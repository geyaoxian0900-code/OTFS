function setup_project_paths(project_root, include_reference_legacy)
%SETUP_PROJECT_PATHS Add active project paths while keeping legacy/archive isolated.
%
%   setup_project_paths(project_root)
%   setup_project_paths(project_root, true)

    if nargin < 1 || isempty(project_root)
        project_root = fileparts(mfilename('fullpath'));
    end
    if nargin < 2
        include_reference_legacy = false;
    end

    add_if_dir(project_root);
    add_if_dir(fullfile(project_root, 'config'));
    add_if_dir(fullfile(project_root, 'scripts'));

    add_if_dir(fullfile(project_root, 'core', 'array'));
    add_if_dir(fullfile(project_root, 'core', 'channel'));
    add_if_dir(fullfile(project_root, 'core', 'data'));
    add_if_dir(fullfile(project_root, 'core', 'detection'));
    add_if_dir(fullfile(project_root, 'core', 'equalizer'));
    add_if_dir(fullfile(project_root, 'core', 'experiment'));
    add_if_dir(fullfile(project_root, 'core', 'models'));
    add_if_dir(fullfile(project_root, 'core', 'modulation'));
    add_if_dir(fullfile(project_root, 'core', 'plotting'));
    add_if_dir(fullfile(project_root, 'core', 'utils'));
    add_if_dir(fullfile(project_root, 'test'));

    if include_reference_legacy
        add_if_dir(fullfile(project_root, 'legacy', 'fig37_reference'));
        add_if_dir(fullfile(project_root, 'legacy', 'helpers_reference'));
    end
end

function add_if_dir(p)
    if exist(p, 'dir') == 7
        addpath(p);
    end
end

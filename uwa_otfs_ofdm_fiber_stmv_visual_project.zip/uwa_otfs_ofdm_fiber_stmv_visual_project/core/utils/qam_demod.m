function bits = qam_demod(symbols, M, varargin)
%QAM_DEMOD Gray-coded square QAM demodulation
%
% Supported call styles:
%   bits = qam_demod(symbols, M, 'hard')
%   bits = qam_demod(symbols, M, noise_var, 'hard')
%
% Inputs:
%   symbols   : received QAM symbols
%   M         : modulation order, supported: 4,16,64,256
%   noise_var : optional, ignored in hard decision mode
%   mode      : currently supports 'hard'
%
% Output:
%   bits      : column vector of recovered bits

    if nargin < 3
        error('qam_demod requires at least 3 arguments');
    end

    if ~ismember(M, [4 16 64 256])
        error('qam_demod: only M = 4, 16, 64, 256 are supported');
    end

    % Parse optional args
    if nargin == 3
        mode = varargin{1};
    elseif nargin >= 4
        mode = varargin{2};
    else
        error('qam_demod: invalid number of arguments');
    end

    if ~ischar(mode) && ~isstring(mode)
        error('qam_demod: mode must be ''hard''');
    end

    mode = char(mode);
    if ~strcmpi(mode, 'hard')
        error('qam_demod: only hard decision is supported in this version');
    end

    symbols = symbols(:);
    k = log2(M);
    m_side = round(sqrt(M));
    k2 = k / 2;

    % Build normalized constellation axis
    levels = -(m_side-1):2:(m_side-1);

    % Normalize levels the same way as qam_mod
    [I, Q] = meshgrid(levels, levels);
    const_full = I(:) + 1j * Q(:);
    norm_factor = sqrt(mean(abs(const_full).^2));

    levels_n = levels / norm_factor;

    % Slice I/Q independently
    re = real(symbols);
    im = imag(symbols);

    idx_i_bin = nearest_level_index(re, levels_n) - 1; % zero-based
    idx_q_bin = nearest_level_index(im, levels_n) - 1; % zero-based

    % Binary index -> Gray index
    idx_i_gray = bitxor(idx_i_bin, bitshift(idx_i_bin, -1));
    idx_q_gray = bitxor(idx_q_bin, bitshift(idx_q_bin, -1));

    bits_i = de2bi(idx_i_gray, k2, 'left-msb');
    bits_q = de2bi(idx_q_gray, k2, 'left-msb');

    bit_mat = [bits_i, bits_q];
    bits = reshape(bit_mat.', [], 1);
end

function idx = nearest_level_index(x, levels)
    idx = zeros(size(x));
    for n = 1:numel(x)
        [~, ii] = min(abs(x(n) - levels));
        idx(n) = ii;
    end
end

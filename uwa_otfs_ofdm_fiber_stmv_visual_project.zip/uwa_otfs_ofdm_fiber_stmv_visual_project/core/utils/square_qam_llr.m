function llr = square_qam_llr(rx_syms, M, noise_var)
%SQUARE_QAM_LLR Max-log LLR for Gray-coded square QAM.
%
% Output convention:
%   LLR > 0  => bit=0 more likely
%   LLR < 0  => bit=1 more likely

    rx_syms = rx_syms(:).';
    k = log2(M);
    m_side = sqrt(M);
    k2 = k / 2;

    if abs(m_side - round(m_side)) > 1e-12
        error('square_qam_llr: M must be square QAM');
    end
    m_side = round(m_side);

    if noise_var <= 0
        noise_var = 1e-12;
    end

    levels = -(m_side-1):2:(m_side-1);

    [I0, Q0] = meshgrid(levels, levels);
    const0 = I0(:) + 1j * Q0(:);
    norm_factor = sqrt(mean(abs(const0).^2));
    levels_n = levels / norm_factor;

    bin_idx = 0:m_side-1;
    gray_idx = bitxor(bin_idx, bitshift(bin_idx, -1));
    gray_bits = de2bi(gray_idx, k2, 'left-msb');

    llr = zeros(1, numel(rx_syms) * k);

    for s = 1:numel(rx_syms)
        x = real(rx_syms(s));
        y = imag(rx_syms(s));

        llr_i = local_pam_llr(x, levels_n, gray_bits, noise_var);
        llr_q = local_pam_llr(y, levels_n, gray_bits, noise_var);

        out_idx = (s-1) * k + (1:k);
        llr(out_idx) = [llr_i, llr_q];
    end
end

function llr = local_pam_llr(z, levels_n, gray_bits, noise_var)
    [m_side, k2] = size(gray_bits);

    d2 = (z - levels_n(:)).^2;
    llr = zeros(1, k2);

    for b = 1:k2
        idx0 = find(gray_bits(:, b) == 0);
        idx1 = find(gray_bits(:, b) == 1);

        d0 = min(d2(idx0));
        d1 = min(d2(idx1));

        llr(b) = (d1 - d0) / max(noise_var, 1e-12);
    end

    if m_side == 2
        llr = llr(:).';
    end
end

function [Htf_eff, bf] = uwa_apply_line_array_beamforming(cfg, freq_hz, Hp_ft, path_angles_deg, path_metric)
%UWA_APPLY_LINE_ARRAY_BEAMFORMING Combine per-path TF contributions.
%
% Active methods are selected only by configuration:
%   cfg.rx_array.combine_method = 'cbf' | 'stmv' | 'improved_stmv'
%
% The default in this package is improved STMV, replacing the former pure
% delay-and-sum beamforming while keeping the downstream OTFS/OFDM API
% unchanged.

    if nargin < 5
        path_metric = [];
    end

    [Ka, M, P] = size(Hp_ft);

    if P == 0
        Htf_eff = zeros(Ka, M);
        bf = struct();
        bf.enabled = false;
        return;
    end

    [path_response, bf] = uwa_line_array_path_response(cfg, freq_hz, path_angles_deg, path_metric);

    Htf_eff = zeros(Ka, M);
    for p = 1:P
        Htf_eff = Htf_eff + Hp_ft(:,:,p) .* repmat(path_response(:, p), 1, M);
    end
end

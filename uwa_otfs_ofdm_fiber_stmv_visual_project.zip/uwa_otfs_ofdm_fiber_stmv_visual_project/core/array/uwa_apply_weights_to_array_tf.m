function Ytf = uwa_apply_weights_to_array_tf(array_tf, Wfull)
%UWA_APPLY_WEIGHTS_TO_ARRAY_TF Apply full-array beam weights on TF snapshots.
%
% Input:
%   array_tf : [Ka x M x E] element-domain TF data
%   Wfull    : [Ka x E] beam weights, row-wise
%
% Output:
%   Ytf      : [Ka x M] beamformed TF data

    [Ka, M, E] = size(array_tf);
    if size(Wfull, 1) == 1 && Ka > 1
        Wfull = repmat(Wfull, Ka, 1);
    end
    if size(Wfull, 1) ~= Ka || size(Wfull, 2) ~= E
        error('uwa_apply_weights_to_array_tf: size mismatch between array_tf and Wfull.');
    end

    Ytf = zeros(Ka, M);
    for k = 1:Ka
        Xk = squeeze(array_tf(k, :, :)); % [M x E]
        Ytf(k, :) = Xk * conj(Wfull(k, :).');
    end
end

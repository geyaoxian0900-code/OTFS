function results = uwa_run_link_simulation(cfg, mode, exp)
%UWA_RUN_LINK_SIMULATION Complete OTFS vs OFDM link simulation.
%
% Configuration is passed in cfg; this function contains no scenario constants.
% It is used by both the selected improved-STMV run and the beamformer
% comparison script.

    if nargin < 2 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 3
        exp = struct();
    end

    if isfield(exp, 'run_dir')
        cfg.output_dir = exp.run_dir;
    elseif ~isfield(cfg, 'output_dir') || isempty(cfg.output_dir)
        cfg.output_dir = fullfile(cfg.output_root, ['complete_chain_' lower(mode)]);
    end
    if ~exist(cfg.output_dir, 'dir')
        mkdir(cfg.output_dir);
    end
    if ~isfield(cfg, 'bellhop_tmp_dir') || isempty(cfg.bellhop_tmp_dir)
        cfg.bellhop_tmp_dir = uwa_make_short_bellhop_tmp_dir(['link_' lower(mode)]);
    elseif ispc && numel(fullfile(cfg.bellhop_tmp_dir, 'fort.6')) >= 240
        cfg.bellhop_tmp_dir = uwa_make_short_bellhop_tmp_dir(['link_' lower(mode)]);
    end
    cfg.bellhop_cache_dir = fullfile(cfg.output_dir, 'bellhop_cache');
    if ~exist(cfg.bellhop_tmp_dir, 'dir'), mkdir(cfg.bellhop_tmp_dir); end
    if ~exist(cfg.bellhop_cache_dir, 'dir'), mkdir(cfg.bellhop_cache_dir); end

    uwa_log('Preparing nominal underwater paths...');
    nom = uwa_bellhop_get_nominal_paths(cfg, ['complete_chain_' mode '_' cfg.rx_array.combine_method]);
    nominal_paths = nom; %#ok<NASGU>
    save(fullfile(cfg.output_dir, ['nominal_paths_' mode '.mat']), 'nominal_paths', 'cfg');

    N = cfg.Ndd;
    M = cfg.Mdd;
    if isfield(cfg, 'otfs_detection') && isfield(cfg.otfs_detection, 'method')
        detector_method = cfg.otfs_detection.method;
    else
        detector_method = 'tf_mmse';
    end
    snr_dB_list = cfg.snr_range;
    prb_list = cfg.prb_configs;

    num_prb_cases = numel(prb_list);
    num_snr = numel(snr_dB_list);

    per_otfs = zeros(num_prb_cases, num_snr);
    per_ofdm = zeros(num_prb_cases, num_snr);
    ber_otfs = zeros(num_prb_cases, num_snr);
    ber_ofdm = zeros(num_prb_cases, num_snr);

    rx_array_snapshots = cell(num_prb_cases, num_snr);

    for iprb = 1:num_prb_cases
        num_prb = prb_list(iprb);
        [~, data_idx, packet_bits] = uwa_make_resource_mask(cfg, num_prb);
        num_data_symbols = numel(data_idx);

        uwa_log('--- PRB=%d | packet_bits=%d | data_symbols=%d | OTFS detector=%s ---', ...
            num_prb, packet_bits, num_data_symbols, detector_method);

        for isnr = 1:num_snr
            snr_dB = snr_dB_list(isnr);
            noise_var = 1 / (cfg.code_rate * log2(cfg.modulation) * 10^(snr_dB / 10));

            pkt_errors_otfs = 0;
            pkt_errors_ofdm = 0;
            bit_errors_otfs = 0;
            bit_errors_ofdm = 0;
            total_info_bits = 0;

            for ipkt = 1:cfg.num_packets
                pkt = uwa_build_tx_packet(cfg, packet_bits, num_data_symbols);

                seed = cfg.seed_base + 100000 * iprb + 1000 * isnr + ipkt;
                [ch, ~] = uwa_bellhop_prepare_frame_channel(cfg, seed, nom);
                if ipkt == 1
                    rx_array_snapshots{iprb, isnr} = ch.rx_array;
                end

                otfs_out = uwa_run_otfs_frame(cfg, pkt.symbols, data_idx, ch, noise_var);
                ofdm_out = uwa_run_ofdm_frame(cfg, pkt.symbols, data_idx, ch, noise_var);

                met_otfs = uwa_decode_and_count(otfs_out.llr, pkt.info_bits, cfg, packet_bits);
                met_ofdm = uwa_decode_and_count(ofdm_out.llr, pkt.info_bits, cfg, packet_bits);

                pkt_errors_otfs = pkt_errors_otfs + double(met_otfs.packet_error);
                pkt_errors_ofdm = pkt_errors_ofdm + double(met_ofdm.packet_error);
                bit_errors_otfs = bit_errors_otfs + met_otfs.bit_errors;
                bit_errors_ofdm = bit_errors_ofdm + met_ofdm.bit_errors;
                total_info_bits = total_info_bits + packet_bits;
            end

            per_otfs(iprb, isnr) = pkt_errors_otfs / cfg.num_packets;
            per_ofdm(iprb, isnr) = pkt_errors_ofdm / cfg.num_packets;
            ber_otfs(iprb, isnr) = bit_errors_otfs / max(total_info_bits, 1);
            ber_ofdm(iprb, isnr) = bit_errors_ofdm / max(total_info_bits, 1);

            uwa_log('SNR=%5.1f dB | BER OTFS=%1.3e OFDM=%1.3e | PER OTFS=%1.3e OFDM=%1.3e', ...
                snr_dB, ber_otfs(iprb, isnr), ber_ofdm(iprb, isnr), per_otfs(iprb, isnr), per_ofdm(iprb, isnr));
        end
    end

    results = struct();
    results.cfg = cfg;
    results.mode = mode;
    results.snr_dB_list = snr_dB_list;
    results.prb_list = prb_list;
    results.per_otfs = per_otfs;
    results.per_ofdm = per_ofdm;
    results.ber_otfs = ber_otfs;
    results.ber_ofdm = ber_ofdm;
    results.rx_array_snapshots = rx_array_snapshots;
    results.otfs_detector_method = detector_method;
    results.created_at = datestr(now, 31);

    save(fullfile(cfg.output_dir, ['results_' mode '.mat']), 'results');
    uwa_plot_link_results(results, mode);
end

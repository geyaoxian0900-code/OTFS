function results = run_complete_uwa_otfs_ofdm_chain(mode, beamformer_method)
%RUN_COMPLETE_UWA_OTFS_OFDM_CHAIN Complete OTFS vs OFDM UWA chain.
%
% This is the main user-facing script after paper integration.
%
% What is kept from the existing project:
%   - OTFS delay-Doppler frame and DD<->TF processing
%   - OFDM TF frame baseline
%   - Bellhop/UWA nominal paths and statistical time-frequency channel
%   - QAM mapping/demapping, coding/decoding, BER/PER plotting
%
% What changed according to the uploaded papers:
%   - Receiver platform is documented as an all-optical fibre hydrophone
%     line array, using only the array-platform content from the fibre-array
%     thesis.
%   - Former default DAS/CBF beamforming is replaced by the selected
%     paper-style improved STMV beamformer: CBF subarrays + STMV/MVDR across
%     subarray outputs.
%   - Configuration, data processing, models, plotting, and experiment logs
%     are separated.
%   - Every run creates a reproducible output/runs/<run_id>/ folder.
%
% Usage:
%   run_complete_uwa_otfs_ofdm_chain
%   run_complete_uwa_otfs_ofdm_chain('quick')
%   run_complete_uwa_otfs_ofdm_chain('paper')
%   run_complete_uwa_otfs_ofdm_chain('paper_final')
%   run_complete_uwa_otfs_ofdm_chain('paper_single_prb16')
%   run_complete_uwa_otfs_ofdm_chain('paper_single_prb4')
%   run_complete_uwa_otfs_ofdm_chain('full')   % alias of paper
%   run_complete_uwa_otfs_ofdm_chain('quick', 'cbf')
%   run_complete_uwa_otfs_ofdm_chain('quick', 'stmv')
%   run_complete_uwa_otfs_ofdm_chain('quick', 'improved_stmv')

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformer_method = '';
    end

    close all; clc;

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    cfg = complete_chain_demo_config(mode);
    cfg.project_root = project_root;
    if ~isempty(beamformer_method)
        cfg.rx_array.combine_method = lower(strtrim(beamformer_method));
    end

    exp = uwa_begin_experiment(cfg, mode, 'run_complete_uwa_otfs_ofdm_chain');
    cleanup_obj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    uwa_log('============================================================');
    uwa_log('Complete UWA OTFS vs OFDM Chain');
    mode_label = mode;
    if isfield(cfg, 'mode_label') && ~isempty(cfg.mode_label)
        mode_label = cfg.mode_label;
    end
    uwa_log('Mode              : %s', upper(mode_label));
    uwa_log('Array platform    : %s', cfg.rx_array.platform);
    uwa_log('Beamformer        : %s', cfg.rx_array.combine_method);
    uwa_log('Metrics           : post-decoder BER and PER');
    uwa_log('Output run folder : %s', exp.run_dir);
    uwa_log('============================================================');
    uwa_log('Carrier           : %.1f kHz', cfg.fc_hz / 1e3);
    uwa_log('Bandwidth         : %.1f Hz', cfg.bandwidth_hz);
    uwa_log('Active SC         : %d', cfg.Ndd);
    uwa_log('OFDM symbols      : %d', cfg.Mdd);
    uwa_log('Modulation        : %d-QAM', cfg.modulation);
    uwa_log('Code rate         : %.3f', cfg.code_rate);
    uwa_log('PRB cases         : [%s]', num2str(cfg.prb_configs));
    if isfield(cfg, 'mode_purpose') && ~isempty(cfg.mode_purpose)
        uwa_log('Mode purpose      : %s', cfg.mode_purpose);
    end
    uwa_log('Packets / SNR     : %d', cfg.num_packets);
    uwa_log('SNR grid          : [%s]', num2str(cfg.snr_range));
    uwa_log('============================================================');

    results = uwa_run_link_simulation(cfg, mode, exp);

    uwa_log('Done. Main run folder: %s', exp.run_dir);
end

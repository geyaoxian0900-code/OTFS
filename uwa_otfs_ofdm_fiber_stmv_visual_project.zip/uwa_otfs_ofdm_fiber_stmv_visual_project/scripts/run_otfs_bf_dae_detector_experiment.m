function all_results = run_otfs_bf_dae_detector_experiment(mode, beamformer_method)
%RUN_OTFS_BF_DAE_DETECTOR_EXPERIMENT Compare TF-MMSE and BF-DAE OTFS detectors.
%
% Example:
%   run_otfs_bf_dae_detector_experiment('quick')
%   run_otfs_bf_dae_detector_experiment('paper', 'improved_stmv')

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2 || isempty(beamformer_method)
        beamformer_method = 'improved_stmv';
    end

    close all; clc;

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    base_cfg = complete_chain_demo_config(mode);
    base_cfg.rx_array.combine_method = lower(strtrim(beamformer_method));

    exp = uwa_begin_experiment(base_cfg, mode, 'run_otfs_bf_dae_detector_experiment');
    cleanup_obj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    methods = {'tf_mmse', 'bf_dae'};
    all_results = cell(1, numel(methods));
    for i = 1:numel(methods)
        cfg = base_cfg;
        cfg.otfs_detection.method = methods{i};
        cfg.output_dir = fullfile(exp.run_dir, methods{i});
        cfg.bellhop_tmp_dir = fullfile(cfg.output_dir, 'bellhop_tmp');
        cfg.bellhop_cache_dir = fullfile(exp.run_dir, 'shared_bellhop_cache');
        if exist(cfg.output_dir, 'dir') ~= 7
            mkdir(cfg.output_dir);
        end

        uwa_log('============================================================');
        uwa_log('OTFS detector comparison branch: %s', methods{i});
        uwa_log('Receive beamformer             : %s', cfg.rx_array.combine_method);
        uwa_log('============================================================');

        all_results{i} = uwa_run_link_simulation(cfg, [mode '_' methods{i}], struct('run_dir', cfg.output_dir));
    end

    save(fullfile(exp.run_dir, ['otfs_detector_results_' mode '.mat']), 'all_results', 'methods', 'base_cfg');
    uwa_plot_otfs_detector_comparison(all_results, methods, exp.run_dir, mode);
    uwa_log('OTFS detector comparison finished. Folder: %s', exp.run_dir);
end

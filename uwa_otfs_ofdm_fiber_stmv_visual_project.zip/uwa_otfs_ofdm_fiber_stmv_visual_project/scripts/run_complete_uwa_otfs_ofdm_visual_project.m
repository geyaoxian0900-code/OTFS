function outputs = run_complete_uwa_otfs_ofdm_visual_project(mode, beamformer_method, otfs_detector_method)
%RUN_COMPLETE_UWA_OTFS_OFDM_VISUAL_PROJECT Full project with all requested figures.
%
% Main user entry for the expanded project.
% Optional third argument selects the OTFS detector.
%
% Usage:
%   run_complete_uwa_otfs_ofdm_visual_project
%   run_complete_uwa_otfs_ofdm_visual_project('quick')
%   run_complete_uwa_otfs_ofdm_visual_project('paper')
%   run_complete_uwa_otfs_ofdm_visual_project('paper_final')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'cbf')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'stmv')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv', 'bf_dae')
%
% Output:
%   outputs.results            : BER/PER Monte-Carlo results
%   outputs.visual_snapshot    : representative node snapshot
%   outputs.chain_manifest     : communication-node figure list
%   outputs.beam_manifest      : beamforming-figure list
%   outputs.summary_manifest   : markdown manifest path

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformer_method = '';
    end
    if nargin < 3
        otfs_detector_method = '';
    end

    close all; clc;

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    cfg = visualization_project_config(mode);
    cfg.project_root = project_root;
    if ~isempty(beamformer_method)
        cfg.rx_array.combine_method = lower(strtrim(beamformer_method));
    end
    if ~isempty(otfs_detector_method)
        cfg.otfs_detection.method = lower(strtrim(otfs_detector_method));
    end

    exp = uwa_begin_experiment(cfg, mode, 'run_complete_uwa_otfs_ofdm_visual_project');
    cleanup_obj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    uwa_log('============================================================');
    uwa_log('Expanded UWA OTFS/OFDM full visual project');
    uwa_log('Mode              : %s', upper(mode));
    uwa_log('Beamformer        : %s', cfg.rx_array.combine_method);
    uwa_log('Output run folder : %s', exp.run_dir);
    uwa_log('OTFS detector     : %s', cfg.otfs_detection.method);
    uwa_log('Representative PRB: %d', cfg.visual.rep_prb);
    uwa_log('Representative SNR: %.2f dB', cfg.visual.rep_snr_dB);
    uwa_log('============================================================');

    % Use the actual run folder for all outputs.
    cfg.output_dir = exp.run_dir;
    cfg.run_dir = exp.run_dir;

    results = uwa_run_link_simulation(cfg, mode, exp);

    nom = uwa_bellhop_get_nominal_paths(cfg, ['visual_project_' lower(mode) '_' cfg.rx_array.combine_method]);
    visual_snapshot = uwa_capture_link_nodes(cfg, nom);
   snapshot_file = fullfile(exp.run_dir, 'visual_snapshot.mat');

% 短路径兜底目录
short_snapshot_dir = fullfile(tempdir, 'uwa_visual_snapshots');
if ~exist(short_snapshot_dir, 'dir')
    mkdir(short_snapshot_dir);
end
snapshot_file_short = fullfile(short_snapshot_dir, [exp.run_id '_visual_snapshot.mat']);

% 删除可能遗留的坏文件
if exist(snapshot_file, 'file')
    delete(snapshot_file);
end
if exist(snapshot_file_short, 'file')
    delete(snapshot_file_short);
end

try
    % 优先用 -v7，避免 -v7.3/HDF5 在长路径下出问题
    save(snapshot_file, 'visual_snapshot', '-v7');
    visual_snapshot_save_path = snapshot_file;
catch ME1
    warning('Save to run_dir failed: %s', ME1.message);
    warning('Falling back to short path: %s', snapshot_file_short);

    try
        save(snapshot_file_short, 'visual_snapshot', '-v7');
        visual_snapshot_save_path = snapshot_file_short;
    catch ME2
        % 如果变量过大，再尝试短路径 + v7.3
        warning('Save with -v7 also failed: %s', ME2.message);
        save(snapshot_file_short, 'visual_snapshot', '-v7.3');
        visual_snapshot_save_path = snapshot_file_short;
    end
end


    chain_dir = fullfile(exp.run_dir, cfg.visual.figure_root_name, cfg.visual.chain_subdir);
    beam_dir = fullfile(exp.run_dir, cfg.visual.figure_root_name, cfg.visual.beam_subdir);

    chain_manifest = uwa_generate_communication_node_figures(visual_snapshot, chain_dir);
    beam_manifest = uwa_generate_beamforming_figure_suite(visual_snapshot, beam_dir);
    summary_manifest = uwa_write_visual_manifest(exp.run_dir, results, chain_manifest, beam_manifest, visual_snapshot);

    uwa_log('Communication-node figures saved: %d', numel(chain_manifest));
    uwa_log('Beamforming figures saved       : %d', numel(beam_manifest));
    uwa_log('Figure manifest                 : %s', summary_manifest);
    uwa_log('============================================================');

    outputs = struct();
    outputs.results = results;
    outputs.visual_snapshot = visual_snapshot;
    outputs.chain_manifest = chain_manifest;
    outputs.beam_manifest = beam_manifest;
    outputs.summary_manifest = summary_manifest;
end

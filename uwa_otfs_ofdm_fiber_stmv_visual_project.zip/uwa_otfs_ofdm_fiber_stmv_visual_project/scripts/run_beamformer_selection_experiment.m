function all_results = run_beamformer_selection_experiment(mode)
%RUN_BEAMFORMER_SELECTION_EXPERIMENT Compare CBF/MVDR/WICMV/STMV/improved-STMV.
%
% This script keeps the transceiver, channel, coding, mapping, and OTFS/OFDM
% settings fixed, and changes only cfg.rx_array.combine_method.  It is the
% reproducible comparison used to justify choosing improved STMV as the
% default OTFS receive beamformer.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end

    close all; clc;

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    base_cfg = beamformer_selection_config(mode);
    methods = base_cfg.rx_array.candidate_methods;

    exp = uwa_begin_experiment(base_cfg, mode, 'run_beamformer_selection_experiment');
    cleanup_obj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    all_results = cell(1, numel(methods));
    for im = 1:numel(methods)
        method = methods{im};
        cfg = base_cfg;
        cfg.rx_array.combine_method = method;
        cfg.seed_base = base_cfg.seed_base;  % same seeds for fair comparison
        cfg.output_dir = fullfile(exp.run_dir, method);
        cfg.bellhop_tmp_dir = fullfile(cfg.output_dir, 'bellhop_tmp');
        cfg.bellhop_cache_dir = fullfile(exp.run_dir, 'shared_bellhop_cache');
        if ~exist(cfg.output_dir, 'dir')
            mkdir(cfg.output_dir);
        end

        uwa_log('============================================================');
        uwa_log('Beamformer comparison branch: %s', method);
        uwa_log('============================================================');
        all_results{im} = uwa_run_link_simulation(cfg, [mode '_' method], struct('run_dir', cfg.output_dir));
    end

    save(fullfile(exp.run_dir, ['beamformer_selection_results_' mode '.mat']), 'all_results', 'methods', 'base_cfg');
    uwa_plot_beamformer_selection(all_results, methods, exp.run_dir, mode);
    uwa_log('Beamformer selection finished. Folder: %s', exp.run_dir);
end

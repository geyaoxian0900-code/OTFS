function manifest = run_generate_beamforming_suite(mode, beamformer_method)
%RUN_GENERATE_BEAMFORMING_SUITE Generate only the beamforming figure suite.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformer_method = '';
    end

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    cfg = visualization_project_config(mode);
    if ~isempty(beamformer_method)
        cfg.rx_array.combine_method = lower(strtrim(beamformer_method));
    end

    nom = uwa_bellhop_get_nominal_paths(cfg, ['beam_suite_' lower(mode) '_' cfg.rx_array.combine_method]);
    vis = uwa_capture_link_nodes(cfg, nom);

    out_dir = fullfile(cfg.output_root, 'beamforming_suite_only');
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end
    manifest = uwa_generate_beamforming_figure_suite(vis, out_dir);
end

function manifest = run_generate_link_node_figures(mode, beamformer_method)
%RUN_GENERATE_LINK_NODE_FIGURES Generate only the communication-node figures.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformer_method = '';
    end

    project_root = fileparts(fileparts(mfilename('fullpath')));
    setup_project_paths(project_root, false);

    cfg = visualization_project_config(mode);
    if ~isempty(beamformer_method)
        cfg.rx_array.combine_method = lower(strtrim(beamformer_method));
    end

    nom = uwa_bellhop_get_nominal_paths(cfg, ['node_suite_' lower(mode) '_' cfg.rx_array.combine_method]);
    vis = uwa_capture_link_nodes(cfg, nom);

    out_dir = fullfile(cfg.output_root, 'communication_node_figures_only');
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end
    manifest = uwa_generate_communication_node_figures(vis, out_dir);
end

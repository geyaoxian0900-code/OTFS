function [nominalPaths, visualSnapshot] = uwa_capture_visual_snapshot(cfg, snapshotTag)
%UWA_CAPTURE_VISUAL_SNAPSHOT Capture a representative visualization snapshot.
%
% Usage:
%   [nominalPaths, visualSnapshot] = uwa_capture_visual_snapshot(cfg, snapshotTag)
%
% Inputs:
%   cfg          - Visualization configuration struct.
%   snapshotTag  - String tag used for Bellhop/cache naming.
%
% Outputs:
%   nominalPaths - Nominal path struct returned by Bellhop/synthetic model.
%   visualSnapshot - Representative link/node snapshot struct.

    if nargin < 2 || isempty(snapshotTag)
        error('uwa_capture_visual_snapshot: snapshotTag must be provided.');
    end

    nominalPaths = uwa_bellhop_get_nominal_paths(cfg, snapshotTag); % [Refactor] 原因：将“生成标称路径 + 抓取可视化快照”固定组合提取为单一职责函数。
    visualSnapshot = uwa_capture_link_nodes(cfg, nominalPaths);      % [Refactor] 原因：避免多个入口分别维护相同的可视化快照生成序列。
end

function cfg = uwa_prepare_link_simulation_dirs(cfg, mode, exp)
%UWA_PREPARE_LINK_SIMULATION_DIRS Prepare output and Bellhop directories.
%
% Usage:
%   cfg = uwa_prepare_link_simulation_dirs(cfg, mode)
%   cfg = uwa_prepare_link_simulation_dirs(cfg, mode, exp)
%
% Inputs:
%   cfg  - Simulation configuration struct.
%   mode - Run mode string.
%   exp  - Optional experiment struct; if it contains run_dir, that folder
%          becomes cfg.output_dir.
%
% Output:
%   cfg  - Updated configuration with prepared directories.

    if nargin < 3
        exp = struct();
    end

    if isfield(exp, 'run_dir')
        cfg.output_dir = exp.run_dir; % [Refactor] 原因：将实验目录优先级规则集中封装，避免模型主函数携带过多目录分支逻辑。
    elseif ~isfield(cfg, 'output_dir') || isempty(cfg.output_dir)
        cfg.output_dir = fullfile(cfg.output_root, ['complete_chain_' lower(mode)]); % [Refactor] 原因：保留原默认目录策略，同时让主仿真函数只负责流程控制。
    end
    if exist(cfg.output_dir, 'dir') ~= 7
        mkdir(cfg.output_dir);
    end

    if ~isfield(cfg, 'bellhop_tmp_dir') || isempty(cfg.bellhop_tmp_dir)
        cfg.bellhop_tmp_dir = uwa_make_short_bellhop_tmp_dir(['link_' lower(mode)]); % [Refactor] 原因：集中处理 Bellhop 临时目录创建与短路径兜底逻辑。
    elseif ispc && numel(fullfile(cfg.bellhop_tmp_dir, 'fort.6')) >= 240
        cfg.bellhop_tmp_dir = uwa_make_short_bellhop_tmp_dir(['link_' lower(mode)]); % [Refactor] 原因：保留原 Windows 长路径保护分支，但移出主仿真循环函数。
    end

    cfg.bellhop_cache_dir = fullfile(cfg.output_dir, 'bellhop_cache'); % [Refactor] 原因：统一缓存目录命名，避免目录创建代码散落在主流程中。
    if exist(cfg.bellhop_tmp_dir, 'dir') ~= 7
        mkdir(cfg.bellhop_tmp_dir);
    end
    if exist(cfg.bellhop_cache_dir, 'dir') ~= 7
        mkdir(cfg.bellhop_cache_dir);
    end
end

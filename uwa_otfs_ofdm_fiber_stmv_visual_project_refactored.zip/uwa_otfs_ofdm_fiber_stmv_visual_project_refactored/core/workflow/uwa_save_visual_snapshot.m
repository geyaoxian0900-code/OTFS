function savedPath = uwa_save_visual_snapshot(visualSnapshot, runDir, runId)
%UWA_SAVE_VISUAL_SNAPSHOT Save visual snapshot with long-path fallback handling.
%
% Usage:
%   savedPath = uwa_save_visual_snapshot(visualSnapshot, runDir, runId)
%
% Inputs:
%   visualSnapshot - Snapshot struct to be saved.
%   runDir         - Experiment run directory.
%   runId          - Run identifier used in fallback filename.
%
% Output:
%   savedPath      - Actual .mat file path used for saving.

    if nargin < 3 || isempty(runId)
        error('uwa_save_visual_snapshot: runId must be provided.');
    end

    visual_snapshot = visualSnapshot; %#ok<NASGU> % [Refactor] 原因：保持 .mat 文件中的变量名与原脚本一致，避免下游读取兼容性变化。
    snapshotFile = fullfile(runDir, 'visual_snapshot.mat');

    shortSnapshotDir = fullfile(tempdir, 'uwa_visual_snapshots');
    if exist(shortSnapshotDir, 'dir') ~= 7
        mkdir(shortSnapshotDir); % [Refactor] 原因：将长路径兜底逻辑集中封装，主脚本不再嵌入文件系统细节。
    end
    snapshotFileShort = fullfile(shortSnapshotDir, [runId '_visual_snapshot.mat']);

    delete_if_exists(snapshotFile);      % [Refactor] 原因：将保存前坏文件清理固定化，避免重复样板代码。
    delete_if_exists(snapshotFileShort); % [Refactor] 原因：与主保存路径同样执行清理，降低异常重跑时的文件残留风险。

    try
        save(snapshotFile, 'visual_snapshot', '-v7'); % [Refactor] 原因：优先保持原有 -v7 保存策略，最大限度维持兼容性与数值序列化行为。
        savedPath = snapshotFile;
    catch primaryError
        warning('Save to run_dir failed: %s', primaryError.message);
        warning('Falling back to short path: %s', snapshotFileShort);

        try
            save(snapshotFileShort, 'visual_snapshot', '-v7'); % [Refactor] 原因：与原逻辑一致，先尝试短路径 + -v7。
            savedPath = snapshotFileShort;
        catch secondaryError
            warning('Save with -v7 also failed: %s', secondaryError.message);
            save(snapshotFileShort, 'visual_snapshot', '-v7.3'); % [Refactor] 原因：仅在变量过大或格式受限时再回退到 -v7.3，保持原保存优先级。
            savedPath = snapshotFileShort;
        end
    end
end

function delete_if_exists(filePath)
%DELETE_IF_EXISTS Delete file only when it already exists.
    if exist(filePath, 'file') == 2
        delete(filePath);
    end
end

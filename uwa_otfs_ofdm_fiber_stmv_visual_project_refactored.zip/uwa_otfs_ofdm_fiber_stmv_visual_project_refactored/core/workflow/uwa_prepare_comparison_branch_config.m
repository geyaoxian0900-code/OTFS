function branchCfg = uwa_prepare_comparison_branch_config(baseCfg, experimentRunDir, branchName)
%UWA_PREPARE_COMPARISON_BRANCH_CONFIG Build per-branch config for comparison runs.
%
% Usage:
%   branchCfg = uwa_prepare_comparison_branch_config(baseCfg, experimentRunDir, branchName)
%
% Inputs:
%   baseCfg          - Base configuration struct.
%   experimentRunDir - Root run directory of the current experiment.
%   branchName       - Name of the branch/method subfolder.
%
% Output:
%   branchCfg        - Configuration struct for the requested branch.

    if nargin < 3 || isempty(branchName)
        error('uwa_prepare_comparison_branch_config: branchName must be provided.');
    end

    branchCfg = baseCfg;
    branchCfg.output_dir = fullfile(experimentRunDir, branchName); % [Refactor] 原因：将分支目录构造逻辑提取为复用函数，消除多个脚本中的重复代码。
    branchCfg.bellhop_tmp_dir = fullfile(branchCfg.output_dir, 'bellhop_tmp'); % [Refactor] 原因：保持每个分支的临时目录隔离，同时复用统一构造规则。
    branchCfg.bellhop_cache_dir = fullfile(experimentRunDir, 'shared_bellhop_cache'); % [Refactor] 原因：统一共享 Bellhop 缓存目录，避免脚本间实现漂移。

    if exist(branchCfg.output_dir, 'dir') ~= 7
        mkdir(branchCfg.output_dir); % [Refactor] 原因：把输出目录预创建放在配置阶段，主脚本只保留流程编排职责。
    end
end

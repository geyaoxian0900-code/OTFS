function results = uwa_build_link_results(cfg, mode, snrDbList, prbList, metrics, detectorMethod)
%UWA_BUILD_LINK_RESULTS Assemble the saved results struct for link simulation.
%
% Usage:
%   results = uwa_build_link_results(cfg, mode, snrDbList, prbList, metrics, detectorMethod)
%
% Inputs:
%   cfg            - Simulation configuration struct.
%   mode           - Run mode string.
%   snrDbList      - SNR grid vector.
%   prbList        - PRB configuration vector.
%   metrics        - Struct returned/filled by simulation loops.
%   detectorMethod - OTFS detector method string.
%
% Output:
%   results        - Results struct saved to disk and passed to plotting.

    results = struct();
    results.cfg = cfg;
    results.mode = mode;
    results.snr_dB_list = snrDbList;
    results.prb_list = prbList;
    results.per_otfs = metrics.perOtfs;
    results.per_ofdm = metrics.perOfdm;
    results.ber_otfs = metrics.berOtfs;
    results.ber_ofdm = metrics.berOfdm;
    results.rx_array_snapshots = metrics.rxArraySnapshots;
    results.otfs_detector_method = detectorMethod;
    results.created_at = datestr(now, 31);
end

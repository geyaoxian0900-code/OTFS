function batchMetrics = uwa_run_snr_packet_batch(cfg, dataIdx, packetBits, snrDb, prbIndex, snrIndex, nominalPaths)
%UWA_RUN_SNR_PACKET_BATCH Run all packets for one PRB/SNR operating point.
%
% Usage:
%   batchMetrics = uwa_run_snr_packet_batch(cfg, dataIdx, packetBits, snrDb, prbIndex, snrIndex, nominalPaths)
%
% Inputs:
%   cfg          - Simulation configuration struct.
%   dataIdx      - Active resource/data indices for the current PRB case.
%   packetBits   - Information-bit count per packet.
%   snrDb        - Current SNR point in dB.
%   prbIndex     - PRB-case loop index.
%   snrIndex     - SNR loop index.
%   nominalPaths - Nominal path struct.
%
% Output:
%   batchMetrics - Struct with BER/PER statistics and first packet array snapshot.

    numDataSymbols = numel(dataIdx);
    noiseVar = 1 / (cfg.code_rate * log2(cfg.modulation) * 10^(snrDb / 10));

    packetErrorOtfs = 0;
    packetErrorOfdm = 0;
    bitErrorOtfs = 0;
    bitErrorOfdm = 0;
    firstRxArraySnapshot = [];

    for packetIndex = 1:cfg.num_packets
        txPacket = uwa_build_tx_packet(cfg, packetBits, numDataSymbols);

        seed = cfg.seed_base + 100000 * prbIndex + 1000 * snrIndex + packetIndex; % [Refactor] 原因：保持原种子生成公式不变，确保 Monte-Carlo 随机序列逻辑一致。
        [channelRealization, ~] = uwa_bellhop_prepare_frame_channel(cfg, seed, nominalPaths);
        if packetIndex == 1
            firstRxArraySnapshot = channelRealization.rx_array; % [Refactor] 原因：仅保留每个工作点首包快照，与原结果结构完全一致。
        end

        otfsOutput = uwa_run_otfs_frame(cfg, txPacket.symbols, dataIdx, channelRealization, noiseVar);
        ofdmOutput = uwa_run_ofdm_frame(cfg, txPacket.symbols, dataIdx, channelRealization, noiseVar);

        otfsMetrics = uwa_decode_and_count(otfsOutput.llr, txPacket.info_bits, cfg, packetBits);
        ofdmMetrics = uwa_decode_and_count(ofdmOutput.llr, txPacket.info_bits, cfg, packetBits);

        packetErrorOtfs = packetErrorOtfs + double(otfsMetrics.packet_error);
        packetErrorOfdm = packetErrorOfdm + double(ofdmMetrics.packet_error);
        bitErrorOtfs = bitErrorOtfs + otfsMetrics.bit_errors;
        bitErrorOfdm = bitErrorOfdm + ofdmMetrics.bit_errors;
    end

    totalInfoBits = packetBits * cfg.num_packets; % [Refactor] 原因：该值在当前工作点内恒定，直接计算可消除重复累加而不改变数值结果。

    batchMetrics = struct();
    batchMetrics.perOtfs = packetErrorOtfs / cfg.num_packets;
    batchMetrics.perOfdm = packetErrorOfdm / cfg.num_packets;
    batchMetrics.berOtfs = bitErrorOtfs / max(totalInfoBits, 1);
    batchMetrics.berOfdm = bitErrorOfdm / max(totalInfoBits, 1);
    batchMetrics.rxArraySnapshot = firstRxArraySnapshot;
end

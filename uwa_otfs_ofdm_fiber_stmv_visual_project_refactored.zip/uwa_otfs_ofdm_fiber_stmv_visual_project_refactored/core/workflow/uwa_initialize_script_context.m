function scriptContext = uwa_initialize_script_context(callerFullPath, resetWorkspaceState)
%UWA_INITIALIZE_SCRIPT_CONTEXT Initialize project root and path context for entry scripts.
%
% Usage:
%   scriptContext = uwa_initialize_script_context(callerFullPath)
%   scriptContext = uwa_initialize_script_context(callerFullPath, resetWorkspaceState)
%
% Inputs:
%   callerFullPath      - Full path returned by mfilename('fullpath') from
%                         the caller entry script/function.
%   resetWorkspaceState - Logical flag. true executes close all and clc.
%
% Output:
%   scriptContext       - Struct with fields:
%                         .callerFullPath
%                         .projectRoot
%
% Notes:
%   This helper centralizes the repeated "find project root + setup path"
%   logic used by multiple top-level entry functions.

    if nargin < 1 || isempty(callerFullPath)
        error('uwa_initialize_script_context: callerFullPath must be provided.');
    end
    if nargin < 2
        resetWorkspaceState = true;
    end

    if resetWorkspaceState
        close all; % [Refactor] 原因：将入口脚本重复的环境清理动作收敛到单一函数，减少样板代码。
        clc;       % [Refactor] 原因：与 close all 一并封装，保证各入口的一致初始化行为。
    end

    projectRoot = fileparts(fileparts(callerFullPath));
    setup_project_paths(projectRoot, false); % [Refactor] 原因：统一路径初始化入口，避免各主脚本重复维护同样的 addpath 逻辑。

    scriptContext = struct();
    scriptContext.callerFullPath = callerFullPath;
    scriptContext.projectRoot = projectRoot;
end

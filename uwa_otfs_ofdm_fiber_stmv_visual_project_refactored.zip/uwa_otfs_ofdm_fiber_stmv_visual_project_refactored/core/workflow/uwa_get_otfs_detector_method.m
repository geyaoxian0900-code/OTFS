function detectorMethod = uwa_get_otfs_detector_method(cfg)
%UWA_GET_OTFS_DETECTOR_METHOD Resolve the OTFS detector method from cfg.
%
% Usage:
%   detectorMethod = uwa_get_otfs_detector_method(cfg)
%
% Input:
%   cfg            - Configuration struct.
%
% Output:
%   detectorMethod - Detector method string.

    if isfield(cfg, 'otfs_detection') && isfield(cfg.otfs_detection, 'method') && ~isempty(cfg.otfs_detection.method)
        detectorMethod = cfg.otfs_detection.method;
    else
        detectorMethod = 'tf_mmse'; % [Refactor] 原因：把默认检测器选择规则从主仿真流程中提取，避免重复字段判断。
    end
end

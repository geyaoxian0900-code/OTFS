function [chainDir, beamDir] = uwa_build_visual_output_dirs(runDir, visualCfg)
%UWA_BUILD_VISUAL_OUTPUT_DIRS Build output directories for visual figure suites.
%
% Usage:
%   [chainDir, beamDir] = uwa_build_visual_output_dirs(runDir, visualCfg)
%
% Inputs:
%   runDir    - Experiment run directory.
%   visualCfg - cfg.visual struct.
%
% Outputs:
%   chainDir  - Communication-node figure directory.
%   beamDir   - Beamforming-suite figure directory.

    chainDir = fullfile(runDir, visualCfg.figure_root_name, visualCfg.chain_subdir); % [Refactor] 原因：集中封装目录拼接规则，避免入口脚本出现重复的 fullfile 组合。
    beamDir = fullfile(runDir, visualCfg.figure_root_name, visualCfg.beam_subdir);   % [Refactor] 原因：同上，保证链路图与波束图目录命名规则一致。
end

function cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod, otfsDetectorMethod)
%UWA_APPLY_RUNTIME_OVERRIDES Apply optional runtime method overrides to cfg.
%
% Usage:
%   cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod)
%   cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod, otfsDetectorMethod)
%
% Inputs:
%   cfg                - Configuration struct.
%   beamformerMethod   - Optional beamformer method string.
%   otfsDetectorMethod - Optional OTFS detector method string.
%
% Output:
%   cfg                - Updated configuration struct.

    if nargin >= 2 && ~isempty(beamformerMethod)
        cfg.rx_array.combine_method = lower(strtrim(beamformerMethod)); % [Refactor] 原因：将重复的波束形成器覆盖逻辑提取为公共函数，统一入口行为。
    end

    if nargin >= 3 && ~isempty(otfsDetectorMethod)
        if ~isfield(cfg, 'otfs_detection') || ~isstruct(cfg.otfs_detection)
            cfg.otfs_detection = struct(); % [Refactor] 原因：保证检测器配置字段存在，避免入口脚本分别处理字段防御逻辑。
        end
        cfg.otfs_detection.method = lower(strtrim(otfsDetectorMethod)); % [Refactor] 原因：集中处理 OTFS 检测器覆盖逻辑，减少主脚本分支代码。
    end
end

function metrics = uwa_initialize_link_metrics(numPrbCases, numSnr)
%UWA_INITIALIZE_LINK_METRICS Preallocate result arrays for link simulation.
%
% Usage:
%   metrics = uwa_initialize_link_metrics(numPrbCases, numSnr)
%
% Inputs:
%   numPrbCases - Number of PRB configurations.
%   numSnr      - Number of SNR points.
%
% Output:
%   metrics     - Struct with preallocated metric arrays and snapshots.

    metrics = struct();
    metrics.perOtfs = zeros(numPrbCases, numSnr);  % [Refactor] 原因：统一集中预分配，避免主仿真函数分散声明多个结果数组。
    metrics.perOfdm = zeros(numPrbCases, numSnr);  % [Refactor] 原因：显式预分配内存，满足重构要求并减少动态扩展风险。
    metrics.berOtfs = zeros(numPrbCases, numSnr);  % [Refactor] 原因：与原数值类型保持一致，不改变算法输出格式。
    metrics.berOfdm = zeros(numPrbCases, numSnr);  % [Refactor] 原因：同上。
    metrics.rxArraySnapshots = cell(numPrbCases, numSnr); % [Refactor] 原因：将快照容器也统一预分配，避免循环内隐式扩容。
end

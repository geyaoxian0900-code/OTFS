function pkt = uwa_build_tx_packet(cfg, packet_bits, num_data_symbols)
%UWA_BUILD_TX_PACKET Generate bits, encode, and QAM map one packet.

    pkt = struct();
    pkt.info_bits = randi([0 1], 1, packet_bits);
    pkt.coded_len = num_data_symbols * log2(cfg.modulation);

    coded_bits = ldpc_encode(pkt.info_bits, cfg.code_rate, pkt.coded_len, 'QPSK');
    coded_bits = double(coded_bits(:)).';
    if numel(coded_bits) < pkt.coded_len
        coded_bits = [coded_bits zeros(1, pkt.coded_len - numel(coded_bits))];
    elseif numel(coded_bits) > pkt.coded_len
        coded_bits = coded_bits(1:pkt.coded_len);
    end
    pkt.coded_bits = coded_bits;
    pkt.symbols = qam_mod(coded_bits, cfg.modulation);
    pkt.symbols = pkt.symbols(:);
end

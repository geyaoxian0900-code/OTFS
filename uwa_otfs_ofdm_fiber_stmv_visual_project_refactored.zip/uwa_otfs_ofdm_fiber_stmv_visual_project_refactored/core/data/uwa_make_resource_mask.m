function [resource_mask, data_idx, packet_bits] = uwa_make_resource_mask(cfg, num_prb)
%UWA_MAKE_RESOURCE_MASK Build active DD/TF resource mask and info-bit count.

    N = cfg.Ndd;
    M = cfg.Mdd;
    resource_mask = false(N, M);
    resource_mask(1:num_prb, :) = true;
    data_idx = find(resource_mask);
    num_data_symbols = numel(data_idx);
    packet_bits_nominal = round(num_data_symbols * log2(cfg.modulation) * cfg.code_rate);
    packet_bits = max(packet_bits_nominal - 6, 1);
end

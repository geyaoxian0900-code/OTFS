function metrics = uwa_decode_and_count(llr, tx_info_bits, cfg, packet_bits)
%UWA_DECODE_AND_COUNT Decode one packet and count bit/packet errors.

    metrics = struct();
    metrics.rx_info_bits = [];
    metrics.bit_errors = packet_bits;
    metrics.packet_error = 1;

    try
        rx_info = ldpc_decode(llr(:), cfg.code_rate, packet_bits, 0, 'QPSK');
    catch
        rx_info = [];
    end

    if ~isempty(rx_info)
        rx_info = double(rx_info(:)).';
        metrics.rx_info_bits = rx_info;
        if numel(rx_info) >= packet_bits
            metrics.bit_errors = sum(rx_info(1:packet_bits) ~= tx_info_bits);
            metrics.packet_error = double(metrics.bit_errors > 0);
        end
    end
end

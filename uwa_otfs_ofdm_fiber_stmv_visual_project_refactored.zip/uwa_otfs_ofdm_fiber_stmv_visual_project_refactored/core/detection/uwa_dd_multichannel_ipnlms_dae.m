function out = uwa_dd_multichannel_ipnlms_dae(cfg, Zdd, Xdd_ref, data_idx, noise_var)
%UWA_DD_MULTICHANNEL_IPNLMS_DAE Multichannel DD-domain adaptive detector.
%
% Lightweight project implementation inspired by the BF-DAE OTFS UWA paper.
% The detector keeps multiple beamformed DD-domain inputs and applies a 2D
% feedforward / feedback adaptive filter with IPNLMS-style updates.
%
% Input:
%   cfg     : project config, uses cfg.otfs_detection.bf_dae
%   Zdd     : [N x M x Q] beamformed DD-domain observations
%   Xdd_ref : [N x M] reference transmitted DD grid (used for the training
%             portion and for simulation-time benchmarking)
%   data_idx: linear indices of data-bearing DD bins
%   noise_var: effective noise variance used for LLR generation
%
% Output fields:
%   Xhat_dd, decisions_dd, llr, rx_syms, beam_filters, feedback_filter,
%   train_count, num_beams, params

    pars = cfg.otfs_detection.bf_dae;
    [N, M, Q] = size(Zdd);

    Kf = local_get_field(pars, 'Kf', 1);
    Lf = local_get_field(pars, 'Lf', 1);
    Kb = local_get_field(pars, 'Kb', 1);
    Lb = local_get_field(pars, 'Lb', 1);
    mu_f = local_get_field(pars, 'mu_f', 0.25);
    mu_b = local_get_field(pars, 'mu_b', 0.10);
    delta_f = local_get_field(pars, 'delta_f', 1e-3);
    delta_b = local_get_field(pars, 'delta_b', 1e-3);
    alpha = local_get_field(pars, 'ipnlms_alpha', 0);
    use_feedback = logical(local_get_field(pars, 'use_feedback', true));
    dd_after_train = logical(local_get_field(pars, 'decision_directed_after_training', true));
    num_passes = max(1, round(local_get_field(pars, 'num_passes', 1)));

    ff_len = (2 * Kf + 1) * (Lf + 1);
    fb_offsets = local_feedback_offsets(Kb, Lb);
    fb_len = size(fb_offsets, 1);

    F = cell(Q, 1);
    for q = 1:Q
        fq = zeros(ff_len, 1);
        center_idx = local_ff_center_index(Kf, Lf);
        fq(center_idx) = 1 / max(Q, 1);
        F{q} = fq;
    end
    B = zeros(fb_len, 1);

    order = data_idx(:).';
    train_count = max(1, min(numel(order), round(local_get_field(pars, 'training_fraction', 0.25) * numel(order))));

    Xhat_dd = zeros(N, M);
    decisions_dd = zeros(N, M);
    data_mask = false(N, M);
    data_mask(data_idx) = true;

    for pass = 1:num_passes
        for it = 1:numel(order)
            lin = order(it);
            [k, l] = ind2sub([N, M], lin);

            ff_cell = cell(Q, 1);
            y_hat = 0;
            for q = 1:Q
                u_ff = local_ff_patch(Zdd(:, :, q), k, l, Kf, Lf);
                ff_cell{q} = u_ff;
                y_hat = y_hat + F{q}' * u_ff;
            end

            if use_feedback && fb_len > 0
                u_fb = local_fb_patch(decisions_dd, k, l, fb_offsets);
                y_hat = y_hat - B' * u_fb;
            else
                u_fb = zeros(0, 1);
            end

            x_true = Xdd_ref(k, l);
            if pass == 1 && it <= train_count
                d = x_true;
            elseif dd_after_train
                d = local_hard_qam_symbol(y_hat, cfg.modulation);
            else
                d = x_true;
            end

            e = d - y_hat;

            for q = 1:Q
                Gf = local_ipnlms_diag(F{q}, alpha);
                u_ff = ff_cell{q};
                denom_f = real(u_ff' * Gf * u_ff) + delta_f;
                F{q} = F{q} + mu_f * conj(e) * (Gf * u_ff) / max(denom_f, eps);
            end

            if use_feedback && fb_len > 0
                Gb = local_ipnlms_diag(B, alpha);
                denom_b = real(u_fb' * Gb * u_fb) + delta_b;
                B = B + mu_b * conj(e) * (Gb * u_fb) / max(denom_b, eps);
            end

            Xhat_dd(k, l) = y_hat;
            decisions_dd(k, l) = d;
        end
    end

    rx_syms = Xhat_dd(data_idx).';
    if nargin < 5 || isempty(noise_var)
        noise_var = 1;
    end
    llr = square_qam_llr(rx_syms, cfg.modulation, noise_var);

    out = struct();
    out.Xhat_dd = Xhat_dd;
    out.decisions_dd = decisions_dd;
    out.llr = llr(:).';
    out.rx_syms = rx_syms;
    out.beam_filters = F;
    out.feedback_filter = B;
    out.train_count = train_count;
    out.num_beams = Q;
    out.params = pars;
end

function idx = local_ff_center_index(Kf, Lf)
    idx = Kf + 1; % column l itself, row center
    if Lf > 0
        idx = idx + 0 * (2 * Kf + 1);
    end
end

function u = local_ff_patch(Z, k, l, Kf, Lf)
    [N, M] = size(Z);
    u = zeros((2 * Kf + 1) * (Lf + 1), 1);
    t = 1;
    for dl = 0:Lf
        ll = mod(l - 1 + dl, M) + 1;
        for dk = -Kf:Kf
            kk = mod(k - 1 + dk, N) + 1;
            u(t) = Z(kk, ll);
            t = t + 1;
        end
    end
end

function offs = local_feedback_offsets(Kb, Lb)
    offs = [];
    for dl = 0:Lb
        for dk = -Kb:Kb
            if dl == 0 && dk == 0
                continue;
            end
            % only already-decided neighbourhood: same or previous delay
            if dl == 0 && dk > 0
                continue;
            end
            offs = [offs; dk, -dl]; %#ok<AGROW>
        end
    end
end

function u = local_fb_patch(D, k, l, offs)
    [N, M] = size(D);
    L = size(offs, 1);
    u = zeros(L, 1);
    for i = 1:L
        kk = mod(k - 1 + offs(i, 1), N) + 1;
        ll = mod(l - 1 + offs(i, 2), M) + 1;
        u(i) = D(kk, ll);
    end
end

function G = local_ipnlms_diag(w, alpha)
    w = w(:);
    L = numel(w);
    if L == 0
        G = zeros(0, 0);
        return;
    end
    absw = abs(w);
    s = sum(absw) + eps;
    g = ((1 - alpha) / (2 * L)) * ones(L, 1) + ((1 + alpha) / (2 * s)) * absw;
    G = diag(g);
end

function sym = local_hard_qam_symbol(x, M)
    bits = qam_demod(x, M, 'hard');
    sym = qam_mod(bits, M);
    sym = sym(1);
end

function v = local_get_field(s, name, default_v)
    v = default_v;
    if isstruct(s) && isfield(s, name)
        cand = s.(name);
        if isnumeric(cand) || islogical(cand)
            v = cand;
        end
    end
end

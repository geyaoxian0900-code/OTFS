function out = uwa_tf_beamforming_preprocess_otfs(cfg, freq_hz, Ytf_elem, beam_angles_deg)
%UWA_TF_BEAMFORMING_PREPROCESS_OTFS TF-domain R-to-Q beamforming for OTFS.
%
% This helper follows the beamforming-preprocessing idea of the 2025 OTFS
% UWA paper: perform DoA-based receive beamforming directly in the TF
% domain, reducing the element domain from R hydrophones to Q beam outputs.
%
% Input:
%   cfg            : project config (uses cfg.rx_array and sound speed)
%   freq_hz        : [Ka x 1] absolute frequency of each active subcarrier
%   Ytf_elem       : [Ka x M x R] element-domain TF data
%   beam_angles_deg: [1 x Q] beam directions
%
% Output struct fields:
%   Ztf            : [Ka x M x Q] beamformed TF-domain outputs
%   weights        : [Ka x R x Q] beamforming weights
%   beam_angles_deg, num_beams, num_elements

    arr = uwa_line_array_defaults(cfg);
    c = local_sound_speed(cfg);
    freq_hz = freq_hz(:);

    [Ka, Mtime, R] = size(Ytf_elem);
    Q = numel(beam_angles_deg);

    Ztf = zeros(Ka, Mtime, Q);
    W = zeros(Ka, R, Q);

    for q = 1:Q
        Aq = uwa_line_array_steering(freq_hz, R, arr.spacing_m, c, beam_angles_deg(q));
        for k = 1:Ka
            % Paper-consistent TF-domain beamforming coefficient:
            %   w_r = conj(a_r) / sqrt(R)
            w = conj(Aq(k, :).') / sqrt(max(R, 1));
            W(k, :, q) = w(:).';
            Xk = squeeze(Ytf_elem(k, :, :)); % [Mtime x R]
            Ztf(k, :, q) = Xk * w;
        end
    end

    out = struct();
    out.Ztf = Ztf;
    out.weights = W;
    out.beam_angles_deg = beam_angles_deg(:).';
    out.num_beams = Q;
    out.num_elements = R;
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

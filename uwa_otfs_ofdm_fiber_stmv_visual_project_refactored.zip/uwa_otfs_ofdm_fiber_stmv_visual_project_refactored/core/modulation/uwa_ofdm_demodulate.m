function Yf = uwa_ofdm_demodulate(rx, K, cp, M)

    L = K+cp;
    rx = reshape(rx(1:L*M), L, M);
    rx = rx(cp+1:end,:);
    Yf = fft(rx,K,1)/sqrt(K);
end

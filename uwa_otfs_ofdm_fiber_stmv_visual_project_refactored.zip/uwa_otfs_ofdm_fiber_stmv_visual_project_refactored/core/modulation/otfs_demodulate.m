function X_dd = otfs_demodulate(rx_vec, varargin)
%OTFS_DEMODULATE OTFS demodulation with backward-compatible interface
%
% Supported call styles:
%   X_dd = otfs_demodulate(rx_vec, N, M, cp_len)
%   X_dd = otfs_demodulate(rx_vec, otfs_cfg)
%
% otfs_cfg fields:
%   N, M, optional cp_len

    narginchk(2, 4);

    % Parse arguments
    if numel(varargin) == 1
        otfs_cfg = varargin{1};

        if ~isstruct(otfs_cfg)
            error('otfs_demodulate: second argument must be otfs_cfg struct or N.');
        end
        if ~isfield(otfs_cfg, 'N') || ~isfield(otfs_cfg, 'M')
            error('otfs_demodulate: otfs_cfg must contain fields N and M.');
        end

        N = otfs_cfg.N;
        M = otfs_cfg.M;

        if isfield(otfs_cfg, 'cp_len')
            cp_len = otfs_cfg.cp_len;
        else
            cp_len = 0;
        end

    elseif numel(varargin) == 3
        N = varargin{1};
        M = varargin{2};
        cp_len = varargin{3};

    else
        error('Use either otfs_demodulate(rx_vec, N, M, cp_len) or otfs_demodulate(rx_vec, otfs_cfg).');
    end

    expected_len = M * (N + cp_len);
    if numel(rx_vec) ~= expected_len
        msg = sprintf('otfs_demodulate: input length mismatch. Expected %d, got %d.', ...
                      expected_len, numel(rx_vec));
        error(msg);
    end

    rx_vec = rx_vec(:);

    % Reshape into OFDM symbols
    rx_with_cp = reshape(rx_vec, N + cp_len, M);

    % Remove CP
    if cp_len > 0
        rx_no_cp = rx_with_cp(cp_len+1:end, :);
    else
        rx_no_cp = rx_with_cp;
    end

    % Time -> TF
    rx_tf = fft(rx_no_cp, [], 1) / sqrt(N);

    % TF -> DD
    X_dd = fft(ifft(rx_tf, [], 2), [], 1);
end

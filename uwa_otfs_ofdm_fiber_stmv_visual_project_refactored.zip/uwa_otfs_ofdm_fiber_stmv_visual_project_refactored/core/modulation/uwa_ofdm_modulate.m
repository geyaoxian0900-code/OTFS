function tx = uwa_ofdm_modulate(Xf, K, cp)

    xt = ifft(Xf, K, 1)*sqrt(K);
    xt = [xt(end-cp+1:end,:); xt];
    tx = xt(:);
end

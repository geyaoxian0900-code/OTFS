function Ydd = uwa_otfs_demodulate(rx, cfg)
%UWA_OTFS_DEMODULATE 论文口径 OTFS 解调
% OFDM kernel -> TF(active) -> DD via unitary SFFT

    Yf = uwa_ofdm_demodulate(rx, cfg.fft_size, cfg.cp_otfs, cfg.num_symbols);

    idx = uwa_center_active_indices(cfg.fft_size, cfg.num_active_sc);
    Ytf = Yf(idx, :);

    N = cfg.Ndd;
    M = cfg.Mdd;

    % ===== unitary SFFT =====
    % 先沿 Doppler 维做 unitary IFFT，再沿 delay 维做 unitary FFT
    Ydd = fft(ifft(Ytf, [], 2) * sqrt(M), [], 1) / sqrt(N);
end

function Xdd = uwa_otfs_sfft(Xtf, cfg)
%UWA_OTFS_SFFT Unitary TF -> DD transform used in the project.
    Xdd = fft(ifft(Xtf, [], 2) * sqrt(cfg.Mdd), [], 1) / sqrt(cfg.Ndd);
end

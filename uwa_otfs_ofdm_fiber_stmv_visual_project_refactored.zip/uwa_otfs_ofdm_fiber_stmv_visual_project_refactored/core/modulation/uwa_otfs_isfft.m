function Xtf = uwa_otfs_isfft(Xdd, cfg)
%UWA_OTFS_ISFFT Unitary DD -> TF transform used in the project.
    Xtf = fft(ifft(Xdd, [], 1) * sqrt(cfg.Ndd), [], 2) / sqrt(cfg.Mdd);
end

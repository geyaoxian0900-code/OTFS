function tx_vec = otfs_modulate(X_dd, varargin)
%OTFS_MODULATE OTFS modulation with backward-compatible interface
%
% Supported call styles:
%   tx_vec = otfs_modulate(X_dd, N, M, cp_len)
%   tx_vec = otfs_modulate(X_dd, otfs_cfg)
%
% otfs_cfg fields:
%   N, M, optional cp_len

    narginchk(2, 4);

    % Parse arguments
    if numel(varargin) == 1
        otfs_cfg = varargin{1};

        if ~isstruct(otfs_cfg)
            error('otfs_modulate: second argument must be otfs_cfg struct or N.');
        end
        if ~isfield(otfs_cfg, 'N') || ~isfield(otfs_cfg, 'M')
            error('otfs_modulate: otfs_cfg must contain fields N and M.');
        end

        N = otfs_cfg.N;
        M = otfs_cfg.M;

        if isfield(otfs_cfg, 'cp_len')
            cp_len = otfs_cfg.cp_len;
        else
            cp_len = 0;
        end

    elseif numel(varargin) == 3
        N = varargin{1};
        M = varargin{2};
        cp_len = varargin{3};

    else
        error('Use either otfs_modulate(X_dd, N, M, cp_len) or otfs_modulate(X_dd, otfs_cfg).');
    end

    % Basic checks
    sz = size(X_dd);
    if numel(sz) ~= 2 || sz(1) ~= N || sz(2) ~= M
        msg = sprintf('otfs_modulate: X_dd size mismatch. Expected [%d x %d], got [%d x %d].', ...
                      N, M, sz(1), sz(2));
        error(msg);
    end

    % OTFS transform used in this project
    % DD -> TF
    tf_data = fft(ifft(X_dd, [], 1), [], 2);

    % TF -> time-domain OFDM symbols
    time_grid = ifft(tf_data, [], 1) * sqrt(N);

    % Add CP
    if cp_len > 0
        tx_with_cp = [time_grid(end-cp_len+1:end, :); time_grid];
    else
        tx_with_cp = time_grid;
    end

    % Serialize column-wise
    tx_vec = tx_with_cp(:);
end

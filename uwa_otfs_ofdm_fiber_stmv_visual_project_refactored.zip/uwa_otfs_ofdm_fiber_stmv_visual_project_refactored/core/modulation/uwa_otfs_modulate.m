function tx = uwa_otfs_modulate(Xdd, cfg)
%UWA_OTFS_MODULATE 论文口径 OTFS 调制
% DD -> TF(active) via unitary ISFFT
% TF(active) -> full FFT grid -> OFDM kernel

    N = cfg.Ndd;
    M = cfg.Mdd;

    if ~isequal(size(Xdd), [N, M])
        error('uwa_otfs_modulate: Xdd size mismatch.');
    end

    % ===== unitary ISFFT =====
    % 先沿 delay 维做 unitary IFFT，再沿 Doppler 维做 unitary FFT
    Xtf = fft(ifft(Xdd, [], 1) * sqrt(N), [], 2) / sqrt(M);

    % ===== map active TF grid into full OFDM FFT grid =====
    Xfull = zeros(cfg.fft_size, cfg.num_symbols);
    idx = uwa_center_active_indices(cfg.fft_size, cfg.num_active_sc);
    Xfull(idx, :) = Xtf;

    % ===== OFDM kernel =====
    tx = uwa_ofdm_modulate(Xfull, cfg.fft_size, cfg.cp_otfs);
end

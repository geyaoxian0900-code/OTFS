function Ytf = ofdm_demod_block(y, M, N, cp_len)
Ytf = zeros(M, N);

ptr = 1;
for n = 1:N
    blk = y(ptr+cp_len : ptr+cp_len+M-1);
    Ytf(:,n) = fft(blk, M) / sqrt(M);
    ptr = ptr + M + cp_len;
end
end

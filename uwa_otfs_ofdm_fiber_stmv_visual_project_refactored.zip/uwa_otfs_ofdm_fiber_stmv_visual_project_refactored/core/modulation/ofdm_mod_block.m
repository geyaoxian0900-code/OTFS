function x = ofdm_mod_block(Xtf, cp_len)
% Xtf: M x N
[M, N] = size(Xtf);
x = zeros((M+cp_len)*N, 1);

ptr = 1;
for n = 1:N
    s = ifft(Xtf(:,n), M) * sqrt(M);
    s_cp = [s(end-cp_len+1:end); s];
    x(ptr:ptr+M+cp_len-1) = s_cp;
    ptr = ptr + M + cp_len;
end
end

function A = uwa_line_array_steering(freq_hz, num_elements, spacing_m, sound_speed, angle_deg)
%UWA_LINE_ARRAY_STEERING Frequency-dependent steering vectors for a ULA.
%
% Input:
%   freq_hz     : [Ka x 1] absolute frequencies
%   num_elements: number of array elements
%   spacing_m   : element spacing
%   sound_speed : propagation speed
%   angle_deg   : arrival/steering angle in degrees
%
% Output:
%   A           : [Ka x num_elements] steering matrix
%
% Convention:
%   The Bellhop receiver angle is interpreted as an elevation / grazing
%   angle in the range-depth plane. For a vertical line array, the inter-
%   element delay is proportional to d * sin(theta) / c.

    if nargin < 5 || isempty(angle_deg)
        angle_deg = 0;
    end
    if nargin < 4 || isempty(sound_speed) || sound_speed <= 0
        sound_speed = 1500;
    end
    if nargin < 3 || isempty(spacing_m)
        spacing_m = 0;
    end
    if nargin < 2 || isempty(num_elements)
        num_elements = 1;
    end

    freq_hz = freq_hz(:);
    elem_idx = 0:(max(1, round(num_elements)) - 1);

    tau_elem = (spacing_m * sind(angle_deg) / max(sound_speed, eps)) * elem_idx;
    A = exp(-1j * 2*pi * (freq_hz * tau_elem));
end

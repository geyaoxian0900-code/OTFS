function scan = uwa_beam_scan_spectrum(cfg, freq_hz, array_tf, path_angles_deg, path_metric, scan_angles_deg, method)
%UWA_BEAM_SCAN_SPECTRUM Scan azimuth spectrum using selected beamformer.
%
% Input:
%   cfg            : project config
%   freq_hz        : [Ka x 1]
%   array_tf       : [Ka x M x E] element-domain TF data
%   path_angles_deg: physical path DOAs used to build adaptive covariance
%   path_metric    : path weights/powers used by STMV/improved STMV
%   scan_angles_deg: angles to scan
%   method         : 'cbf' | 'stmv' | 'improved_stmv'
%
% Output fields:
%   power_lin, power_db, scan_angles_deg, weight_norm_mean, method

    if nargin < 7 || isempty(method)
        method = cfg.rx_array.combine_method;
    end
    if nargin < 6 || isempty(scan_angles_deg)
        scan_angles_deg = -90:0.5:90;
    end

    arr = uwa_line_array_defaults(cfg);
    arr.combine_method = lower(strtrim(method));
    arr.steering_mode = 'manual';

    cfg_scan = cfg;
    cfg_scan.rx_array = arr;

    power_lin = zeros(1, numel(scan_angles_deg));
    weight_norm_mean = zeros(1, numel(scan_angles_deg));

    for ia = 1:numel(scan_angles_deg)
        cfg_scan.rx_array.steering_angle_deg = scan_angles_deg(ia);
        [~, bf] = uwa_line_array_path_response(cfg_scan, freq_hz, path_angles_deg, path_metric);
        Wfull = uwa_beamformer_extract_full_weights(bf);
        Ytf = uwa_apply_weights_to_array_tf(array_tf, Wfull);
        power_lin(ia) = mean(abs(Ytf(:)).^2);
        weight_norm_mean(ia) = mean(sqrt(sum(abs(Wfull).^2, 2)));
    end

    power_lin = max(power_lin, 0);
    power_db = 10 * log10(max(power_lin / max(max(power_lin), eps), 1e-12));

    scan = struct();
    scan.method = arr.combine_method;
    scan.scan_angles_deg = scan_angles_deg;
    scan.power_lin = power_lin;
    scan.power_db = power_db;
    scan.weight_norm_mean = weight_norm_mean;
end

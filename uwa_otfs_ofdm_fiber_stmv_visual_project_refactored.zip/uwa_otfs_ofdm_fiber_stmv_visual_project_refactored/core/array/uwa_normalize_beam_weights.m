function w = uwa_normalize_beam_weights(w, a0, do_normalize)
%UWA_NORMALIZE_BEAM_WEIGHTS Normalize weights to unit noise gain.
%
% The communication simulator injects noise after the effective channel.
% Therefore the array gain must appear in the effective channel itself.  A
% unit-norm weight vector makes CBF produce sqrt(M) amplitude gain in the
% steering direction, matching the usual M-fold power array gain.

    if nargin < 3
        do_normalize = true;
    end
    w = w(:);
    if ~do_normalize
        return;
    end
    nrm = norm(w);
    if isfinite(nrm) && nrm > 0
        w = w / nrm;
    end

    if nargin >= 2 && ~isempty(a0)
        ph = w' * a0(:);
        if abs(ph) > 0
            w = w * exp(1j * angle(ph));
        end
    end
end

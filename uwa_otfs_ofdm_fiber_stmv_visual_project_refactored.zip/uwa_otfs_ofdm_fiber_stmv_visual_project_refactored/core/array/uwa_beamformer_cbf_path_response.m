function [path_response, info] = uwa_beamformer_cbf_path_response(arr, freq_hz, sound_speed, path_angles_deg, steer_angle_deg)
%UWA_BEAMFORMER_CBF_PATH_RESPONSE Conventional frequency-domain beamformer.
%
% This is the delay-and-sum / CBF baseline from the papers.  It is robust
% and has low complexity, but weak interference suppression.

    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);
    P = numel(path_angles_deg);
    M = arr.num_elements;

    taper = uwa_array_taper(arr.window, M);
    path_response = zeros(Ka, P);
    weights = zeros(Ka, M);

    A0 = uwa_line_array_steering(freq_hz, M, arr.spacing_m, sound_speed, steer_angle_deg);
    for k = 1:Ka
        a0 = A0(k, :).';
        w = a0 .* taper(:);
        w = uwa_normalize_beam_weights(w, a0, arr.normalize_weights);
        weights(k, :) = w(:).';
        for p = 1:P
            ap = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, path_angles_deg(p));
            path_response(k, p) = w' * ap(:);
        end
    end

    info = struct();
    info.method = 'cbf';
    info.weights = weights;
    info.taper = taper;
    info.description = 'Conventional delay-and-sum beamforming baseline';
end

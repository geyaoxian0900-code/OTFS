function patt = uwa_beampattern_from_weights(cfg, freq_hz, Wfull, angle_grid_deg)
%UWA_BEAMPATTERN_FROM_WEIGHTS Evaluate beam pattern over angle grid.
%
% Output fields:
%   gain_lin, gain_db, angle_grid_deg, response

    if nargin < 4 || isempty(angle_grid_deg)
        angle_grid_deg = -90:0.5:90;
    end

    arr = uwa_line_array_defaults(cfg);
    c = local_sound_speed(cfg);
    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);
    E = arr.num_elements;
    if size(Wfull, 1) == 1 && Ka > 1
        Wfull = repmat(Wfull, Ka, 1);
    end

    gain_lin = zeros(1, numel(angle_grid_deg));
    response = zeros(Ka, numel(angle_grid_deg));

    for ia = 1:numel(angle_grid_deg)
        A = uwa_line_array_steering(freq_hz, E, arr.spacing_m, c, angle_grid_deg(ia));
        for k = 1:Ka
            response(k, ia) = conj(Wfull(k, :)) * A(k, :).';
        end
        gain_lin(ia) = mean(abs(response(:, ia)).^2);
    end

    gain_lin = gain_lin / max(max(gain_lin), eps);
    gain_db = 10 * log10(max(gain_lin, 1e-12));

    patt = struct();
    patt.angle_grid_deg = angle_grid_deg;
    patt.gain_lin = gain_lin;
    patt.gain_db = gain_db;
    patt.response = response;
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

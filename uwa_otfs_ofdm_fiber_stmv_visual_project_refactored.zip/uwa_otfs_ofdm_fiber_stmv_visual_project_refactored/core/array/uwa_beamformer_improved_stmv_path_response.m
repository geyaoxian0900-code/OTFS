function [path_response, info] = uwa_beamformer_improved_stmv_path_response(arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg)
%UWA_BEAMFORMER_IMPROVED_STMV_PATH_RESPONSE CBF-subarray + STMV beamformer.
%
% This implements the chosen paper beamformer at link-simulation level:
%   1) split the all-optical fibre receive line array into subarrays;
%   2) do CBF inside each subarray, producing lower-dimensional "new sensors";
%   3) run diagonally-loaded STMV/MVDR across the subarray outputs.
%
% This matches the CBF+STMV cascade idea: robust pre-beamforming, lower
% dimensional adaptive stage, and better multipath/interference suppression
% than pure CBF.

    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);
    P = numel(path_angles_deg);
    M = arr.num_elements;

    groups = uwa_subarray_groups(M, arr.subarray_partition, arr.subarray_overlap, arr.subarray_mode);
    Q = numel(groups);

    path_power = abs(path_metric(:)).^2;
    if ~any(isfinite(path_power)) || sum(path_power) <= 0
        path_power = ones(P, 1);
    end
    path_power = path_power / (sum(path_power) + eps);

    path_response = zeros(Ka, P);
    sub_weights = cell(Ka, Q);
    adaptive_weights = zeros(Ka, Q);
    loading_used = zeros(Ka, 1);

    for k = 1:Ka
        % Full steering vectors for all paths and desired direction.
        A = zeros(M, P);
        for p = 1:P
            A(:, p) = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, path_angles_deg(p)).';
        end
        a0_full = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, steer_angle_deg).';

        % CBF inside each subarray; B(:,p) is the subarray-output steering
        % vector for path p.
        B = zeros(Q, P);
        b0 = zeros(Q, 1);
        for q = 1:Q
            idx = groups{q};
            taper_q = uwa_array_taper(arr.window, numel(idx)).';
            a0_q = a0_full(idx);
            wq = a0_q .* taper_q;
            wq = uwa_normalize_beam_weights(wq, a0_q, true);
            sub_weights{k, q} = wq;
            b0(q) = wq' * a0_q;
            for p = 1:P
                B(q, p) = wq' * A(idx, p);
            end
        end

        use_power = path_power;
        if arr.exclude_steered_path_from_interference && steer_idx >= 1 && steer_idx <= P
            use_power(steer_idx) = 0;
        end
        R = zeros(Q, Q);
        for p = 1:P
            R = R + max(use_power(p), 0) * (B(:, p) * B(:, p)');
        end
        avg_diag = real(trace(R)) / max(Q, 1);
        diag_load = arr.diagonal_loading * max(avg_diag, arr.interference_power_floor);
        if diag_load <= 0
            diag_load = arr.interference_power_floor;
        end
        R = R + diag_load * eye(Q);
        loading_used(k) = diag_load;

        v = R \ b0;
        denom = b0' * v;
        if abs(denom) > 0
            v = v / denom;
        end
        v = uwa_normalize_beam_weights(v, b0, arr.normalize_weights);
        adaptive_weights(k, :) = v(:).';

        for p = 1:P
            path_response(k, p) = v' * B(:, p);
        end
    end

    info = struct();
    info.method = 'improved_stmv';
    info.groups = groups;
    info.num_subarrays = Q;
    info.subarray_partition = arr.subarray_partition;
    info.subarray_overlap = arr.subarray_overlap;
    info.subarray_mode = arr.subarray_mode;
    info.sub_weights = sub_weights;
    info.adaptive_weights = adaptive_weights;
    info.diagonal_loading = loading_used;
    info.description = 'Paper-selected CBF-subarray plus STMV cascade';
end

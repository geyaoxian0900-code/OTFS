function Wfull = uwa_beamformer_extract_full_weights(bf)
%UWA_BEAMFORMER_EXTRACT_FULL_WEIGHTS Recover full-array weights from bf info.
%
% Input:
%   bf    : beamformer info returned by uwa_line_array_path_response
%
% Output:
%   Wfull : [Ka x E] full-array complex weights, where each row stores the
%           column-vector weight as a row.  Beam output should be computed as
%           y = x * conj(w) for row-snapshot x.

    if nargin < 1 || isempty(bf) || ~isstruct(bf) || ~isfield(bf, 'enabled') || ~bf.enabled
        Wfull = 1;
        return;
    end

    E = bf.num_elements;
    method = lower(strtrim(bf.combine_method));

    if isfield(bf, 'method_info')
        info = bf.method_info;
    else
        info = struct();
    end

    switch method
        case {'cbf', 'mvdr', 'wicmv', 'stmv'}
            if isfield(info, 'weights') && ~isempty(info.weights)
                Wfull = info.weights;
            else
                Wfull = ones(1, E) / sqrt(max(E, 1));
            end

        case {'improved_stmv', 'improved-stmv', 'cbf_stmv', 'paper_improved_stmv'}
            Wfull = local_expand_improved_weights(bf, info, E);

        otherwise
            if isfield(info, 'weights') && ~isempty(info.weights)
                Wfull = info.weights;
            else
                Wfull = ones(1, E) / sqrt(max(E, 1));
            end
    end
end

function Wfull = local_expand_improved_weights(bf, info, E)
    if ~isfield(info, 'adaptive_weights') || isempty(info.adaptive_weights) || ...
            ~isfield(info, 'sub_weights') || isempty(info.sub_weights) || ...
            ~isfield(info, 'groups') || isempty(info.groups)
        Wfull = ones(1, E) / sqrt(max(E, 1));
        return;
    end

    groups = info.groups;
    V = info.adaptive_weights;
    [Ka, Q] = size(V);
    Wfull = zeros(Ka, E);

    for k = 1:Ka
        wk = zeros(E, 1);
        for q = 1:Q
            idx = groups{q};
            if k <= size(info.sub_weights, 1)
                wq = info.sub_weights{k, q};
            else
                wq = [];
            end
            if isempty(wq)
                continue;
            end
            wk(idx) = wk(idx) + V(k, q) * wq(:);
        end
        Wfull(k, :) = wk(:).';
    end

    if isfield(bf, 'normalize_weights') && bf.normalize_weights
        for k = 1:size(Wfull, 1)
            nrm = norm(Wfull(k, :));
            if nrm > 0
                Wfull(k, :) = Wfull(k, :) / nrm;
            end
        end
    end
end

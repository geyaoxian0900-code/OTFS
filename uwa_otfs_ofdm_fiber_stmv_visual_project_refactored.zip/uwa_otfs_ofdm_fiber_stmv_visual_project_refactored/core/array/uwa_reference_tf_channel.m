function Href = uwa_reference_tf_channel(ch)
%UWA_REFERENCE_TF_CHANNEL Reference TF channel for normalization / noise setup.
%
% When beamforming gain should be preserved relative to a single hydrophone,
% downstream noise calculations should use the pre-beamforming single-sensor
% TF channel as the reference.
%
% Input:
%   ch   : channel struct
%
% Output:
%   Href : [Ka x M] reference TF channel

    Href = ch.Htf_active;

    if isfield(ch, 'rx_array') && isstruct(ch.rx_array) && ...
            isfield(ch.rx_array, 'enabled') && ch.rx_array.enabled && ...
            isfield(ch.rx_array, 'preserve_array_gain') && ch.rx_array.preserve_array_gain && ...
            isfield(ch, 'Htf_single_active') && ~isempty(ch.Htf_single_active)
        Href = ch.Htf_single_active;
    end
end

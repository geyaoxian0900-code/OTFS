function [Htf_elem, meta] = uwa_build_element_channel_response(cfg, ch)
%UWA_BUILD_ELEMENT_CHANNEL_RESPONSE Element-wise TF channel responses.
%
% Input:
%   cfg : full config
%   ch  : channel realization from uwa_bellhop_prepare_frame_channel
%
% Output:
%   Htf_elem : [Ka x M x E] TF channel seen by each array element
%   meta     : auxiliary steering cube and array settings
%
% The stored ch.Hp_ft is path-resolved on the active TF grid.  This helper
% reconstructs the response of each hydrophone element by applying the
% frequency-dependent steering phase of each path.

    arr = uwa_line_array_defaults(cfg);
    freq_hz = ch.freq_hz(:);
    Ka = numel(freq_hz);
    M = numel(ch.time_s);
    E = arr.num_elements;
    P = size(ch.Hp_ft, 3);

    Htf_elem = zeros(Ka, M, E);
    steering_cube = zeros(Ka, E, P);

    if ~isfield(ch, 'path_angles_deg') || isempty(ch.path_angles_deg)
        path_angles_deg = zeros(1, P);
    else
        path_angles_deg = ch.path_angles_deg(:).';
        if numel(path_angles_deg) ~= P
            path_angles_deg = zeros(1, P);
        end
    end

    c = local_sound_speed(cfg);
    for p = 1:P
        A = uwa_line_array_steering(freq_hz, E, arr.spacing_m, c, path_angles_deg(p));
        steering_cube(:, :, p) = A;
        for e = 1:E
            Htf_elem(:, :, e) = Htf_elem(:, :, e) + ch.Hp_ft(:, :, p) .* repmat(A(:, e), 1, M);
        end
    end

    meta = struct();
    meta.freq_hz = freq_hz;
    meta.time_s = ch.time_s;
    meta.path_angles_deg = path_angles_deg;
    meta.steering_cube = steering_cube;
    meta.num_elements = E;
    meta.spacing_m = arr.spacing_m;
    meta.orientation = arr.orientation;
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

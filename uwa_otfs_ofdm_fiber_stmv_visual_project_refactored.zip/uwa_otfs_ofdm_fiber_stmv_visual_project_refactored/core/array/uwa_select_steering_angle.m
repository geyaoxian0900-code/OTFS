function [steer_angle_deg, steer_idx, steer_mode_used] = uwa_select_steering_angle(arr, path_angles_deg, path_metric)
%UWA_SELECT_STEERING_ANGLE Resolve array steering direction.

    mode = lower(strtrim(arr.steering_mode));
    if isempty(mode)
        mode = 'strongest';
    end

    switch mode
        case {'manual', 'fixed'}
            steer_angle_deg = double(arr.steering_angle_deg);
            steer_idx = 1;
            steer_mode_used = 'manual';

        case {'direct', 'earliest', 'first'}
            steer_idx = find(isfinite(path_angles_deg), 1, 'first');
            if isempty(steer_idx)
                steer_idx = 1;
            end
            steer_angle_deg = path_angles_deg(steer_idx);
            steer_mode_used = 'direct';

        otherwise
            [~, steer_idx] = max(abs(path_metric));
            if isempty(steer_idx) || steer_idx < 1
                steer_idx = 1;
            end
            steer_angle_deg = path_angles_deg(steer_idx);
            steer_mode_used = 'strongest';
    end

    if ~isfinite(steer_angle_deg)
        steer_angle_deg = 0;
    end
end

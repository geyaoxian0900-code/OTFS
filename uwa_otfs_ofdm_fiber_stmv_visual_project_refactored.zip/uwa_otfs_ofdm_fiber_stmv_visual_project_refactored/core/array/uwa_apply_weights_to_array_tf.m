function Ytf = uwa_apply_weights_to_array_tf(arrayTf, weightMatrix)
%UWA_APPLY_WEIGHTS_TO_ARRAY_TF Apply full-array beam weights on TF snapshots.
%
% Usage:
%   Ytf = uwa_apply_weights_to_array_tf(arrayTf, weightMatrix)
%
% Inputs:
%   arrayTf      - [Ka x M x E] element-domain TF data.
%   weightMatrix - [Ka x E] beam weights, row-wise. A [1 x E] row is
%                  expanded to all active subcarriers.
%
% Output:
%   Ytf          - [Ka x M] beamformed TF data.

    [numActiveSc, numSymbols, numElements] = size(arrayTf);
    if size(weightMatrix, 1) == 1 && numActiveSc > 1
        weightMatrix = repmat(weightMatrix, numActiveSc, 1);
    end
    if size(weightMatrix, 1) ~= numActiveSc || size(weightMatrix, 2) ~= numElements
        error('uwa_apply_weights_to_array_tf: size mismatch between arrayTf and weightMatrix.');
    end

    weightTensor = conj(reshape(weightMatrix, [numActiveSc, 1, numElements])); % [Refactor] 原因：将每个子载波对应的权值重排为可广播张量，便于用矩阵/向量化替代显式 for 循环。
    Ytf = sum(arrayTf .* weightTensor, 3); % [Refactor] 原因：向量化替代逐子载波循环，保持同一线性加权公式不变并减少解释器循环开销。

    if ~isequal(size(Ytf), [numActiveSc, numSymbols])
        error('uwa_apply_weights_to_array_tf: unexpected output size after beamforming.');
    end
end

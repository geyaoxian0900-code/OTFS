function [path_response, bf] = uwa_line_array_path_response(cfg, freq_hz, path_angles_deg, path_metric)
%UWA_LINE_ARRAY_PATH_RESPONSE Per-path receive responses after beamforming.
%
% The function is the single active beamforming gateway for the extracted
% project.  It supports CBF, MVDR, wideband incoherent MVDR (WICMV),
% STMV, and the selected paper-style improved STMV. Existing channel code
% still calls this function through
% uwa_apply_line_array_beamforming, so changing cfg.rx_array.combine_method
% cleanly changes the receive array model without touching the OTFS/OFDM
% transceiver.

    arr = uwa_line_array_defaults(cfg);
    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);

    if nargin < 3 || isempty(path_angles_deg)
        path_angles_deg = 0;
    end
    path_angles_deg = double(path_angles_deg(:).');
    P = numel(path_angles_deg);

    if nargin < 4 || isempty(path_metric)
        path_metric = ones(1, P);
    end
    path_metric = double(path_metric(:).');
    if numel(path_metric) ~= P
        path_metric = ones(1, P);
    end

    if P == 0
        path_response = zeros(Ka, 0);
        bf = local_empty_info(arr, Ka);
        return;
    end

    path_angles_deg(~isfinite(path_angles_deg)) = 0;
    path_metric(~isfinite(path_metric)) = 0;

    if ~arr.enabled || strcmpi(arr.combine_method, 'none')
        path_response = ones(Ka, P);
        bf = local_empty_info(arr, Ka);
        bf.enabled = false;
        bf.path_angles_deg = path_angles_deg;
        bf.path_metric = path_metric;
        bf.path_gain_lin = ones(1, P);
        return;
    end

    [steer_angle_deg, steer_idx, steer_mode_used] = ...
        uwa_select_steering_angle(arr, path_angles_deg, path_metric);

    sound_speed = local_sound_speed(cfg);
    switch lower(arr.combine_method)
        case {'cbf', 'das'}
            [path_response, method_info] = uwa_beamformer_cbf_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, steer_angle_deg);
            method_used = 'cbf';

        case {'mvdr', 'capon'}
            [path_response, method_info] = uwa_beamformer_mvdr_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);
            method_used = 'mvdr';

        case {'wicmv', 'wideband_mvdr', 'wideband-mvdr', 'wideband'}
            [path_response, method_info] = uwa_beamformer_wicmv_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);
            method_used = 'wicmv';

        case {'stmv'}
            [path_response, method_info] = uwa_beamformer_stmv_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);
            method_used = 'stmv';

        case {'improved_stmv', 'improved-stmv', 'cbf_stmv', 'paper_improved_stmv'}
            [path_response, method_info] = uwa_beamformer_improved_stmv_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);
            method_used = 'improved_stmv';

        otherwise
            warning('Unknown combine_method=%s. Falling back to improved_stmv.', arr.combine_method);
            [path_response, method_info] = uwa_beamformer_improved_stmv_path_response( ...
                arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);
            method_used = 'improved_stmv';
    end

    path_gain_lin = mean(abs(path_response).^2, 1);

    bf = struct();
    bf.enabled = true;
    bf.platform = arr.platform;
    bf.combine_method = method_used;
    bf.orientation = arr.orientation;
    bf.num_elements = arr.num_elements;
    bf.spacing_m = arr.spacing_m;
    bf.window = arr.window;
    bf.preserve_array_gain = logical(arr.preserve_array_gain);
    bf.steering_mode = steer_mode_used;
    bf.steering_angle_deg = steer_angle_deg;
    bf.steering_path_idx = steer_idx;
    bf.path_angles_deg = path_angles_deg;
    bf.path_metric = path_metric;
    bf.path_response = path_response;
    bf.path_gain_lin = path_gain_lin;
    bf.method_info = method_info;
end

function bf = local_empty_info(arr, Ka)
    bf = struct();
    bf.enabled = false;
    bf.platform = arr.platform;
    bf.combine_method = arr.combine_method;
    bf.orientation = arr.orientation;
    bf.num_elements = arr.num_elements;
    bf.spacing_m = arr.spacing_m;
    bf.window = arr.window;
    bf.preserve_array_gain = logical(arr.preserve_array_gain);
    bf.steering_mode = 'disabled';
    bf.steering_angle_deg = 0;
    bf.steering_path_idx = 1;
    bf.path_angles_deg = [];
    bf.path_metric = [];
    bf.path_response = [];
    bf.path_gain_lin = [];
    bf.weights = ones(Ka, 1);
    bf.taper = 1;
    bf.method_info = struct();
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

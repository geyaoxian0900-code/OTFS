function groups = uwa_subarray_groups(num_elements, partition, overlap, mode)
%UWA_SUBARRAY_GROUPS Build subarray index groups for improved STMV.
%
% partition may be a scalar number of subarrays or a vector containing the
% number of elements in each subarray.  The default mode is contiguous.

    if nargin < 2 || isempty(partition)
        partition = [4 4 4 4];
    end
    if nargin < 3 || isempty(overlap)
        overlap = 0;
    end
    if nargin < 4 || isempty(mode)
        mode = 'contiguous';
    end

    num_elements = max(1, round(num_elements));
    overlap = max(0, round(overlap));

    if isscalar(partition)
        q = max(1, round(partition));
        base = floor(num_elements / q);
        part = base * ones(1, q);
        part(end) = part(end) + num_elements - sum(part);
    else
        part = round(double(partition(:).'));
        part = part(part > 0);
        if isempty(part)
            part = num_elements;
        end
        if sum(part) ~= num_elements
            scale = num_elements / sum(part);
            part = max(1, round(part * scale));
            part(end) = part(end) + num_elements - sum(part);
        end
    end

    q = numel(part);
    groups = cell(1, q);

    switch lower(strtrim(mode))
        case {'interleaved', 'periodic'}
            for g = 1:q
                groups{g} = g:q:num_elements;
                if isempty(groups{g})
                    groups{g} = g;
                end
            end
        otherwise
            cursor = 1;
            for g = 1:q
                first_idx = max(1, cursor - overlap);
                last_idx = min(num_elements, cursor + part(g) - 1 + overlap);
                groups{g} = first_idx:last_idx;
                cursor = cursor + part(g);
            end
    end
end

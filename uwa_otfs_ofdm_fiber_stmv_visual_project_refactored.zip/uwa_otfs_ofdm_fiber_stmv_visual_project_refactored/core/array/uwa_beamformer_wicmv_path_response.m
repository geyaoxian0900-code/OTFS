function [path_response, info] = uwa_beamformer_wicmv_path_response(arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg)
%UWA_BEAMFORMER_WICMV_PATH_RESPONSE Wideband incoherent MVDR (WICMV).
%
% In the thesis, WICMV performs narrowband MVDR on each subband and then
% combines the subband outputs noncoherently across frequency. At the
% project path-response level we keep the per-frequency MVDR weights and let
% the downstream scan/power integration perform the noncoherent wideband
% combination.

    [path_response, info_mvdr] = uwa_beamformer_mvdr_path_response( ...
        arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg);

    info = info_mvdr;
    info.method = 'wicmv';
    info.description = ['Wideband incoherent MVDR: per-frequency MVDR ', ...
        'weights with noncoherent power integration across frequency'];
end

function fast = uwa_fast_cbf_fft_scan(cfg, array_tf, fft_len, scan_angles_deg)
%UWA_FAST_CBF_FFT_SCAN Fast approximate CBF scan using spatial FFT.
%
% This is a narrowband approximation around the array centre frequency.  It
% is intended as a fast educational algorithm for a ULA with near-uniform
% spacing.  The exact scan should still be preferred when the array is
% strongly broadband or when spacing departs from the FFT assumption.
%
% Input:
%   cfg            : project config
%   array_tf       : [Ka x M x E] element-domain TF data
%   fft_len        : spatial FFT length, default 2048
%   scan_angles_deg: optional target angle grid for interpolation
%
% Output fields:
%   angle_fft_deg, power_fft_db, scan_angles_deg, power_interp_db,
%   power_interp_lin

    if nargin < 3 || isempty(fft_len)
        fft_len = 2048;
    end
    if nargin < 4 || isempty(scan_angles_deg)
        scan_angles_deg = -90:0.5:90;
    end

    arr = uwa_line_array_defaults(cfg);
    [Ka, M, E] = size(array_tf);
    k0 = max(1, round((Ka + 1) / 2));

    Xc = squeeze(array_tf(k0, :, :)); % [M x E]
    Xc = Xc.';                        % [E x M]

    nfft = max(fft_len, E);
    S = fftshift(fft(Xc, nfft, 1), 1);
    power_fft = mean(abs(S).^2, 2);

    c = local_sound_speed(cfg);
    lambda0 = c / max(cfg.fc_hz, eps);
    alpha = arr.spacing_m / max(lambda0, eps); % d/lambda

    u = ((0:nfft-1) - floor(nfft/2)) / nfft;   % cycles / element
    sin_theta = u / max(alpha, eps);
    valid = abs(sin_theta) <= 1;
    angle_fft_deg = asind(max(min(sin_theta(valid), 1), -1));
    power_fft_valid = power_fft(valid);

    % Sort by angle to keep interpolation stable.
    [angle_fft_deg, ord] = sort(angle_fft_deg);
    power_fft_valid = power_fft_valid(ord);

    power_fft_valid = power_fft_valid / max(max(power_fft_valid), eps);
    power_fft_db = 10 * log10(max(power_fft_valid, 1e-12));

    power_interp_lin = interp1(angle_fft_deg, power_fft_valid, scan_angles_deg, 'linear', 1e-12);
    power_interp_lin = max(power_interp_lin, 1e-12);
    power_interp_lin = power_interp_lin / max(max(power_interp_lin), eps);
    power_interp_db = 10 * log10(power_interp_lin);

    fast = struct();
    fast.angle_fft_deg = angle_fft_deg;
    fast.power_fft_db = power_fft_db;
    fast.scan_angles_deg = scan_angles_deg;
    fast.power_interp_lin = power_interp_lin;
    fast.power_interp_db = power_interp_db;
    fast.center_bin_index = k0;
    fast.description = 'Spatial-FFT narrowband approximate CBF scan';
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

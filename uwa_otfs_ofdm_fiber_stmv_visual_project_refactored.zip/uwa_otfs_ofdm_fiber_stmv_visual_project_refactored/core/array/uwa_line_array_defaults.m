function arr = uwa_line_array_defaults(cfg)
%UWA_LINE_ARRAY_DEFAULTS Normalize receive line-array beamforming settings.
%
% Supported cfg fields include both cfg.rx_array and cfg.beamforming:
%   enabled, platform, num_elements/num_sensors, spacing_m/element_spacing_m,
%   orientation, combine_method, steering_mode, steering_angle_deg,
%   preserve_array_gain, window, diagonal_loading, subarray_partition,
%   subarray_overlap, subarray_mode, normalize_weights.
%
% combine_method:
%   'none'          : no array combining
%   'das' / 'cbf'   : conventional delay-and-sum / CBF
%   'mvdr'          : narrowband MVDR/Capon per frequency
%   'wicmv'         : wideband incoherent MVDR (subband MVDR + noncoherent integration)
%   'stmv'          : steered minimum-variance beamformer
%   'improved_stmv' : paper-style CBF subarrays + STMV across subarrays

    arr = struct();
    arr.enabled = false;
    arr.platform = 'generic_hydrophone_array';
    arr.num_elements = 1;
    arr.spacing_m = [];
    arr.orientation = 'vertical';
    arr.combine_method = 'improved_stmv';
    arr.candidate_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};
    arr.steering_mode = 'strongest';
    arr.steering_angle_deg = 0;
    arr.preserve_array_gain = true;
    arr.window = 'uniform';
    arr.diagonal_loading = 1e-2;
    arr.interference_power_floor = 1e-4;
    arr.exclude_steered_path_from_interference = true;
    arr.subarray_partition = [4 4 4 4];
    arr.subarray_overlap = 0;
    arr.subarray_mode = 'contiguous';
    arr.normalize_weights = true;

    if nargin < 1 || isempty(cfg)
        cfg = struct();
    end

    fc_hz = local_get_scalar(cfg, {'fc_hz', 'center_freq_hz'}, 4000);
    c = local_get_scalar(cfg, {'sound_speed'}, 1500);
    lambda0 = c / max(fc_hz, eps);
    arr.spacing_m = lambda0 / 2;

    user_cfg = struct();
    if isfield(cfg, 'rx_array') && isstruct(cfg.rx_array)
        user_cfg = cfg.rx_array;
    elseif isfield(cfg, 'beamforming') && isstruct(cfg.beamforming)
        user_cfg = cfg.beamforming;
    end

    if isfield(user_cfg, 'num_sensors') && ~isfield(user_cfg, 'num_elements')
        user_cfg.num_elements = user_cfg.num_sensors;
    end
    if isfield(user_cfg, 'element_spacing_m') && ~isfield(user_cfg, 'spacing_m')
        user_cfg.spacing_m = user_cfg.element_spacing_m;
    end
    if isfield(user_cfg, 'steer_angle_deg') && ~isfield(user_cfg, 'steering_angle_deg')
        user_cfg.steering_angle_deg = user_cfg.steer_angle_deg;
    end
    if isfield(user_cfg, 'method') && ~isfield(user_cfg, 'combine_method')
        user_cfg.combine_method = user_cfg.method;
    end

    fns = fieldnames(user_cfg);
    for k = 1:numel(fns)
        arr.(fns{k}) = user_cfg.(fns{k});
    end

    arr.num_elements = max(1, round(double(arr.num_elements)));
    arr.spacing_m = max(double(arr.spacing_m), 0);
    arr.enabled = logical(arr.enabled) && arr.num_elements > 1 && arr.spacing_m > 0;

    arr.combine_method = lower(strtrim(char(arr.combine_method)));
    if strcmp(arr.combine_method, 'das')
        arr.combine_method = 'cbf';
    end
    if isempty(arr.combine_method)
        arr.combine_method = 'improved_stmv';
    end
    if isempty(arr.steering_mode)
        arr.steering_mode = 'strongest';
    end
    if isempty(arr.window)
        arr.window = 'uniform';
    end
    if isempty(arr.orientation)
        arr.orientation = 'vertical';
    end
    if isempty(arr.subarray_partition)
        arr.subarray_partition = local_default_partition(arr.num_elements);
    end
    arr.diagonal_loading = max(double(arr.diagonal_loading), 0);
    arr.interference_power_floor = max(double(arr.interference_power_floor), 0);
    arr.subarray_overlap = max(0, round(double(arr.subarray_overlap)));
    arr.normalize_weights = logical(arr.normalize_weights);
end

function part = local_default_partition(num_elements)
    if num_elements <= 4
        part = num_elements;
    else
        q = 4;
        base = floor(num_elements / q);
        part = base * ones(1, q);
        part(end) = part(end) + num_elements - sum(part);
    end
end

function v = local_get_scalar(cfg, names, v_default)
    v = v_default;
    for i = 1:numel(names)
        name = names{i};
        if isfield(cfg, name)
            cand = cfg.(name);
            if isnumeric(cand) && isscalar(cand) && isfinite(cand)
                v = cand;
                return;
            end
        end
    end
end

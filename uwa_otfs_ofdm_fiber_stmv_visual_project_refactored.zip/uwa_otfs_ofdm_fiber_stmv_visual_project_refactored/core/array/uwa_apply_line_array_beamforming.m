function [HtfEff, beamformingInfo] = uwa_apply_line_array_beamforming(cfg, freqHz, HpFt, pathAnglesDeg, pathMetric)
%UWA_APPLY_LINE_ARRAY_BEAMFORMING Combine per-path TF contributions.
%
% Active methods are selected only by configuration:
%   cfg.rx_array.combine_method = 'cbf' | 'stmv' | 'improved_stmv'
%
% The default in this package is improved STMV, replacing the former pure
% delay-and-sum beamforming while keeping the downstream OTFS/OFDM API
% unchanged.
%
% Inputs:
%   cfg           - Configuration struct.
%   freqHz        - Active-subcarrier frequency vector.
%   HpFt          - [Ka x M x P] per-path TF contribution tensor.
%   pathAnglesDeg - Path arrival angles in degrees.
%   pathMetric    - Optional path metric/weight vector.
%
% Outputs:
%   HtfEff          - [Ka x M] effective beamformed TF channel.
%   beamformingInfo - Auxiliary beamformer information struct.

    if nargin < 5
        pathMetric = [];
    end

    [numActiveSc, numSymbols, numPaths] = size(HpFt);

    if numPaths == 0
        HtfEff = zeros(numActiveSc, numSymbols);
        beamformingInfo = struct();
        beamformingInfo.enabled = false;
        return;
    end

    [pathResponse, beamformingInfo] = uwa_line_array_path_response(cfg, freqHz, pathAnglesDeg, pathMetric);
    pathResponseTensor = reshape(pathResponse, [numActiveSc, 1, numPaths]); % [Refactor] 原因：将路径响应扩展为三维张量，便于直接与每条路径的 TF 响应逐元素相乘。
    HtfEff = sum(HpFt .* pathResponseTensor, 3); % [Refactor] 原因：向量化替代按路径累加的显式循环，不改变路径叠加公式。
end

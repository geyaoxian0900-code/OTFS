function [path_response, info] = uwa_beamformer_mvdr_path_response(arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg)
%UWA_BEAMFORMER_MVDR_PATH_RESPONSE Narrowband MVDR/Capon per frequency.
%
% This function implements the classic narrowband MVDR/Capon beamformer on
% every active frequency. In the project it serves two purposes:
%   1) explicit MVDR support in the beamformer family sweep;
%   2) the narrowband building block of the wideband incoherent MVDR path.
%
% The covariance is built from Bellhop/statistical path manifolds so that
% the link-level simulator can stay lightweight while preserving the main
% angle-domain behaviour of MVDR.

    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);
    P = numel(path_angles_deg);
    M = arr.num_elements;

    path_power = abs(path_metric(:)).^2;
    if ~any(isfinite(path_power)) || sum(path_power) <= 0
        path_power = ones(P, 1);
    end
    path_power = path_power / (sum(path_power) + eps);

    path_response = zeros(Ka, P);
    weights = zeros(Ka, M);
    loading_used = zeros(Ka, 1);

    for k = 1:Ka
        A = zeros(M, P);
        for p = 1:P
            A(:, p) = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, path_angles_deg(p)).';
        end
        a0 = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, steer_angle_deg).';

        use_power = path_power;
        if arr.exclude_steered_path_from_interference && steer_idx >= 1 && steer_idx <= P
            use_power(steer_idx) = 0;
        end

        R = zeros(M, M);
        for p = 1:P
            R = R + max(use_power(p), 0) * (A(:, p) * A(:, p)');
        end
        avg_diag = real(trace(R)) / max(M, 1);
        diag_load = arr.diagonal_loading * max(avg_diag, arr.interference_power_floor);
        if diag_load <= 0
            diag_load = arr.interference_power_floor;
        end
        R = R + diag_load * eye(M);
        loading_used(k) = diag_load;

        w = R \ a0;
        denom = a0' * w;
        if abs(denom) > 0
            w = w / denom;
        end
        w = uwa_normalize_beam_weights(w, a0, arr.normalize_weights);
        weights(k, :) = w(:).';

        for p = 1:P
            path_response(k, p) = w' * A(:, p);
        end
    end

    info = struct();
    info.method = 'mvdr';
    info.weights = weights;
    info.diagonal_loading = loading_used;
    info.description = 'Per-frequency narrowband MVDR/Capon beamformer';
end

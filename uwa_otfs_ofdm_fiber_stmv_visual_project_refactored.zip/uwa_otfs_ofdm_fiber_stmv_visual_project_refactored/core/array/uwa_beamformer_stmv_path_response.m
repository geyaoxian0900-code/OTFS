function [path_response, info] = uwa_beamformer_stmv_path_response(arr, freq_hz, sound_speed, path_angles_deg, path_metric, steer_idx, steer_angle_deg)
%UWA_BEAMFORMER_STMV_PATH_RESPONSE Steered minimum-variance beamformer.
%
% Approximate project-level STMV implementation:
%   - presteer the array to the desired angle using T(theta);
%   - build a steered covariance from path manifolds in that domain;
%   - solve the minimum-variance beamformer with a distortionless response
%     to the presteered all-ones desired vector.
%
% This keeps STMV distinct from the standard MVDR/Capon beamformer while
% remaining lightweight enough for end-to-end OTFS/OFDM Monte-Carlo runs.

    freq_hz = freq_hz(:);
    Ka = numel(freq_hz);
    P = numel(path_angles_deg);
    M = arr.num_elements;

    path_power = abs(path_metric(:)).^2;
    if ~any(isfinite(path_power)) || sum(path_power) <= 0
        path_power = ones(P, 1);
    end
    path_power = path_power / (sum(path_power) + eps);

    path_response = zeros(Ka, P);
    weights = zeros(Ka, M);
    loading_used = zeros(Ka, 1);

    one_vec = ones(M, 1);

    for k = 1:Ka
        A = zeros(M, P);
        for p = 1:P
            A(:, p) = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, path_angles_deg(p)).';
        end
        a0 = uwa_line_array_steering(freq_hz(k), M, arr.spacing_m, sound_speed, steer_angle_deg).';
        T0 = diag(conj(a0));

        use_power = path_power;
        if arr.exclude_steered_path_from_interference && steer_idx >= 1 && steer_idx <= P
            use_power(steer_idx) = 0;
        end

        Rstcm = zeros(M, M);
        Yp = zeros(M, P);
        for p = 1:P
            Yp(:, p) = T0 * A(:, p);
            Rstcm = Rstcm + max(use_power(p), 0) * (Yp(:, p) * Yp(:, p)');
        end
        avg_diag = real(trace(Rstcm)) / max(M, 1);
        diag_load = arr.diagonal_loading * max(avg_diag, arr.interference_power_floor);
        if diag_load <= 0
            diag_load = arr.interference_power_floor;
        end
        Rstcm = Rstcm + diag_load * eye(M);
        loading_used(k) = diag_load;

        v = Rstcm \ one_vec;
        denom = one_vec' * v;
        if abs(denom) > 0
            v = v / denom;
        end

        % Map back to a full-array weight so that beam patterns and array-TF
        % application remain compatible with the rest of the project.
        w = diag(a0) * v;
        w = uwa_normalize_beam_weights(w, a0, arr.normalize_weights);
        weights(k, :) = w(:).';

        for p = 1:P
            path_response(k, p) = w' * A(:, p);
        end
    end

    info = struct();
    info.method = 'stmv';
    info.weights = weights;
    info.diagonal_loading = loading_used;
    info.description = 'Steered-covariance minimum-variance beamformer (project approximation)';
end

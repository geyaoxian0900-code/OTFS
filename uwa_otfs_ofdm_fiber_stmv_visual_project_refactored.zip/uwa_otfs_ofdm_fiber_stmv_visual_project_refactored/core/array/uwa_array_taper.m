function taper = uwa_array_taper(window_name, num_elements)
%UWA_ARRAY_TAPER Make a unit-norm amplitude taper.

    num_elements = max(1, round(num_elements));
    n = 0:(num_elements-1);

    switch lower(strtrim(window_name))
        case {'hann', 'hanning'}
            if num_elements == 1
                taper = 1;
            else
                taper = 0.5 - 0.5*cos(2*pi*n/(num_elements-1));
            end
        case 'hamming'
            if num_elements == 1
                taper = 1;
            else
                taper = 0.54 - 0.46*cos(2*pi*n/(num_elements-1));
            end
        otherwise
            taper = ones(1, num_elements);
    end

    taper = taper(:).' / sqrt(sum(abs(taper).^2) + eps);
end

function uwa_plot_beamformer_selection(all_results, methods, out_dir, mode)
%UWA_PLOT_BEAMFORMER_SELECTION Plot OTFS BER/PER across beamformers.
%
% Paper-style helper used by run_beamformer_selection_experiment. It compares
% OTFS performance under CBF, MVDR, WICMV, STMV, and improved-STMV while keeping
% the rest of the link fixed.

    if nargin < 4 || isempty(mode)
        mode = 'quick';
    end
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end

    cfg = default_plot_config();

    fig1 = figure('Color', 'w', 'Position', [100 100 900 650]);
    ax1 = axes(fig1); %#ok<LAXES>
    hold(ax1, 'on'); grid(ax1, 'on'); box(ax1, 'on');
    set_paper_axes_style(ax1, cfg);

    legends = {};
    for i = 1:numel(all_results)
        r = all_results{i};
        y = safe_log_data(r.ber_otfs(1, :), cfg.ber_floor);
        semilogy(ax1, r.snr_dB_list, y, pick_style(cfg.styles, i), ...
            'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
        legends{end+1} = sprintf('OTFS + %s', prettify_method(methods{i})); %#ok<AGROW>
    end
    xlabel(ax1, 'SNR (dB)', 'FontName', cfg.font_name, 'FontSize', cfg.label_font_size);
    ylabel(ax1, 'BER', 'FontName', cfg.font_name, 'FontSize', cfg.label_font_size);
    title(ax1, 'OTFS BER Comparison with Different Beamformers', ...
        'FontName', cfg.font_name, 'FontSize', cfg.title_font_size, 'FontWeight', 'normal');
    legend(ax1, legends, 'Location', 'southwest', 'Interpreter', 'none', ...
        'FontName', cfg.font_name, 'FontSize', cfg.legend_font_size);
    ylim(ax1, [cfg.ber_floor, 1]);
    save_figure_pair(fig1, fullfile(out_dir, ['beamformer_selection_otfs_ber_' mode]), cfg.export_dpi);

    fig2 = figure('Color', 'w', 'Position', [120 120 900 650]);
    ax2 = axes(fig2); %#ok<LAXES>
    hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
    set_paper_axes_style(ax2, cfg);

    legends = {};
    for i = 1:numel(all_results)
        r = all_results{i};
        y = safe_log_data(r.per_otfs(1, :), cfg.per_floor);
        semilogy(ax2, r.snr_dB_list, y, pick_style(cfg.styles, i), ...
            'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
        legends{end+1} = sprintf('OTFS + %s', prettify_method(methods{i})); %#ok<AGROW>
    end
    xlabel(ax2, 'SNR (dB)', 'FontName', cfg.font_name, 'FontSize', cfg.label_font_size);
    ylabel(ax2, 'PER', 'FontName', cfg.font_name, 'FontSize', cfg.label_font_size);
    title(ax2, 'OTFS PER Comparison with Different Beamformers', ...
        'FontName', cfg.font_name, 'FontSize', cfg.title_font_size, 'FontWeight', 'normal');
    legend(ax2, legends, 'Location', 'southwest', 'Interpreter', 'none', ...
        'FontName', cfg.font_name, 'FontSize', cfg.legend_font_size);
    ylim(ax2, [cfg.per_floor, 1]);
    save_figure_pair(fig2, fullfile(out_dir, ['beamformer_selection_otfs_per_' mode]), cfg.export_dpi);
end

function cfg = default_plot_config()
    cfg.font_name = 'Times New Roman';
    cfg.title_font_size = 15;
    cfg.label_font_size = 14;
    cfg.axis_font_size = 12;
    cfg.legend_font_size = 11;
    cfg.line_width = 1.8;
    cfg.marker_size = 7;
    cfg.axis_line_width = 1.0;
    cfg.export_dpi = 300;
    cfg.ber_floor = 1e-5;
    cfg.per_floor = 1e-3;
    cfg.styles = {'-o', '--s', '-.^', ':d', '-v', '-->'};
end

function set_paper_axes_style(ax, cfg)
    set(ax, 'FontName', cfg.font_name, 'FontSize', cfg.axis_font_size, ...
        'LineWidth', cfg.axis_line_width, 'YScale', 'log', 'Layer', 'top');
end

function y = safe_log_data(x, floor_val)
    y = x;
    y(~isfinite(y)) = floor_val;
    y(y <= 0) = floor_val;
end

function s = pick_style(style_list, idx)
    n = numel(style_list);
    s = style_list{mod(idx - 1, n) + 1};
end

function name = prettify_method(name)
    name = strrep(char(name), '_', '-');
    if strcmpi(name, 'improved-stmv')
        name = 'Improved-STMV';
    elseif strcmpi(name, 'stmv')
        name = 'STMV';
    elseif strcmpi(name, 'wicmv')
        name = 'WICMV';
    elseif strcmpi(name, 'mvdr')
        name = 'MVDR';
    elseif strcmpi(name, 'cbf')
        name = 'CBF';
    end
end

function save_figure_pair(fig, stem, dpi)
    try
        exportgraphics(fig, [stem '.png'], 'Resolution', dpi);
    catch
        try
            print(fig, [stem '.png'], '-dpng', ['-r' num2str(dpi)]);
        catch
            saveas(fig, [stem '.png']);
        end
    end
    try
        savefig(fig, [stem '.fig']);
    catch
    end
end

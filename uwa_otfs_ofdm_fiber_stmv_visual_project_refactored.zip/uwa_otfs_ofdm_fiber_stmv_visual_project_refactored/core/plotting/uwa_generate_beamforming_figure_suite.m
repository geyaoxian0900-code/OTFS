function manifest = uwa_generate_beamforming_figure_suite(vis, out_dir)
%UWA_GENERATE_BEAMFORMING_FIGURE_SUITE Generate array / beamforming figures.
%
% Covered figure categories:
%   1) fibre-array beam pointing pattern
%   2) beam azimuth pattern / scan azimuth spectrum
%   3) 0-degree beam output spectrum
%   4) full-array / subarray scan spectra
%   5) full-array / subarray output spectra
%   6) element-1 zeroed processing result
%   7) pure-signal beam scan spectrum
%   8) array gain versus direction
%   9) CBF weight-vector norm
%  10) spacing sweep beam patterns
%  11) different arrival-angle cases
%  12) fast beamforming algorithm comparison
%  13) CBF/MVDR/WICMV/STMV/improved-STMV scan comparison
%  14) CBF/MVDR/WICMV/STMV/improved-STMV output-spectrum comparison

    if nargin < 2 || isempty(out_dir)
        out_dir = fullfile(vis.cfg.output_dir, vis.cfg.visual.figure_root_name, vis.cfg.visual.beam_subdir);
    end
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end

    manifest = struct('name', {}, 'png', {}, 'fig', {}, 'description', {});
    cfg = vis.cfg;
    scan_angles = cfg.visual.scan_angles_deg;
    gain_angles = cfg.visual.direction_gain_angles_deg;
    path_angles = vis.channel.path_angles_deg;
    path_metric = abs(vis.channel.hp_ls(:)).';
    freq_hz = vis.channel.freq_hz(:);
    dpi = cfg.visual.export_dpi;

    % Representative noisy array data for data-driven beam scanning.
    array_tf_noisy = vis.ofdm.Ytf_elem_noisy;
    array_tf_clean = vis.array.probe_elem_tf_clean;

    % ------------------------------------------------------------------
    % 1) Beam pointing pattern of the selected fibre-array beamformer
    % ------------------------------------------------------------------
    bf_weights = vis.array.weights_full;
    patt = uwa_beampattern_from_weights(cfg, freq_hz, bf_weights, gain_angles);
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(patt.angle_grid_deg, patt.gain_db, 'LineWidth', 1.4);
    hold on; grid on; box on;
    ylm = [-60 5];
    for p = 1:numel(path_angles)
        local_add_vertical_marker(path_angles(p), ylm, '--');
    end
    local_add_vertical_marker(cfg.visual.beam_pointing_angle_deg, ylm, ':');
    xlabel('Angle (deg)'); ylabel('Normalized gain (dB)');
    title('Fibre-array beam pointing pattern', 'Interpreter', 'none');
    ylim([-60 5]);
    manifest(end+1) = local_finalize(fig, out_dir, 'beam_pointing_pattern', ...
        'Selected beamformer pointing pattern with physical path-angle markers.', dpi);

    % ------------------------------------------------------------------
    % 2) Beam scan azimuth spectrum (selected beamformer, noisy data)
    % ------------------------------------------------------------------
    scan_sel = uwa_beam_scan_spectrum(cfg, freq_hz, array_tf_noisy, path_angles, path_metric, ...
        scan_angles, cfg.rx_array.combine_method);
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(scan_sel.scan_angles_deg, scan_sel.power_db, 'LineWidth', 1.3);
    grid on; box on; xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title(sprintf('Beam scan azimuth spectrum (%s)', cfg.rx_array.combine_method), 'Interpreter', 'none');
    ylim([-60 5]);
    manifest(end+1) = local_finalize(fig, out_dir, 'beam_scan_spectrum', ...
        'Data-driven scan spectrum using the selected beamformer.', dpi);

    % ------------------------------------------------------------------
    % 3) 0-degree beam output spectrum
    % ------------------------------------------------------------------
    [w0, ~] = local_weights_for_angle(cfg, freq_hz, path_angles, path_metric, 0, []);
    Y0 = uwa_apply_weights_to_array_tf(array_tf_noisy, w0);
    [f_axis, p0_db] = local_tf_output_spectrum(freq_hz, Y0);
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(f_axis, p0_db, 'LineWidth', 1.3);
    grid on; box on; xlabel('Frequency (Hz)'); ylabel('Relative output power (dB)');
    title('0-degree beam output spectrum', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'beam_output_spectrum_0deg', ...
        'Beamformed output spectrum when the beam is steered to 0 degree.', dpi);

    % ------------------------------------------------------------------
    % 4) Full array / different subarray scan spectra
    % ------------------------------------------------------------------
    fig = figure('Color', 'w', 'Position', [100 100 860 440], 'Visible', 'off');
    hold on; grid on; box on;
    labels = cfg.visual.subarray_labels;
    for i = 1:numel(cfg.visual.subarray_partitions)
        part = cfg.visual.subarray_partitions{i};
        cfg_i = local_cfg_partition(cfg, part);
        scan_i = uwa_beam_scan_spectrum(cfg_i, freq_hz, array_tf_noisy, path_angles, path_metric, ...
            scan_angles, 'improved_stmv');
        plot(scan_i.scan_angles_deg, scan_i.power_db, 'LineWidth', 1.15, 'DisplayName', labels{i});
    end
    xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('Full array / different subarray scan spectra', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best');
    manifest(end+1) = local_finalize(fig, out_dir, 'subarray_scan_spectrum_compare', ...
        'Compare azimuth scan spectra for full-array and different subarray partitions.', dpi);

    % ------------------------------------------------------------------
    % 5) Full array / different subarray beam output spectra
    % ------------------------------------------------------------------
    fig = figure('Color', 'w', 'Position', [100 100 860 440], 'Visible', 'off');
    hold on; grid on; box on;
    for i = 1:numel(cfg.visual.subarray_partitions)
        part = cfg.visual.subarray_partitions{i};
        cfg_i = local_cfg_partition(cfg, part);
        [Wi, ~] = local_weights_for_angle(cfg_i, freq_hz, path_angles, path_metric, 0, part);
        Yi = uwa_apply_weights_to_array_tf(array_tf_noisy, Wi);
        [fi, pi_db] = local_tf_output_spectrum(freq_hz, Yi);
        plot(fi, pi_db, 'LineWidth', 1.15, 'DisplayName', labels{i});
    end
    xlabel('Frequency (Hz)'); ylabel('Relative output power (dB)');
    title('Full array / different subarray beam output spectra', 'Interpreter', 'none');
    legend('Location', 'best');
    manifest(end+1) = local_finalize(fig, out_dir, 'subarray_output_spectrum_compare', ...
        'Compare output spectra for full-array and different subarray partitions.', dpi);

    % ------------------------------------------------------------------
    % 6) Element-1 zeroed processing result
    % ------------------------------------------------------------------
    array_zero = array_tf_noisy;
    zero_idx = cfg.visual.zeroed_element_index;
    if zero_idx >= 1 && zero_idx <= size(array_zero, 3)
        array_zero(:, :, zero_idx) = 0;
    end
    scan_zero = uwa_beam_scan_spectrum(cfg, freq_hz, array_zero, path_angles, path_metric, ...
        scan_angles, cfg.rx_array.combine_method);
    Yzero = uwa_apply_weights_to_array_tf(array_zero, w0);
    [fz, pz_db] = local_tf_output_spectrum(freq_hz, Yzero);
    fig = figure('Color', 'w', 'Position', [100 100 920 720], 'Visible', 'off');
    subplot(2,1,1);
    plot(scan_sel.scan_angles_deg, scan_sel.power_db, 'LineWidth', 1.2, 'DisplayName', 'Normal');
    hold on; plot(scan_zero.scan_angles_deg, scan_zero.power_db, 'LineWidth', 1.2, 'DisplayName', 'Element #1 zeroed');
    grid on; box on; xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('Azimuth spectrum with element #1 zeroed', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best');
    subplot(2,1,2);
    plot(f_axis, p0_db, 'LineWidth', 1.2, 'DisplayName', 'Normal');
    hold on; plot(fz, pz_db, 'LineWidth', 1.2, 'DisplayName', 'Element #1 zeroed');
    grid on; box on; xlabel('Frequency (Hz)'); ylabel('Relative output power (dB)');
    title('0-degree beam output spectrum with element #1 zeroed', 'Interpreter', 'none');
    legend('Location', 'best');
    manifest(end+1) = local_finalize(fig, out_dir, 'element1_zeroed_result', ...
        'Effect of zeroing the first array element on azimuth spectrum and output spectrum.', dpi);

    % ------------------------------------------------------------------
    % 7) Pure-signal beam scan spectrum
    % ------------------------------------------------------------------
    scan_pure = uwa_beam_scan_spectrum(cfg, freq_hz, array_tf_clean, path_angles, path_metric, ...
        scan_angles, cfg.rx_array.combine_method);
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(scan_pure.scan_angles_deg, scan_pure.power_db, 'LineWidth', 1.3);
    grid on; box on; xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('Pure-signal beam scan azimuth spectrum', 'Interpreter', 'none');
    ylim([-60 5]);
    manifest(end+1) = local_finalize(fig, out_dir, 'pure_signal_scan_spectrum', ...
        'Scan spectrum computed from clean array data without additive noise.', dpi);

    % ------------------------------------------------------------------
    % 8) Array gain versus direction
    % ------------------------------------------------------------------
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(patt.angle_grid_deg, patt.gain_db, 'LineWidth', 1.3);
    grid on; box on; xlabel('Direction angle (deg)'); ylabel('Array gain (dB)');
    title('Array gain versus direction', 'Interpreter', 'none');
    ylim([-60 5]);
    manifest(end+1) = local_finalize(fig, out_dir, 'array_gain_vs_direction', ...
        'Directional gain of the selected beamformer.', dpi);

    % ------------------------------------------------------------------
    % 9) Conventional beamformer weight-vector norm
    % ------------------------------------------------------------------
    cbf_norm = zeros(1, numel(scan_angles));
    for ia = 1:numel(scan_angles)
        [Wcbf, ~] = local_weights_for_angle(cfg, freq_hz, path_angles, path_metric, scan_angles(ia), [], 'cbf');
        cbf_norm(ia) = mean(sqrt(sum(abs(Wcbf).^2, 2)));
    end
    fig = figure('Color', 'w', 'Position', [100 100 860 420], 'Visible', 'off');
    plot(scan_angles, cbf_norm, 'LineWidth', 1.3);
    grid on; box on; xlabel('Steering angle (deg)'); ylabel('Mean ||w||_2');
    title('CBF weight-vector norm', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'cbf_weight_norm', ...
        'Mean 2-norm of conventional beamformer weights versus steering angle.', dpi);

    % ------------------------------------------------------------------
    % 10) Different element-spacing beam patterns
    % ------------------------------------------------------------------
    c = local_sound_speed(cfg);
    lambda0 = c / max(cfg.fc_hz, eps);
    fig = figure('Color', 'w', 'Position', [100 100 860 440], 'Visible', 'off');
    hold on; grid on; box on;
    for i = 1:numel(cfg.visual.spacing_lambda_list)
        cfg_i = cfg;
        cfg_i.rx_array.spacing_m = cfg.visual.spacing_lambda_list(i) * lambda0;
        [Wi, ~] = local_weights_for_angle(cfg_i, freq_hz, path_angles, path_metric, 0, [], 'cbf');
        patt_i = uwa_beampattern_from_weights(cfg_i, freq_hz, Wi, gain_angles);
        plot(patt_i.angle_grid_deg, patt_i.gain_db, 'LineWidth', 1.15, 'DisplayName', cfg.visual.spacing_labels{i});
    end
    xlabel('Angle (deg)'); ylabel('Normalized gain (dB)');
    title('Beam patterns under different element spacing', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best');
    manifest(end+1) = local_finalize(fig, out_dir, 'spacing_sweep_beampattern', ...
        'Conventional beam patterns for different element spacings.', dpi);

    % ------------------------------------------------------------------
    % 11) Different arrival-angle cases
    % ------------------------------------------------------------------
    fig = figure('Color', 'w', 'Position', [100 100 860 440], 'Visible', 'off');
    hold on; grid on; box on;
    for ia = 1:numel(cfg.visual.arrival_angle_cases_deg)
        theta = cfg.visual.arrival_angle_cases_deg(ia);
        single_tf = local_single_source_array_tf(cfg, freq_hz, size(array_tf_clean, 2), theta);
        scan_case = uwa_beam_scan_spectrum(cfg, freq_hz, single_tf, theta, 1, scan_angles, 'cbf');
        theta_label = sprintf('Arrival %d%s', round(theta), char(176));
        plot(scan_case.scan_angles_deg, scan_case.power_db, 'LineWidth', 1.05, ...
            'DisplayName', theta_label);
    end
    xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('Different arrival-angle cases', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'arrival_angle_cases', ...
        'Beam scan spectra for several synthetic single-arrival directions.', dpi);

    % ------------------------------------------------------------------
    % 12) Fast beamforming algorithm comparison
    % ------------------------------------------------------------------
    tic;
    scan_exact_cbf = uwa_beam_scan_spectrum(cfg, freq_hz, array_tf_clean, path_angles, path_metric, scan_angles, 'cbf');
    t_exact = toc;

    tic;
    fast = uwa_fast_cbf_fft_scan(cfg, array_tf_clean, cfg.visual.fast_fft_length, scan_angles);
    t_fast = toc;

    fig = figure('Color', 'w', 'Position', [100 100 920 720], 'Visible', 'off');
    subplot(2,1,1);
    plot(scan_exact_cbf.scan_angles_deg, scan_exact_cbf.power_db, 'LineWidth', 1.25, 'DisplayName', 'Exact CBF scan');
    hold on; plot(fast.scan_angles_deg, fast.power_interp_db, '--', 'LineWidth', 1.25, 'DisplayName', 'Fast FFT scan');
    grid on; box on; xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('Fast beamforming algorithm: exact vs FFT scan', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best');
    subplot(2,1,2);
    bar([t_exact, t_fast]); grid on; box on;
    set(gca, 'XTickLabel', {'Exact', 'Fast FFT'});
    ylabel('Execution time (s)');
    title('Fast beamforming algorithm timing', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'fast_beamforming_compare', ...
        'Compare exact CBF scan with the FFT-based fast beamforming approximation.', dpi);

    % ------------------------------------------------------------------
    % 13) Beamformer family scan-spectrum comparison
    % ------------------------------------------------------------------
    if isfield(cfg, 'visual') && isfield(cfg.visual, 'beamformer_family_methods') && ~isempty(cfg.visual.beamformer_family_methods)
        family_methods = cfg.visual.beamformer_family_methods;
    else
        family_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};
    end
    fig = figure('Color', 'w', 'Position', [100 100 900 440], 'Visible', 'off');
    hold on; grid on; box on;
    for im = 1:numel(family_methods)
        mth = family_methods{im};
        sc = uwa_beam_scan_spectrum(cfg, freq_hz, array_tf_noisy, path_angles, path_metric, scan_angles, mth);
        plot(sc.scan_angles_deg, sc.power_db, 'LineWidth', 1.15, 'DisplayName', upper(strrep(mth, '_', '-')));
    end
    xlabel('Scan angle (deg)'); ylabel('Relative power (dB)');
    title('CBF / MVDR / WICMV / STMV / improved-STMV scan spectra', 'Interpreter', 'none');
    ylim([-60 5]); legend('Location', 'best', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'beamformer_family_scan_compare', ...
        'Compare scan azimuth spectra for CBF, MVDR, WICMV, STMV, and improved STMV.', dpi);

    % ------------------------------------------------------------------
    % 14) Beamformer family output-spectrum comparison at 0 degree
    % ------------------------------------------------------------------
    fig = figure('Color', 'w', 'Position', [100 100 900 440], 'Visible', 'off');
    hold on; grid on; box on;
    for im = 1:numel(family_methods)
        mth = family_methods{im};
        [Wm, ~] = local_weights_for_angle(cfg, freq_hz, path_angles, path_metric, 0, [], mth);
        Ym = uwa_apply_weights_to_array_tf(array_tf_noisy, Wm);
        [fm, pm_db] = local_tf_output_spectrum(freq_hz, Ym);
        plot(fm, pm_db, 'LineWidth', 1.15, 'DisplayName', upper(strrep(mth, '_', '-')));
    end
    xlabel('Frequency (Hz)'); ylabel('Relative output power (dB)');
    title('CBF / MVDR / WICMV / STMV / improved-STMV output spectra at 0 degree', 'Interpreter', 'none');
    legend('Location', 'best', 'Interpreter', 'none');
    manifest(end+1) = local_finalize(fig, out_dir, 'beamformer_family_output_compare', ...
        'Compare 0-degree beam output spectra for CBF, MVDR, WICMV, STMV, and improved STMV.', dpi);
end

% -------------------------------------------------------------------------
% Local helpers
% -------------------------------------------------------------------------

function cfg_i = local_cfg_partition(cfg, part)
    cfg_i = cfg;
    cfg_i.rx_array.combine_method = 'improved_stmv';
    cfg_i.rx_array.subarray_partition = part;
    cfg_i.rx_array.steering_mode = 'manual';
end

function [W, bf] = local_weights_for_angle(cfg, freq_hz, path_angles, path_metric, angle_deg, part, method)
    if nargin < 7 || isempty(method)
        method = cfg.rx_array.combine_method;
    end
    cfg_i = cfg;
    cfg_i.rx_array.combine_method = method;
    cfg_i.rx_array.steering_mode = 'manual';
    cfg_i.rx_array.steering_angle_deg = angle_deg;
    if nargin >= 6 && ~isempty(part)
        cfg_i.rx_array.subarray_partition = part;
    end
    [~, bf] = uwa_line_array_path_response(cfg_i, freq_hz, path_angles, path_metric);
    W = uwa_beamformer_extract_full_weights(bf);
end

function [f_axis, p_db] = local_tf_output_spectrum(freq_hz, Ytf)
    p = mean(abs(Ytf).^2, 2);
    p = p(:);
    p = p / max(max(p), eps);
    p_db = 10 * log10(max(p, 1e-12));
    f_axis = freq_hz(:);
end

function X = local_single_source_array_tf(cfg, freq_hz, Mtime, angle_deg)
    arr = uwa_line_array_defaults(cfg);
    c = local_sound_speed(cfg);
    E = arr.num_elements;
    A = uwa_line_array_steering(freq_hz, E, arr.spacing_m, c, angle_deg);
    Ka = numel(freq_hz);
    X = zeros(Ka, Mtime, E);
    for e = 1:E
        X(:, :, e) = repmat(A(:, e), 1, Mtime);
    end
end

function c = local_sound_speed(cfg)
    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end
end

function local_add_vertical_marker(xv, ylm, style)
    plot([xv xv], ylm, style, 'LineWidth', 0.8);
end

function item = local_finalize(fig, out_dir, token, desc, dpi)
    png_file = fullfile(out_dir, [token '.png']);
    fig_file = fullfile(out_dir, [token '.fig']);
    saveas(fig, png_file);
    try
        exportgraphics(fig, png_file, 'Resolution', dpi);
    catch
    end
    savefig(fig, fig_file);
    close(fig);

    item = struct();
    item.name = token;
    item.png = png_file;
    item.fig = fig_file;
    item.description = desc;
end

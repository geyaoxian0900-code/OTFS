function out = uwa_plot_link_results(results, mode)
%UWA_PLOT_LINK_RESULTS Save paper-style BER/PER figures.
%
% This wrapper keeps the historical project API while delegating the actual
% plotting to the root-level plot_results.m. The new plotter uses semilogy
% paper-style axes and exports 300 dpi PNG + FIG files.

    if nargin < 2 || isempty(mode)
        if isfield(results, 'mode') && ~isempty(results.mode)
            mode = results.mode;
        else
            mode = 'run';
        end
    end

    cfg = results.cfg;
    if isfield(cfg, 'output_dir') && ~isempty(cfg.output_dir)
        out_dir = cfg.output_dir;
    else
        out_dir = pwd;
    end

    if isfield(cfg, 'rx_array') && isstruct(cfg.rx_array) && ...
            isfield(cfg.rx_array, 'combine_method') && ~isempty(cfg.rx_array.combine_method)
        beamformer_name = cfg.rx_array.combine_method;
    else
        beamformer_name = 'beamformer';
    end

    out = plot_results(results, out_dir, beamformer_name);

    % Backward-compatible file names expected by older docs/scripts.
    copy_if_exists(out.ber_png, fullfile(out_dir, ['ber_curve_' mode '.png']));
    copy_if_exists(out.ber_fig, fullfile(out_dir, ['ber_curve_' mode '.fig']));
    copy_if_exists(out.per_png, fullfile(out_dir, ['per_curve_' mode '.png']));
    copy_if_exists(out.per_fig, fullfile(out_dir, ['per_curve_' mode '.fig']));
end

function copy_if_exists(src, dst)
    if exist(src, 'file') == 2
        try
            copyfile(src, dst);
        catch
        end
    end
end

function manifest_file = uwa_write_visual_manifest(run_dir, results, chain_manifest, beam_manifest, vis)
%UWA_WRITE_VISUAL_MANIFEST Write a markdown summary of generated figures.

    if nargin < 5
        vis = struct();
    end

    out_dir = fullfile(run_dir, 'figures', 'summaries');
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end
    manifest_file = fullfile(out_dir, 'figure_manifest.md');

    fid = fopen(manifest_file, 'w');
    if fid < 0
        warning('Could not create figure manifest: %s', manifest_file);
        return;
    end

    cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid, '# UWA OTFS/OFDM full visual project figure manifest\n\n');
    fprintf(fid, '- Created at: %s\n', datestr(now, 31));
    if isfield(results, 'mode')
        fprintf(fid, '- Mode: %s\n', results.mode);
    end
    if isfield(results, 'cfg') && isfield(results.cfg, 'rx_array') && isfield(results.cfg.rx_array, 'combine_method')
        fprintf(fid, '- Beamformer: %s\n', results.cfg.rx_array.combine_method);
    end
    if isfield(results, 'otfs_detector_method')
        fprintf(fid, '- OTFS detector: %s\n', results.otfs_detector_method);
    end
    if nargin >= 5 && isstruct(vis) && isfield(vis, 'rep_snr_dB')
        fprintf(fid, '- Representative SNR: %.2f dB\n', vis.rep_snr_dB);
    end
    if nargin >= 5 && isstruct(vis) && isfield(vis, 'rep_prb')
        fprintf(fid, '- Representative PRB: %d\n', vis.rep_prb);
    end
    fprintf(fid, '\n');

    fprintf(fid, '## Performance results\n\n');
    if isfield(results, 'cfg') && isfield(results.cfg, 'output_dir')
        fprintf(fid, '- BER/PER figures are stored in `%s`.\n\n', results.cfg.output_dir);
    end

    fprintf(fid, '## Communication-chain node figures\n\n');
    local_write_items(fid, chain_manifest);

    fprintf(fid, '## Beamforming / array figure suite\n\n');
    local_write_items(fid, beam_manifest);
end

function local_write_items(fid, items)
    if isempty(items)
        fprintf(fid, '_No items._\n\n');
        return;
    end
    for i = 1:numel(items)
        fprintf(fid, '### %d. `%s`\n\n', i, items(i).name);
        fprintf(fid, '- PNG: `%s`\n', items(i).png);
        fprintf(fid, '- FIG: `%s`\n', items(i).fig);
        fprintf(fid, '- Description: %s\n\n', items(i).description);
    end
end

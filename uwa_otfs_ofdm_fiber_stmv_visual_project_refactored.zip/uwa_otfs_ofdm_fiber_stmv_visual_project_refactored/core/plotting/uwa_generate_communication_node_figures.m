function manifest = uwa_generate_communication_node_figures(vis, out_dir)
%UWA_GENERATE_COMMUNICATION_NODE_FIGURES Generate node-by-node link figures.
%
% The suite covers the major communication nodes for both OTFS and OFDM:
%   bits -> coding -> mapping -> DD/TF -> time signal -> channel ->
%   beamforming -> receive TF/DD -> equalization -> LLR -> decoded bits

    if nargin < 2 || isempty(out_dir)
        out_dir = fullfile(vis.cfg.output_dir, vis.cfg.visual.figure_root_name, vis.cfg.visual.chain_subdir);
    end
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end

    manifest = struct('name', {}, 'png', {}, 'fig', {}, 'description', {});
    cfg = vis.cfg;
    max_time_samples = cfg.visual.max_time_samples_to_plot;
    show_bits = min(cfg.visual.show_decoded_bit_count, vis.packet_bits);
    dpi = cfg.visual.export_dpi;

    % 0) system chain block diagram
    manifest(end+1) = local_plot_block_diagram(out_dir, 'system_chain_block_diagram', ...
        'Communication chain block diagram', ...
        'Overall OTFS/OFDM underwater communication chain with fibre-array beamforming.', dpi);

    % 1) information bits
    manifest(end+1) = local_plot_bits(vis.packet.info_bits, show_bits, out_dir, ...
        'info_bits', 'Information bits', 'Input bit stream to the encoder.', dpi);

    % 2) coded bits
    manifest(end+1) = local_plot_bits(vis.packet.coded_bits, min(show_bits, numel(vis.packet.coded_bits)), out_dir, ...
        'coded_bits', 'Coded bits', 'Encoded bit stream before QAM mapping.', dpi);

    % 3) transmit constellation
    manifest(end+1) = local_plot_constellation(vis.packet.symbols, [], out_dir, ...
        'tx_constellation', 'Transmit constellation', 'Mapped QAM symbols before OTFS/OFDM.', dpi);

    % 4) OTFS TX DD grid
    manifest(end+1) = local_plot_matrix(vis.otfs.Xdd_tx, out_dir, 'otfs_tx_dd_grid', ...
        'OTFS transmit DD grid |X_{dd}|', 'Delay index', 'Doppler index', ...
        'OTFS mapped symbols in the delay-Doppler domain.', dpi);

    % 5) OTFS TX TF grid
    manifest(end+1) = local_plot_matrix(vis.otfs.Xtf_tx, out_dir, 'otfs_tx_tf_grid', ...
        'OTFS transmit TF grid |X_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'OTFS after DD->TF transform.', dpi);

    % 6) OTFS transmit time signal
    manifest(end+1) = local_plot_time_signal(vis.otfs.tx_time, max_time_samples, out_dir, ...
        'otfs_tx_time_signal', 'OTFS transmit time signal', ...
        'Serialized OTFS waveform after the OFDM kernel.', dpi);

    % 7) OFDM TX TF grid
    manifest(end+1) = local_plot_matrix(vis.ofdm.Xtf_tx, out_dir, 'ofdm_tx_tf_grid', ...
        'OFDM transmit TF grid |X_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'OFDM mapped symbols in the TF domain.', dpi);

    % 8) OFDM transmit time signal
    manifest(end+1) = local_plot_time_signal(vis.ofdm.tx_time, max_time_samples, out_dir, ...
        'ofdm_tx_time_signal', 'OFDM transmit time signal', ...
        'Serialized OFDM waveform after IFFT and CP.', dpi);

    % 9) single-sensor TF channel
    manifest(end+1) = local_plot_matrix(vis.channel.Htf_single_active, out_dir, 'single_sensor_tf_channel', ...
        'Single-sensor TF channel |H_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'Reference hydrophone TF channel without array beamforming.', dpi);

    % 10) beamformed TF channel
    manifest(end+1) = local_plot_matrix(vis.channel.Htf_active, out_dir, 'beamformed_tf_channel', ...
        'Beamformed TF channel |H_{tf,beam}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'Effective TF channel after the selected array beamformer.', dpi);

    % 11) effective DD channel
    manifest(end+1) = local_plot_matrix(vis.effective_dd_channel, out_dir, 'effective_dd_channel', ...
        'Effective DD channel |h_{dd}|', 'Delay index', 'Doppler index', ...
        'Equivalent OTFS delay-Doppler channel obtained by impulse probing.', dpi);

    % 12) element-1 OTFS receive time signal
    manifest(end+1) = local_plot_time_signal(vis.otfs.rx_time_elem1, max_time_samples, out_dir, ...
        'otfs_rx_time_element1', 'OTFS receive time signal at element #1', ...
        'Received OTFS waveform at the first array element.', dpi);

    % 13) beamformed OTFS receive time signal
    manifest(end+1) = local_plot_time_signal(vis.otfs.rx_time_beam, max_time_samples, out_dir, ...
        'otfs_rx_time_beamformed', 'OTFS beamformed receive time signal', ...
        'Beamformed OTFS waveform reconstructed from the active TF grid.', dpi);

    % 14) OTFS receive TF grid before DD demod
    manifest(end+1) = local_plot_matrix(vis.otfs.Ytf_beam_noisy, out_dir, 'otfs_rx_tf_noisy', ...
        'OTFS receive TF grid |Y_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'Beamformed OTFS TF grid before TF->DD transform.', dpi);

    % 15) OTFS receive DD grid before equalization
    manifest(end+1) = local_plot_matrix(vis.otfs.Ydd_beam_noisy, out_dir, 'otfs_rx_dd_noisy', ...
        'OTFS receive DD grid |Y_{dd}|', 'Delay index', 'Doppler index', ...
        'OTFS DD-domain signal before equalization.', dpi);

    % 16) OTFS equalized DD grid
    manifest(end+1) = local_plot_matrix(vis.otfs.Xdd_hat, out_dir, 'otfs_eq_dd', ...
        'OTFS equalized DD grid |\hat{X}_{dd}|', 'Delay index', 'Doppler index', ...
        'OTFS equalized DD-domain estimate.', dpi);

    if isfield(vis, 'otfs_bf_dae')
        manifest(end+1) = local_plot_matrix(vis.otfs_bf_dae.beam_tf_first, out_dir, 'otfs_bf_dae_tf_beam1', ...
            'OTFS BF-DAE first TF beam |Z_{tf}^{(1)}|', 'OFDM symbol index', 'Active subcarrier index', ...
            'First TF-domain beam output after the R-to-Q beamforming preprocessing.', dpi);
        manifest(end+1) = local_plot_matrix(vis.otfs_bf_dae.beam_dd_first, out_dir, 'otfs_bf_dae_dd_beam1', ...
            'OTFS BF-DAE first DD beam |z_{dd}^{(1)}|', 'Delay index', 'Doppler index', ...
            'First DD-domain beam output after SFFT.', dpi);
        manifest(end+1) = local_plot_matrix(vis.otfs_bf_dae.X_hat_grid, out_dir, 'otfs_bf_dae_eq_dd', ...
            'OTFS BF-DAE equalized DD grid |\hat{X}_{dd,BF-DAE}|', 'Delay index', 'Doppler index', ...
            'DD-domain estimate obtained by TF beamforming preprocessing plus multichannel adaptive detection.', dpi);
        manifest(end+1) = local_plot_constellation(vis.otfs_bf_dae.rx_syms_pre, vis.otfs_bf_dae.rx_syms_post, out_dir, ...
            'otfs_bf_dae_constellation_prepost', 'OTFS BF-DAE constellation before/after detection', ...
            'BF-DAE data symbols before adaptive detection and after DD-domain recovery.', dpi);
    end

    % 17) OFDM element-1 receive time signal
    manifest(end+1) = local_plot_time_signal(vis.ofdm.rx_time_elem1, max_time_samples, out_dir, ...
        'ofdm_rx_time_element1', 'OFDM receive time signal at element #1', ...
        'Received OFDM waveform at the first array element.', dpi);

    % 18) OFDM beamformed receive time signal
    manifest(end+1) = local_plot_time_signal(vis.ofdm.rx_time_beam, max_time_samples, out_dir, ...
        'ofdm_rx_time_beamformed', 'OFDM beamformed receive time signal', ...
        'Beamformed OFDM waveform reconstructed from the active TF grid.', dpi);

    % 19) OFDM receive TF grid before equalization
    manifest(end+1) = local_plot_matrix(vis.ofdm.Ytf_beam_noisy, out_dir, 'ofdm_rx_tf_noisy', ...
        'OFDM receive TF grid |Y_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'OFDM TF-domain receive grid before equalization.', dpi);

    % 20) OFDM equalized TF grid
    manifest(end+1) = local_plot_matrix(vis.ofdm.Xtf_hat, out_dir, 'ofdm_eq_tf', ...
        'OFDM equalized TF grid |\hat{X}_{tf}|', 'OFDM symbol index', 'Active subcarrier index', ...
        'OFDM equalized TF-domain estimate.', dpi);

    % 21) OTFS pre/post constellation
    manifest(end+1) = local_plot_constellation(vis.otfs.rx_syms_pre, vis.otfs.rx_syms_post, out_dir, ...
        'otfs_constellation_prepost', 'OTFS constellation before/after equalization', ...
        'OTFS data symbols before and after equalization.', dpi);

    % 22) OFDM pre/post constellation
    manifest(end+1) = local_plot_constellation(vis.ofdm.rx_syms_pre, vis.ofdm.rx_syms_post, out_dir, ...
        'ofdm_constellation_prepost', 'OFDM constellation before/after equalization', ...
        'OFDM data symbols before and after equalization.', dpi);

    % 23) OTFS LLRs
    manifest(end+1) = local_plot_llr(vis.otfs.llr, out_dir, 'otfs_llr', ...
        'OTFS soft bits (LLR)', 'Soft bits produced by OTFS equalization and demapping.', dpi);
    if isfield(vis, 'otfs_bf_dae')
        manifest(end+1) = local_plot_llr(vis.otfs_bf_dae.llr, out_dir, 'otfs_bf_dae_llr', ...
            'OTFS BF-DAE soft bits (LLR)', 'Soft bits produced by the BF-DAE detector.', dpi);
    end

    % 24) OFDM LLRs
    manifest(end+1) = local_plot_llr(vis.ofdm.llr, out_dir, 'ofdm_llr', ...
        'OFDM soft bits (LLR)', 'Soft bits produced by OFDM equalization and demapping.', dpi);

    % 25) decoded-bit comparison
    manifest(end+1) = local_plot_bit_comparison(vis.summary.info_bits, vis.summary.decoded_bits_otfs, ...
        vis.summary.decoded_bits_ofdm, show_bits, out_dir, 'decoded_bits_compare', ...
        'Decoded bit comparison', 'Original bits compared with OTFS and OFDM decoded bits.', dpi);

    % 26) channel node summary: single vs beamformed time spectra
    manifest(end+1) = local_plot_dual_spectrum(vis.otfs.rx_time_single, vis.otfs.rx_time_beam, cfg.fs, out_dir, ...
        'otfs_single_vs_beam_spectrum', 'OTFS receive spectrum: single sensor vs beamformed', ...
        'Compare the receive spectra before and after beamforming for OTFS.', dpi);

    manifest(end+1) = local_plot_dual_spectrum(vis.ofdm.rx_time_single, vis.ofdm.rx_time_beam, cfg.fs, out_dir, ...
        'ofdm_single_vs_beam_spectrum', 'OFDM receive spectrum: single sensor vs beamformed', ...
        'Compare the receive spectra before and after beamforming for OFDM.', dpi);
end

% -------------------------------------------------------------------------
% Local plotting helpers
% -------------------------------------------------------------------------

function item = local_plot_block_diagram(out_dir, token, ttl, desc, dpi)
    fig = figure('Color', 'w', 'Position', [100 100 1200 260], 'Visible', 'off');
    ax = axes(fig, 'Position', [0 0 1 1], 'Visible', 'off'); %#ok<LAXES>
    x = [0.03 0.16 0.29 0.42 0.57 0.72 0.85];
    w = 0.10; h = 0.22; y = 0.42;
    labels = {'Info bits', 'Coding/QAM', 'OTFS DD / OFDM TF', 'Time waveform', ...
        'UWA channel', 'Fibre array + beamforming', 'Equalize / Decode'};
    for i = 1:numel(labels)
        annotation(fig, 'rectangle', [x(i) y w h], 'LineWidth', 1.0);
        annotation(fig, 'textbox', [x(i) y w h], 'String', labels{i}, ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
            'LineStyle', 'none', 'FontSize', 11);
        if i < numel(labels)
            annotation(fig, 'arrow', [x(i)+w x(i+1)], [y+h/2 y+h/2], 'LineWidth', 1.0);
        end
    end
    annotation(fig, 'textbox', [0.02 0.78 0.96 0.12], 'String', ttl, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
        'LineStyle', 'none', 'FontSize', 14, 'FontWeight', 'bold');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_bits(bits, nshow, out_dir, token, ttl, desc, dpi)
    bits = double(bits(:)).';
    nshow = min(nshow, numel(bits));
    fig = figure('Color', 'w', 'Position', [100 100 900 320], 'Visible', 'off');
    stairs(0:nshow-1, bits(1:nshow), 'LineWidth', 1.2);
    ylim([-0.2 1.2]); grid on; box on;
    xlabel('Bit index'); ylabel('Bit value'); title(ttl, 'Interpreter', 'none');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_constellation(pre_syms, post_syms, out_dir, token, ttl, desc, dpi)
    fig = figure('Color', 'w', 'Position', [100 100 640 560], 'Visible', 'off');
    hold on; box on; grid on;
    if ~isempty(pre_syms)
        plot(real(pre_syms(:)), imag(pre_syms(:)), 'o', 'MarkerSize', 4, 'DisplayName', 'Before EQ');
    end
    if ~isempty(post_syms)
        plot(real(post_syms(:)), imag(post_syms(:)), 'x', 'MarkerSize', 4, 'DisplayName', 'After EQ');
    end
    xlabel('In-phase'); ylabel('Quadrature'); axis equal;
    title(ttl, 'Interpreter', 'none');
    legend('Location', 'best');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_matrix(X, out_dir, token, ttl, xlab, ylab, desc, dpi)
    fig = figure('Color', 'w', 'Position', [100 100 760 560], 'Visible', 'off');
    imagesc(abs(X));
    axis xy; colorbar; box on;
    xlabel(xlab); ylabel(ylab); title(ttl, 'Interpreter', 'none');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_time_signal(x, max_time_samples, out_dir, token, ttl, desc, dpi)
    x = x(:);
    ns = min(max_time_samples, numel(x));
    n = 0:ns-1;
    fig = figure('Color', 'w', 'Position', [100 100 900 360], 'Visible', 'off');
    plot(n, real(x(1:ns)), 'LineWidth', 1.0, 'DisplayName', 'Real');
    hold on; plot(n, imag(x(1:ns)), 'LineWidth', 1.0, 'DisplayName', 'Imag');
    grid on; box on;
    xlabel('Sample index'); ylabel('Amplitude'); title(ttl, 'Interpreter', 'none');
    legend('Location', 'best');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_llr(llr, out_dir, token, ttl, desc, dpi)
    llr = llr(:).';
    nshow = min(256, numel(llr));
    fig = figure('Color', 'w', 'Position', [100 100 900 360], 'Visible', 'off');
    stem(0:nshow-1, llr(1:nshow), 'filled');
    grid on; box on;
    xlabel('LLR index'); ylabel('LLR value'); title(ttl, 'Interpreter', 'none');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_bit_comparison(info_bits, dec_otfs, dec_ofdm, nshow, out_dir, token, ttl, desc, dpi)
    nshow = min(nshow, numel(info_bits));
    fig = figure('Color', 'w', 'Position', [100 100 900 400], 'Visible', 'off');
    stairs(0:nshow-1, info_bits(1:nshow), 'LineWidth', 1.2, 'DisplayName', 'Original');
    hold on;
    stairs(0:nshow-1, dec_otfs(1:nshow), 'LineWidth', 1.0, 'DisplayName', 'OTFS decoded');
    stairs(0:nshow-1, dec_ofdm(1:nshow), 'LineWidth', 1.0, 'DisplayName', 'OFDM decoded');
    ylim([-0.2 1.2]); grid on; box on;
    xlabel('Bit index'); ylabel('Bit value'); title(ttl, 'Interpreter', 'none');
    legend('Location', 'best');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function item = local_plot_dual_spectrum(x1, x2, fs, out_dir, token, ttl, desc, dpi)
    [f1, p1] = local_spectrum(x1, fs);
    [f2, p2] = local_spectrum(x2, fs);
    fig = figure('Color', 'w', 'Position', [100 100 900 380], 'Visible', 'off');
    plot(f1, p1, 'LineWidth', 1.1, 'DisplayName', 'Single sensor');
    hold on; plot(f2, p2, 'LineWidth', 1.1, 'DisplayName', 'Beamformed');
    grid on; box on;
    xlabel('Frequency (Hz)'); ylabel('Magnitude (dB)'); title(ttl, 'Interpreter', 'none');
    legend('Location', 'best');
    item = local_finalize(fig, out_dir, token, desc, dpi);
end

function [f, p_db] = local_spectrum(x, fs)
    x = x(:);
    nfft = 2^nextpow2(max(numel(x), 256));
    X = fftshift(fft(x, nfft));
    p = abs(X).^2;
    p = p / max(max(p), eps);
    p_db = 10 * log10(max(p, 1e-12));
    f = linspace(-fs/2, fs/2, nfft);
end

function item = local_finalize(fig, out_dir, token, desc, dpi)
    png_file = fullfile(out_dir, [token '.png']);
    fig_file = fullfile(out_dir, [token '.fig']);
    saveas(fig, png_file);
    try
        exportgraphics(fig, png_file, 'Resolution', dpi);
    catch
    end
    savefig(fig, fig_file);
    close(fig);

    item = struct();
    item.name = token;
    item.png = png_file;
    item.fig = fig_file;
    item.description = desc;
end

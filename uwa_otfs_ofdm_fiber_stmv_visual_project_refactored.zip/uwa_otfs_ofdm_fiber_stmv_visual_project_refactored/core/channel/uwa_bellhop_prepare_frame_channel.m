function [ch, h_eff, meta] = uwa_bellhop_prepare_frame_channel(cfg, seed, nom)
%UWA_BELLHOP_PREPARE_FRAME_CHANNEL Prepare one normalized Bellhop TF frame.
%
% Input:
%   cfg  : Bellhop/UWA config
%   seed : random seed for statistical layer
%   nom  : optional cached nominal Bellhop paths
%
% Output:
%   ch    : normalized TF channel realization
%   h_eff : effective DD kernel (approximate)
%   meta  : auxiliary info

    if nargin < 3
        nom = [];
    end

    if nargin < 2 || isempty(seed)
        seed = 1;
    end

    if isempty(nom)
        [nom, ~] = uwa_bellhop_get_nominal_paths(cfg);
    end

    ch = uwa_alg32_stat_channel81_bellhop(cfg, cfg.doppler_factor, seed, nom);

    avg_pow_out = mean(abs(ch.Htf_active(:)).^2);
    if ~isfinite(avg_pow_out) || avg_pow_out <= 0
        avg_pow_out = 1;
    end

    Href = uwa_reference_tf_channel(ch);
    ref_pow = mean(abs(Href(:)).^2);
    if ~isfinite(ref_pow) || ref_pow <= 0
        ref_pow = avg_pow_out;
    end

    scale = sqrt(ref_pow);
    ch.Htf_active = ch.Htf_active / scale;

    if isfield(ch, 'Htf_single_active')
        ch.Htf_single_active = ch.Htf_single_active / scale;
    end

    if isfield(ch, 'Hp_ft')
        ch.Hp_ft = ch.Hp_ft / scale;
    end

    h_eff = uwa_bellhop_effective_dd_channel(ch, cfg);

    meta = struct();
    meta.avg_power_before_norm = avg_pow_out;
    meta.ref_power_before_norm = ref_pow;
    meta.norm_scale = scale;
end

function exe = uwa_resolve_bellhop_exe(preferred)
%UWA_RESOLVE_BELLHOP_EXE Resolve Bellhop executable path robustly.
%
% Resolution priority:
%   1) explicit preferred path/name
%   2) environment variable BELLHOP_EXE
%   3) environment variable BELLHOP_BIN
%   4) bellhop/bellhop.exe on MATLAB path
%   5) bellhop/bellhop.exe on OS PATH
%   6) a few common Windows install paths
%
% Notes:
%   - For pathless names like "bellhop.exe", do NOT trust exist(name,'file')
%     by itself. MATLAB can find a file on the MATLAB path while the OS shell
%     still cannot execute it from an arbitrary working directory.
%   - When a match is found on the MATLAB path, this function returns the
%     fully-qualified filesystem path so system() can launch it reliably.

    if nargin < 1
        preferred = '';
    end

    exe = '';
    cand = {};

    if ~isempty(preferred)
        cand{end+1} = preferred; %#ok<AGROW>
    end

    env_exe = getenv('BELLHOP_EXE');
    if ~isempty(env_exe)
        cand{end+1} = env_exe; %#ok<AGROW>
    end

    env_bin = getenv('BELLHOP_BIN');
    if ~isempty(env_bin)
        cand{end+1} = env_bin; %#ok<AGROW>
    end

    if ispc
        cand{end+1} = 'bellhop.exe'; %#ok<AGROW>
        cand{end+1} = 'bellhop'; %#ok<AGROW>
        cand{end+1} = 'C:\Program Files\Bellhop\bellhop.exe'; %#ok<AGROW>
        cand{end+1} = 'C:\Program Files (x86)\Bellhop\bellhop.exe'; %#ok<AGROW>
        cand{end+1} = 'D:\MATLAB\atWin10_2020_11_4\atWin10_2020_11_4\windows-bin-20201102\bellhop.exe'; %#ok<AGROW>
    else
        cand{end+1} = 'bellhop'; %#ok<AGROW>
        cand{end+1} = '/usr/local/bin/bellhop'; %#ok<AGROW>
        cand{end+1} = '/opt/local/bin/bellhop'; %#ok<AGROW>
    end

    for i = 1:numel(cand)
        c = local_normalize_candidate(cand{i});
        if isempty(c)
            continue;
        end

        c = local_expand_dir_candidate(c);
        if isempty(c)
            continue;
        end

        if ~local_is_pathless_name(c)
            if exist(c, 'file') == 2
                exe = c;
                return;
            end
            continue;
        end

        hit = local_search_on_matlab_path(c);
        if ~isempty(hit)
            exe = hit;
            return;
        end

        hit = local_search_on_os_path(c);
        if ~isempty(hit)
            exe = hit;
            return;
        end

        local_file = fullfile(pwd, c);
        if exist(local_file, 'file') == 2
            exe = local_file;
            return;
        end
    end
end

function s = local_normalize_candidate(s)
    if isempty(s)
        return;
    end

    s = strtrim(s);

    while numel(s) >= 2
        if (s(1) == '"' && s(end) == '"') || (s(1) == '''' && s(end) == '''')
            s = strtrim(s(2:end-1));
        else
            break;
        end
    end
end

function c = local_expand_dir_candidate(c)
    if exist(c, 'dir') ~= 7
        return;
    end

    probe = {};
    if ispc
        probe = {fullfile(c, 'bellhop.exe'), fullfile(c, 'bellhop')};
    else
        probe = {fullfile(c, 'bellhop'), fullfile(c, 'bellhop.exe')};
    end

    for k = 1:numel(probe)
        if exist(probe{k}, 'file') == 2
            c = probe{k};
            return;
        end
    end

    c = '';
end

function tf = local_is_pathless_name(s)
    tf = isempty(regexp(s, '[\\/]', 'once')) && isempty(regexp(s, '^[A-Za-z]:', 'once'));
end

function hit = local_search_on_matlab_path(name)
    hit = '';

    try
        w = which(name);
    catch
        w = '';
    end

    if isempty(w)
        return;
    end

    w = strtrim(w);
    if isempty(w)
        return;
    end

    if ~isempty(strfind(lower(w), 'built-in'))
        return;
    end

    w = local_normalize_candidate(w);
    if exist(w, 'file') == 2
        hit = w;
    end
end

function hit = local_search_on_os_path(name)
    hit = '';

    if ispc
        cmd = sprintf('where "%s"', name);
    else
        cmd = sprintf('which "%s"', name);
    end

    [status, out] = system(cmd);
    if status ~= 0 || isempty(strtrim(out))
        return;
    end

    lines = regexp(strtrim(out), '\r\n|\n|\r', 'split');
    if isempty(lines)
        return;
    end

    cand = local_normalize_candidate(strtrim(lines{1}));
    if exist(cand, 'file') == 2
        hit = cand;
    end
end

function arrfile = uwa_bellhop_run(cfg, envfile)
%UWA_BELLHOP_RUN Call Bellhop in a portable way.

    [workdir, tag, ~] = fileparts(envfile);

    exe = '';
    if isfield(cfg, 'bellhop_exe')
        exe = cfg.bellhop_exe;
    end
    exe = uwa_resolve_bellhop_exe(exe);

    if isempty(exe)
        error(['Bellhop executable not found. ', ...
            'Set BELLHOP_EXE / BELLHOP_BIN to the full path of bellhop.exe ', ...
            'or set cfg.bellhop_exe before running the Bellhop-backed figures.']);
    end

    if exist(exe, 'file') ~= 2
        error('Resolved Bellhop executable is not a valid file: %s', exe);
    end

    if ~exist(workdir, 'dir')
        mkdir(workdir);
    end

    if ispc && numel(fullfile(workdir, 'fort.6')) >= 260
        error(['Bellhop working directory is too long for this Windows build.\n', ...
               'Working directory: %s\n', ...
               'Length with fort.6: %d\n', ...
               'Move the project closer to a drive root or use a shorter tmp dir.'], ...
               workdir, numel(fullfile(workdir, 'fort.6')));
    end

    if ispc
        cmd = sprintf('cd /d "%s" && "%s" "%s"', workdir, exe, tag);
    else
        cmd = sprintf('cd "%s" && "%s" "%s"', workdir, exe, tag);
    end

    [status, out] = system(cmd);

    if status ~= 0
        error(['Bellhop run failed.\n', ...
               'Resolved executable: %s\n', ...
               'Working directory: %s\n', ...
               'Command: %s\n', ...
               'Shell output:\n%s'], exe, workdir, cmd, out);
    end

    arrfile = fullfile(workdir, [tag '.arr']);
    if ~exist(arrfile, 'file')
        error('Bellhop arrival file not found: %s', arrfile);
    end
end

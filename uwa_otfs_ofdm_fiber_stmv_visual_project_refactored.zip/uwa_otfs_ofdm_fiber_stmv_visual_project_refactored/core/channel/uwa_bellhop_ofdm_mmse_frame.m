function Xhat_act = uwa_bellhop_ofdm_mmse_frame(Xtf_act, ch, cfg, noise_var)
%UWA_BELLHOP_OFDM_MMSE_FRAME OFDM active-grid TF MMSE equalization.
%
% Input:
%   Xtf_act   : active TF grid [num_active_sc x num_symbols]
%   ch        : normalized TF channel realization
%   cfg       : config
%   noise_var : scalar noise variance
%
% Output:
%   Xhat_act  : equalized active TF grid

    if nargin < 4
        noise_var = 0;
    end

    Yact = ch.Htf_active .* Xtf_act;

    if noise_var > 0
        Yact = Yact + sqrt(noise_var / 2) * ...
            (randn(size(Yact)) + 1j * randn(size(Yact)));
    end

    Xhat_act = Yact .* conj(ch.Htf_active) ./ (abs(ch.Htf_active).^2 + max(noise_var, 1e-12));
end

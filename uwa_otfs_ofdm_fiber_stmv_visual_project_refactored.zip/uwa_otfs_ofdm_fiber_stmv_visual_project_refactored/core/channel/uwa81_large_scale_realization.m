function ls = uwa81_large_scale_realization(cfg, nom)
%UWA81_LARGE_SCALE_REALIZATION
% Large-scale uncertainty per [81] Sec II-B:
% random path length perturbation Δl_p perturbs delay and gain.

    P = numel(nom.lp_m);

    % Standard deviation of path-length perturbation (meters)
    % Engineering parameter; paper [81] models location uncertainty via Δl_p
    if isfield(cfg, 'ls_sigma_l_m')
        sigma_l = cfg.ls_sigma_l_m;
    else
        sigma_l = 0.5;  % modest large-scale geometry uncertainty
    end

    delta_l = sigma_l * randn(1,P);

    lp = max(nom.lp_m + delta_l, 0.1);
    tau_s = lp / cfg.sound_speed;

    % Exponential approximation from [81] Sec II-B
    % large-scale gain = nominal gain * exp(-kappa * Δl_p)
    % Here kappa is approximated from spreading + weak absorption slope.
    l0 = nom.lp_m(1);
    kappa = 1/(2*l0) + 1e-4;   % engineering approximation to paper logic

    hp_ls = nom.hp_nom .* exp(-kappa * delta_l);

    ls = struct();
    ls.delta_l_m = delta_l(:).';
    ls.lp_m      = lp(:).';
    ls.tau_s     = tau_s(:).';
    ls.hp_ls     = hp_ls(:).';
end

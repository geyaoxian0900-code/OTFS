function [nom, cache_file] = uwa_bellhop_get_nominal_paths(cfg, cache_tag)
%UWA_BELLHOP_GET_NOMINAL_PATHS Run Bellhop once and cache nominal arrivals.
%
% If Bellhop is unavailable and cfg.allow_synthetic_nominal_paths is true,
% a deterministic synthetic multipath profile is used.  This keeps teaching
% and reproducibility workflows runnable while preserving Bellhop as the
% preferred physical source.

    if nargin < 2 || isempty(cache_tag)
        cache_tag = local_default_tag(cfg);
    end

    if isfield(cfg, 'bellhop_cache_dir') && ~isempty(cfg.bellhop_cache_dir)
        cache_dir = cfg.bellhop_cache_dir;
    else
        cache_dir = fullfile(tempdir, 'uwa_bellhop_cache');
    end

    if ~exist(cache_dir, 'dir')
        mkdir(cache_dir);
    end

    cache_tag = regexprep(cache_tag, '[^A-Za-z0-9_\-]', '_');
    cache_file = fullfile(cache_dir, [cache_tag '.mat']);

    if exist(cache_file, 'file')
        S = load(cache_file);
        if isfield(S, 'nom')
            nom = S.nom;
            arr_cfg = uwa_line_array_defaults(cfg);
            needs_refresh = false;

            if arr_cfg.enabled
                needs_refresh = ~isfield(nom, 'rx_angle_deg') || isempty(nom.rx_angle_deg);
            end

            if ~needs_refresh
                return;
            end
        end
    end

    allow_fallback = isfield(cfg, 'allow_synthetic_nominal_paths') && logical(cfg.allow_synthetic_nominal_paths);
    bellhop_ok = false;
    exe = '';
    if isfield(cfg, 'bellhop_exe')
        exe = uwa_resolve_bellhop_exe(cfg.bellhop_exe);
    else
        exe = uwa_resolve_bellhop_exe('');
    end
    if ~isempty(exe) && exist(exe, 'file') == 2
        bellhop_ok = true;
    end

    if bellhop_ok
        nom = uwa81_nominal_paths_bellhop(cfg, 1);
        nom.nominal_source = 'bellhop';
    elseif allow_fallback
        nom = uwa_synthetic_nominal_paths(cfg, 1);
        nom.nominal_source = 'synthetic_fallback';
        fprintf(['Warning: Bellhop executable not found. Using deterministic ', ...
                 'synthetic nominal paths for reproducible demo.\n']);
    else
        error(['Bellhop executable not found. Set BELLHOP_EXE / BELLHOP_BIN ', ...
               'or set cfg.allow_synthetic_nominal_paths=true for the demo fallback.']);
    end

    save(cache_file, 'nom');
end

function tag = local_default_tag(cfg)
    fields = { ...
        local_field(cfg, 'range_m'), ...
        local_field(cfg, 'tx_depth_m'), ...
        local_field(cfg, 'rx_depth_m'), ...
        local_field(cfg, 'water_depth_m'), ...
        local_field(cfg, 'sound_speed'), ...
        local_field(cfg, 'fc_hz'), ...
        local_field(cfg, 'fft_size'), ...
        local_field(cfg, 'num_active_sc'), ...
        local_field(cfg, 'num_paths_max')};

    tag = sprintf('bellhop_r%s_tz%s_rz%s_H%s_c%s_fc%s_fft%s_ka%s_np%s', fields{:});
    tag = strrep(tag, '.', 'p');
end

function s = local_field(cfg, name)
    if isfield(cfg, name)
        v = cfg.(name);
        if isnumeric(v) && isscalar(v)
            s = num2str(v);
        else
            s = 'x';
        end
    else
        s = 'x';
    end
end

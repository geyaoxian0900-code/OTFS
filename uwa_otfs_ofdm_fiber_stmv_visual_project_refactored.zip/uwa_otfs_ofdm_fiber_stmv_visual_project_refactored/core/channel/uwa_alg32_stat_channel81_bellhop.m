function ch = uwa_alg32_stat_channel81_bellhop(cfg, doppler_factor, seed, nom_in)
%UWA_ALG32_STAT_CHANNEL81_BELLHOP
% Bellhop nominal paths + [81] statistical layers
%
% New:
%   - supports optional precomputed nominal Bellhop paths (nom_in)
%   - fixes seed initialization guard
%
% Input:
%   cfg            : config
%   doppler_factor : normalized Doppler factor
%   seed           : RNG seed for statistical layers
%   nom_in         : optional cached nominal paths from Bellhop
%
% Output:
%   ch             : TF channel realization on active grid

    if nargin >= 3 && ~isempty(seed)
        rng(seed);
    end

    if nargin < 4
        nom_in = [];
    end

    Ka = cfg.num_active_sc;
    M  = cfg.num_symbols;

    idx = uwa_center_active_indices(cfg.fft_size, Ka);
    k_rel = idx(:) - 1 - floor(cfg.fft_size/2);
    freq_base = k_rel * cfg.delta_f_hz;
    freq_hz = cfg.fc_hz + freq_base;

    Tsym = (cfg.fft_size + cfg.cp_ofdm) / cfg.fs;
    time_s = (0:M-1) * Tsym;

    if isempty(nom_in)
        nom = uwa81_nominal_paths_bellhop(cfg, seed);
    else
        nom = nom_in;
    end

    P = numel(nom.tau_nom_s);

    ls = uwa81_large_scale_realization(cfg, nom);

    gamma_ft = zeros(Ka, M, P);
    for p = 1:P
        ss_cfg = uwa81_small_scale_params(cfg, nom, p, doppler_factor);
        gamma_ft(:,:,p) = uwa81_generate_gamma_ft(freq_hz, time_s, ls.hp_ls(p), ss_cfg);
    end

    H0_f = nom.H0_f;
    Hp_ft = zeros(Ka, M, P);

    for p = 1:P
        phase_delay = exp(-1j * 2*pi * freq_hz(:) * ls.tau_s(p));
        Hp_ft(:,:,p) = (H0_f(:) .* phase_delay) .* gamma_ft(:,:,p) * ls.hp_ls(p);
    end

    Htf_single_active = sum(Hp_ft, 3);

    if isfield(nom, 'rx_angle_deg') && ~isempty(nom.rx_angle_deg)
        path_angles_deg = nom.rx_angle_deg(:).';
    else
        path_angles_deg = zeros(1, P);
    end

    [Htf_active, bf] = uwa_apply_line_array_beamforming( ...
        cfg, freq_hz, Hp_ft, path_angles_deg, abs(ls.hp_ls(:).'));

    ch = struct();
    ch.freq_hz    = freq_hz(:);
    ch.time_s     = time_s(:).';
    ch.tau_nom_s  = nom.tau_nom_s(:).';
    ch.tau_s      = ls.tau_s(:).';
    ch.hp_nom     = nom.hp_nom(:).';
    ch.hp_ls      = ls.hp_ls(:).';
    ch.gamma_ft   = gamma_ft;
    ch.H0_f       = H0_f(:);
    ch.Hp_ft      = Hp_ft;
    ch.Htf_single_active = Htf_single_active;
    ch.Htf_active = Htf_active;
    ch.path_angles_deg = path_angles_deg;
    ch.rx_array   = bf;
end

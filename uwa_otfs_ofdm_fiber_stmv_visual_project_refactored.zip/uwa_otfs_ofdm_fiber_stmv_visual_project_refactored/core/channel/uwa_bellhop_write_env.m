function envfile = uwa_bellhop_write_env(cfg, workdir, tag)
%UWA_BELLHOP_WRITE_ENV
% Write a Bellhop .env file compatible with the current atWin10_2020_11_4 build.

    if ~exist(workdir, 'dir')
        mkdir(workdir);
    end

    envfile = fullfile(workdir, [tag '.env']);
    fid = fopen(envfile, 'w');
    if fid < 0
        error('Cannot create Bellhop env file: %s', envfile);
    end

    % ------------------------------------------------------------
    % Header
    % ------------------------------------------------------------
    fprintf(fid, '''%s''\n', tag);              % Title
    fprintf(fid, '%.1f\n', cfg.fc_hz);         % Frequency (Hz)
    fprintf(fid, '1\n');                       % NMEDIA
    fprintf(fid, '''SVWT''\n');                % Surface/SSP/Volume/Top options

    % ------------------------------------------------------------
    % Water column SSP
    % Match the working Pekeris-style structure:
    %   NMESH  SIGMA  DEPTH
    % then two SSP points: z=0 and z=H
    % ------------------------------------------------------------
    fprintf(fid, '1 0.0 %.1f\n', cfg.water_depth_m);

    % z c alphaR rho alphaI betaI /
    % Use two points explicitly to close the SSP cleanly.
    fprintf(fid, '0.0 %.1f 0.0 1.0 0.0 0.0 /\n', cfg.sound_speed);
    fprintf(fid, '%.1f %.1f 0.0 1.0 0.0 0.0 /\n', cfg.water_depth_m, cfg.sound_speed);

    % ------------------------------------------------------------
    % Bottom half-space
    % This matches the style implied by the Pekeris .prt:
    %   'A' 0.0
    %   z_b  c_b  betaR  rho_b  alphaI  betaI /
    % ------------------------------------------------------------
    fprintf(fid, '''A'' 0.0\n');
    fprintf(fid, '%.1f %.1f 0.0 %.2f %.2f 0.0 /\n', ...
        cfg.water_depth_m, ...
        cfg.bottom_soundspeed, ...
        cfg.bottom_density, ...
        cfg.bottom_atten);

    % ------------------------------------------------------------
    % Source depths
    % ------------------------------------------------------------
    fprintf(fid, '1\n');
    fprintf(fid, '%.1f /\n', cfg.tx_depth_m);

    % ------------------------------------------------------------
    % Receiver depths
    % ------------------------------------------------------------
    fprintf(fid, '1\n');
    fprintf(fid, '%.1f /\n', cfg.rx_depth_m);

    % ------------------------------------------------------------
    % Receiver ranges (km)
    % ------------------------------------------------------------
    fprintf(fid, '1\n');
    fprintf(fid, '%.3f /\n', cfg.range_m / 1000);

    % ------------------------------------------------------------
    % Run type: arrivals
    % ------------------------------------------------------------
    fprintf(fid, '''A''\n');

    % Number of beams (0 lets Bellhop choose)
    fprintf(fid, '0\n');

    % Launch angle limits
    fprintf(fid, '-80.0 80.0 /\n');

    % Step, ZBOX, RBOX
    fprintf(fid, '0.0 %.1f %.3f\n', cfg.water_depth_m, cfg.range_m / 1000);

    fclose(fid);
end

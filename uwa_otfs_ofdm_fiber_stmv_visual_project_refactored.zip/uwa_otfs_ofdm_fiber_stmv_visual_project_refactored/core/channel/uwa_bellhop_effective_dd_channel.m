function h_dd = uwa_bellhop_effective_dd_channel(ch, cfg)
%UWA_BELLHOP_EFFECTIVE_DD_CHANNEL Effective DD kernel via impulse probing.
%
% This is an approximation that maps the exact Bellhop TF channel to an
% equivalent DD circular-convolution kernel, so the existing DD-domain
% equalizers in Figure 5/6 can still be reused.

    Xdd = zeros(cfg.Ndd, cfg.Mdd);
    Xdd(1,1) = 1;

    h_dd = uwa81_apply_otfs_tf_channel(Xdd, ch, cfg, 0);
end

function nom = uwa_synthetic_nominal_paths(cfg, seed)
%UWA_SYNTHETIC_NOMINAL_PATHS Deterministic fallback nominal UWA paths.
%
% This is not a replacement for Bellhop.  It is a reproducible educational
% fallback used when Bellhop is not installed, so the OTFS/OFDM chain and the
% improved-STMV array model remain runnable.

    if nargin < 2 || isempty(seed)
        seed = 1;
    end
    rng(seed);

    P = min(local_get(cfg, 'num_paths_max', 12), 6);
    c = local_get(cfg, 'sound_speed', 1500);
    range_m = local_get(cfg, 'range_m', 1000);
    tx_depth = local_get(cfg, 'tx_depth_m', 20);
    rx_depth = local_get(cfg, 'rx_depth_m', 50);
    water_depth = local_get(cfg, 'water_depth_m', 100);

    direct_len = sqrt(range_m^2 + (rx_depth - tx_depth)^2);
    surface_len = sqrt(range_m^2 + (rx_depth + tx_depth)^2);
    bottom_len = sqrt(range_m^2 + (2*water_depth - rx_depth - tx_depth)^2);
    surf_bottom_len = sqrt(range_m^2 + (2*water_depth + rx_depth - tx_depth)^2);
    two_bounce_len = sqrt(range_m^2 + (2*water_depth + rx_depth + tx_depth)^2);
    extra_len = direct_len + [0 22 48 75 110 150];

    lp = [direct_len surface_len bottom_len surf_bottom_len two_bounce_len extra_len(6)];
    lp = lp(1:P);
    tau = lp / c;

    % Simple physically plausible amplitude profile: pathloss + reflection signs.
    amp = [1.00 -0.72 0.55 -0.38 0.25 -0.18];
    amp = amp(1:P) .* exp(-0.22 * (0:P-1));

    % Receiver grazing/elevation angles in degrees. Direct path from geometry;
    % reflected paths are assigned alternating signs to exercise beamforming.
    direct_ang = atan2d(rx_depth - tx_depth, range_m);
    rx_angle = direct_ang + [0 8 -11 16 -20 24];
    rx_angle = rx_angle(1:P);

    idx = uwa_center_active_indices(cfg.fft_size, cfg.num_active_sc);
    k_rel = idx(:) - 1 - floor(cfg.fft_size/2);
    freq_hz = cfg.fc_hz + k_rel * cfg.delta_f_hz;

    A0_f = uwa81_pathloss(freq_hz, lp(1), cfg.spread_factor);
    A0_fc = uwa81_pathloss(cfg.fc_hz, lp(1), cfg.spread_factor);
    H0_f = A0_f / (A0_fc + eps);
    A_fc = uwa81_pathloss(cfg.fc_hz, lp, cfg.spread_factor);
    hp_nom = amp(:).' .* (A_fc(:).' / (A0_fc + eps));

    nom = struct();
    nom.lp_m = lp(:).';
    nom.tau_nom_s = tau(:).';
    nom.hp_nom = hp_nom(:).';
    nom.H0_f = H0_f(:);
    nom.ns = zeros(1, P);
    nom.nb = zeros(1, P);
    nom.src_angle_deg = -rx_angle(:).';
    nom.rx_angle_deg = rx_angle(:).';
    nom.angle_source = 'deterministic_synthetic_fallback';
    nom.warning = 'Bellhop executable was unavailable; deterministic synthetic paths were used.';
end

function v = local_get(cfg, name, default_value)
    if isfield(cfg, name) && isnumeric(cfg.(name)) && isscalar(cfg.(name)) && isfinite(cfg.(name))
        v = cfg.(name);
    else
        v = default_value;
    end
end

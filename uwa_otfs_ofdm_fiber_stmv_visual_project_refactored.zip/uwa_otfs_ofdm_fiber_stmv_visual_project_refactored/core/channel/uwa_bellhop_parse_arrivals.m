function arr = uwa_bellhop_parse_arrivals(arrfile, num_paths_max)
%UWA_BELLHOP_PARSE_ARRIVALS
% Parse Bellhop .arr file for the current atWin10_2020_11_4 build.
%
% Expected format observed from user's Bellhop output:
%   line 1 : '2D'
%   line 2 : frequency
%   line 3 : NSD  SD
%   line 4 : NRD  RD
%   line 5 : NRR  RR
%   line 6 : NArr (maybe for first receiver)
%   line 7 : NArr repeated
%   line 8+ : arrivals, one per line
%
% Arrival row format (8 columns observed):
%   1: amplitude magnitude
%   2: phase-like quantity
%   3: delay (s)
%   4: imag-like quantity / aux
%   5: src angle (deg)
%   6: rcv angle (deg)
%   7: # surface reflections
%   8: # bottom reflections

    fid = fopen(arrfile, 'r');
    if fid < 0
        error('Cannot open arr file: %s', arrfile);
    end

    C = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
    fclose(fid);

    lines = C{1};
    lines = lines(~cellfun(@isempty, lines));

    if numel(lines) < 8
        error('ARR file too short: %s', arrfile);
    end

    hdr = strtrim(lines{1});
    if ~contains(hdr, '2D')
        warning('Unexpected ARR header: %s', hdr);
    end

    data_lines = lines(8:end);

    amp = [];
    tau = [];
    src_angle_deg = [];
    rx_angle_deg = [];
    ns = [];
    nb = [];

    for i = 1:numel(data_lines)
        vals = sscanf(strtrim(data_lines{i}), '%f');

        if numel(vals) >= 8
            amp_i = vals(1);
            tau_i = vals(3);
            src_i = vals(5);
            rx_i  = vals(6);
            ns_i  = vals(7);
            nb_i  = vals(8);

            if isfinite(amp_i) && isfinite(tau_i) && tau_i > 0
                amp(end+1) = amp_i; %#ok<AGROW>
                tau(end+1) = tau_i; %#ok<AGROW>
                src_angle_deg(end+1) = src_i; %#ok<AGROW>
                rx_angle_deg(end+1)  = rx_i;  %#ok<AGROW>
                ns(end+1)  = ns_i;  %#ok<AGROW>
                nb(end+1)  = nb_i;  %#ok<AGROW>
            end
        end
    end

    if isempty(tau)
        error('No valid arrivals parsed from %s', arrfile);
    end

    [tau, ord] = sort(tau, 'ascend');
    amp = amp(ord);
    src_angle_deg = src_angle_deg(ord);
    rx_angle_deg = rx_angle_deg(ord);
    ns = ns(ord);
    nb = nb(ord);

    keep = true(size(tau));
    tol_tau = 5e-5;  % 50 microseconds
    for k = 2:numel(tau)
        if abs(tau(k) - tau(k-1)) < tol_tau
            if amp(k) > amp(k-1)
                keep(k-1) = false;
            else
                keep(k) = false;
            end
        end
    end

    tau = tau(keep);
    amp = amp(keep);
    src_angle_deg = src_angle_deg(keep);
    rx_angle_deg = rx_angle_deg(keep);
    ns = ns(keep);
    nb = nb(keep);

    [~, idx] = sort(amp, 'descend');
    idx = idx(1:min(num_paths_max, numel(idx)));

    arr.tau_s = tau(idx);
    arr.amp = amp(idx);
    arr.src_angle_deg = src_angle_deg(idx);
    arr.rx_angle_deg = rx_angle_deg(idx);
    arr.ns = ns(idx);
    arr.nb = nb(idx);

    [arr.tau_s, ord2] = sort(arr.tau_s, 'ascend');
    arr.amp = arr.amp(ord2);
    arr.src_angle_deg = arr.src_angle_deg(ord2);
    arr.rx_angle_deg = arr.rx_angle_deg(ord2);
    arr.ns = arr.ns(ord2);
    arr.nb = arr.nb(ord2);
end

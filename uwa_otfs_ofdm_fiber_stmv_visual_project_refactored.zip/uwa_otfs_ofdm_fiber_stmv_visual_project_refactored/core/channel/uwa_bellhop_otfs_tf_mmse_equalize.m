function Xhat_dd = uwa_bellhop_otfs_tf_mmse_equalize(Ydd, ch, cfg, noise_var)
%UWA_BELLHOP_OTFS_TF_MMSE_EQUALIZE Exact TF-domain MMSE equalization for OTFS.
%
% Channel model:
%   Xdd -> Xtf -> Htf_active .* Xtf + W -> Ytf -> Ydd
%
% This detector works directly in TF and then transforms back to DD.

    if nargin < 4
        noise_var = 0;
    end

    Htf = ch.Htf_active;

    Ytf = fft(ifft(Ydd, [], 1) * sqrt(cfg.Ndd), [], 2) / sqrt(cfg.Mdd);
    Xtf_hat = Ytf .* conj(Htf) ./ (abs(Htf).^2 + max(noise_var, 1e-12));
    Xhat_dd = fft(ifft(Xtf_hat, [], 2) * sqrt(cfg.Mdd), [], 1) / sqrt(cfg.Ndd);
end

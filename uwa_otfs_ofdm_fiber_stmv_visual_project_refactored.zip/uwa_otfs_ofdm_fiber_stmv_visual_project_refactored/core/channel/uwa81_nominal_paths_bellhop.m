function nom = uwa81_nominal_paths_bellhop(cfg, seed)
%UWA81_NOMINAL_PATHS_BELLHOP 用 Bellhop 生成名义路径

    if nargin < 2
        seed = 1;
    end

    rng(seed);

    workdir = cfg.bellhop_tmp_dir;
    tag = sprintf('uwa_%d', seed);

    envfile = uwa_bellhop_write_env(cfg, workdir, tag);
    arrfile = uwa_bellhop_run(cfg, envfile);
    arr = uwa_bellhop_parse_arrivals(arrfile, cfg.num_paths_max);

    % 绝对频率
    idx = uwa_center_active_indices(cfg.fft_size, cfg.num_active_sc);
    k_rel = idx(:) - 1 - floor(cfg.fft_size/2);
    freq_base = k_rel * cfg.delta_f_hz;
    freq_hz = cfg.fc_hz + freq_base;

    % Common filter H0(f), normalized by reference path
    l0 = arr.tau_s(1) * cfg.sound_speed;
    A0_f  = uwa81_pathloss(freq_hz, l0, cfg.spread_factor);
    A0_fc = uwa81_pathloss(cfg.fc_hz, l0, cfg.spread_factor);
    H0_f = A0_f / (A0_fc + eps);

    % Nominal path gains
    lp = arr.tau_s * cfg.sound_speed;
    A_fc = uwa81_pathloss(cfg.fc_hz, lp, cfg.spread_factor);

    % Treat Bellhop amplitude magnitude as nominal path weighting
    hp_nom = arr.amp(:).' .* (A_fc(:).' / (A0_fc + eps));

    nom = struct();
    nom.lp_m      = lp(:).';
    nom.tau_nom_s = arr.tau_s(:).';
    nom.hp_nom    = hp_nom(:).';
    nom.H0_f      = H0_f(:);
    nom.ns        = arr.ns(:).';
    nom.nb        = arr.nb(:).';
    if isfield(arr, 'src_angle_deg')
        nom.src_angle_deg = arr.src_angle_deg(:).';
    else
        nom.src_angle_deg = zeros(size(nom.tau_nom_s));
    end
    if isfield(arr, 'rx_angle_deg')
        nom.rx_angle_deg = arr.rx_angle_deg(:).';
    else
        nom.rx_angle_deg = zeros(size(nom.tau_nom_s));
    end
    nom.angle_source = 'bellhop_arrivals';
end

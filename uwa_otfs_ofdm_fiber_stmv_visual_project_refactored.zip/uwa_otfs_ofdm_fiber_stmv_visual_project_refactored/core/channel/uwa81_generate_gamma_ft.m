function gamma_ft = uwa81_generate_gamma_ft(freq_hz, time_s, hp_ls, ss)
%UWA81_GENERATE_GAMMA_FT
% Generate gamma_p(f,t) as a multivariate AR-1 process over frequency.
%
% This follows the logic of [81] Sec III-E / Eq. (30):
% frequency-correlated process vector over active frequencies,
% evolved in time with AR-1 recursion.

    Ka = numel(freq_hz);
    M  = numel(time_s);

    % ------------------------------------------------------------
    % Frequency correlation matrix from Gaussian intrapath delays
    % A practical form consistent with [81] Sec III-C
    % ------------------------------------------------------------
    df = freq_hz(:) - freq_hz(:).';
    Rf = exp(-2 * pi^2 * (ss.sigma_tau_s^2) * (df.^2));

    % Stabilize numerically
    Rf = (Rf + Rf') / 2;
    Rf = Rf + 1e-10 * eye(Ka);

    % Cholesky for colored Gaussian vectors
    Lf = chol(Rf, 'lower');

    % ------------------------------------------------------------
    % AR-1 over time
    % gamma(:,m) = rho*gamma(:,m-1) + w(:,m)
    % with proper innovation scaling to preserve covariance Rf
    % ------------------------------------------------------------
    rho = ss.rho_t;
    innov_scale = sqrt(max(1 - rho^2, 1e-8));

    gamma_ft = zeros(Ka, M);

    % Initial state
    z0 = (randn(Ka,1) + 1j*randn(Ka,1)) / sqrt(2);
    g_prev = ss.mu + ss.sigma_c * (Lf * z0);

    gamma_ft(:,1) = g_prev;

    for m = 2:M
        w = (randn(Ka,1) + 1j*randn(Ka,1)) / sqrt(2);
        innov = ss.sigma_c * innov_scale * (Lf * w);
        g_now = ss.mu + rho * (g_prev - ss.mu) + innov;
        gamma_ft(:,m) = g_now;
        g_prev = g_now;
    end

    % Optional path-gain normalization (keep gamma around unit scale)
    gamma_ft = gamma_ft / sqrt(mean(abs(gamma_ft(:)).^2) + eps);
end

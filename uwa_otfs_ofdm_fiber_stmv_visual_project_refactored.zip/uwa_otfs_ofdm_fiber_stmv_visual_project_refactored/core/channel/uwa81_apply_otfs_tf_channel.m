function Ydd = uwa81_apply_otfs_tf_channel(Xdd, ch, cfg, noise_var)
%UWA81_APPLY_OTFS_TF_CHANNEL
% Apply the [81]-style TF channel to OTFS by:
% DD -> TF(active) -> channel Htf_active -> TF -> DD
%
% Input:
%   Xdd       : [Ndd x Mdd]
%   ch        : output of uwa_alg32_stat_channel81
%   cfg       : config
%   noise_var : scalar noise variance on active TF tones
%
% Output:
%   Ydd       : [Ndd x Mdd]

    if nargin < 4
        noise_var = 0;
    end

    % DD -> TF(active), same unitary transform as OTFS modulator
    Xtf = fft(ifft(Xdd, [], 1) * sqrt(cfg.Ndd), [], 2) / sqrt(cfg.Mdd);

    % Through TF channel
    Ytf = ch.Htf_active .* Xtf;

    if noise_var > 0
        Ytf = Ytf + uwa_complex_awgn(size(Ytf), noise_var);
    end

    % TF -> DD
    Ydd = fft(ifft(Ytf, [], 2) * sqrt(cfg.Mdd), [], 1) / sqrt(cfg.Ndd);
end

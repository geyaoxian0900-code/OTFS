function ss = uwa81_small_scale_params(cfg, nom, p, doppler_factor)
%UWA81_SMALL_SCALE_PARAMS
% Build per-path small-scale parameters inspired by [81] Sec III-IV.
%
% We separate:
%   - path mean (Rice component)
%   - diffuse variance
%   - frequency correlation via sigma_tau
%   - time correlation via AR-1 coefficient tied to Doppler

    f0 = cfg.fc_hz;

    % More surface encounters -> stronger scattering and larger delay spread
    nsurf = nom.ns(p);
    nbot  = nom.nb(p);

    % Micropath delay std in seconds (engineering, but paper-consistent)
    sigma_tau = (20e-6) * (1 + 0.8*nsurf + 0.3*nbot);

    % Rice factor:
    % direct path stronger LOS, reflected paths weaker LOS
    if p == 1
        KdB = 8;
    elseif nsurf == 0 && nbot == 1
        KdB = 4;
    else
        KdB = 1.5 / (1 + 0.3*nsurf);
    end
    Klin = 10^(KdB/10);

    % Mean and diffuse std for conditional Ricean coefficient
    mu = sqrt(Klin / (Klin + 1));
    sigma_c = sqrt(1 / (Klin + 1));

    % Doppler-related temporal correlation
    % [81] shows Bessel-like temporal correlation; here we convert that
    % into a practical AR-1 coefficient for discrete-time simulation.
    %
    % Effective path-dependent Doppler frequency:
    fd = doppler_factor * f0 * (1 + 0.3*nsurf);

    Tsym = (cfg.fft_size + cfg.cp_ofdm) / cfg.fs;
    rho_t = besselj(0, 2*pi*fd*Tsym);
    rho_t = max(min(real(rho_t), 0.995), -0.995);

    ss = struct();
    ss.sigma_tau_s = sigma_tau;
    ss.mu          = mu;
    ss.sigma_c     = sigma_c;
    ss.rho_t       = rho_t;
    ss.fd_hz       = fd;
end

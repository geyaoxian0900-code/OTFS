function A = uwa81_pathloss(freq_hz, dist_m, kappa_spread)
%UWA81_PATHLOSS
% Basic underwater acoustic path loss inspired by [81] Sec II-A, Eq. (1).
%
% A(l,f) = A0 * l^{-k} * a(f)^{-l}
% Here we use Thorp absorption in dB/km and convert to linear amplitude.

    dist_km = dist_m / 1000;

    f_khz = freq_hz(:) / 1e3;

    % Thorp absorption in dB/km
    alpha_db_per_km = 0.11 * (f_khz.^2) ./ (1 + f_khz.^2) + ...
                      44   * (f_khz.^2) ./ (4100 + f_khz.^2) + ...
                      2.75e-4 * f_khz.^2 + 0.003;

    % amplitude attenuation over distance
    absorb_amp = 10.^(-(alpha_db_per_km .* dist_km) / 20);

    % spreading
    spread_amp = (dist_m + eps).^(-kappa_spread/2);

    A = absorb_amp .* spread_amp;
end

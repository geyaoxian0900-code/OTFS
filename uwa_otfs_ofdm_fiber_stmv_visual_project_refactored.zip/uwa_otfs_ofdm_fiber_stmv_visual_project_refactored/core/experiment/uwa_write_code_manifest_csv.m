function uwa_write_code_manifest_csv(filename, manifest)
%UWA_WRITE_CODE_MANIFEST_CSV Save manifest as CSV.

    fid = fopen(filename, 'w');
    if fid < 0
        warning('Could not write code manifest CSV: %s', filename);
        return;
    end
    fprintf(fid, 'relative_path,bytes,datenum,md5\n');
    for i = 1:numel(manifest)
        fprintf(fid, '"%s",%d,%.10f,%s\n', strrep(manifest(i).relative_path, '"', '""'), ...
            manifest(i).bytes, manifest(i).datenum, manifest(i).md5);
    end
    fclose(fid);
end

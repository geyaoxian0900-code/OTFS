function manifest = uwa_code_manifest(project_root)
%UWA_CODE_MANIFEST Collect file size, modification time, and MD5 hashes.

    files = [dir(fullfile(project_root, '**', '*.m')); ...
             dir(fullfile(project_root, '**', '*.md')); ...
             dir(fullfile(project_root, '**', '*.txt'))];
    rows = struct('relative_path', {}, 'bytes', {}, 'datenum', {}, 'md5', {});
    for i = 1:numel(files)
        if files(i).isdir
            continue;
        end
        fullp = fullfile(files(i).folder, files(i).name);
        relp = erase(fullp, [project_root filesep]);
        if contains(relp, [filesep 'output' filesep]) || startsWith(relp, ['output' filesep])
            continue;
        end
        row.relative_path = relp;
        row.bytes = files(i).bytes;
        row.datenum = files(i).datenum;
        row.md5 = uwa_md5_file(fullp);
        rows(end+1) = row; %#ok<AGROW>
    end
    manifest = rows;
end

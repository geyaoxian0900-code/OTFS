function exp = uwa_begin_experiment(cfg, mode, entry_script)
%UWA_BEGIN_EXPERIMENT Create a reproducible run folder and start logging.

    if nargin < 2 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 3
        entry_script = '';
    end

    run_stamp = datestr(now, 'yyyymmdd_HHMMSS');
    method = 'unknown';
    if isfield(cfg, 'rx_array') && isfield(cfg.rx_array, 'combine_method')
        method = cfg.rx_array.combine_method;
    end
    run_id = sprintf('%s_%s_%s_seed%d', run_stamp, lower(mode), method, cfg.seed_base);
    run_id = regexprep(run_id, '[^A-Za-z0-9_\-]', '_');

    if isfield(cfg, 'output_root')
        root = cfg.output_root;
    elseif isfield(cfg, 'output_dir')
        root = fileparts(cfg.output_dir);
    else
        root = fullfile(pwd, 'output');
    end

    run_dir = fullfile(root, 'runs', run_id);
    if ~exist(run_dir, 'dir')
        mkdir(run_dir);
    end

    % Save a snapshot that points to the actual run folder.
    cfg.output_dir = run_dir;
    cfg.run_dir = run_dir;
    cfg.bellhop_tmp_dir = uwa_make_short_bellhop_tmp_dir(run_id);
    cfg.bellhop_cache_dir = fullfile(run_dir, 'bellhop_cache');

    exp = struct();
    exp.run_id = run_id;
    exp.run_dir = run_dir;
    exp.mode = mode;
    exp.entry_script = entry_script;
    exp.started_at = datestr(now, 31);
    exp.log_file = fullfile(run_dir, 'run_log.txt');
    exp.reproduction_file = fullfile(run_dir, 'reproduce_this_run.txt');

    fid = fopen(exp.reproduction_file, 'w');
    if fid > 0
        fprintf(fid, 'Reproduce this run from MATLAB at package root:\n');
        if isempty(entry_script)
            fprintf(fid, 'run_complete_uwa_otfs_ofdm_chain(''%s'', ''%s'');\n', mode, method);
        elseif strcmp(entry_script, 'run_complete_uwa_otfs_ofdm_chain')
            fprintf(fid, '%s(''%s'', ''%s'');\n', entry_script, mode, method);
        else
            fprintf(fid, '%s(''%s'');\n', entry_script, mode);
        end
        fprintf(fid, '\nBeamformer: %s\n', method);
        fprintf(fid, 'Seed base: %d\n', cfg.seed_base);
        fprintf(fid, 'Run created: %s\n', exp.started_at);
        fclose(fid);
    end

    try
        diary(exp.log_file);
    catch
        warning('Could not start diary log at %s', exp.log_file);
    end

    rng(cfg.seed_base, 'twister');
    rng_state = rng; %#ok<NASGU>
    save(fullfile(run_dir, 'rng_initial_state.mat'), 'rng_state');

    cfg_snapshot = cfg; %#ok<NASGU>
    save(fullfile(run_dir, 'config_snapshot.mat'), 'cfg_snapshot');
    if isfield(cfg, 'save_config_json') && cfg.save_config_json
        uwa_write_config_json(fullfile(run_dir, 'config_snapshot.json'), cfg);
    end

    if isfield(cfg, 'save_code_manifest') && cfg.save_code_manifest
        project_root = local_project_root(cfg);
        manifest = uwa_code_manifest(project_root); %#ok<NASGU>
        save(fullfile(run_dir, 'code_manifest.mat'), 'manifest');
        uwa_write_code_manifest_csv(fullfile(run_dir, 'code_manifest.csv'), manifest);
    end
end

function project_root = local_project_root(cfg)
    if isfield(cfg, 'project_root')
        project_root = cfg.project_root;
    else
        project_root = pwd;
    end
end

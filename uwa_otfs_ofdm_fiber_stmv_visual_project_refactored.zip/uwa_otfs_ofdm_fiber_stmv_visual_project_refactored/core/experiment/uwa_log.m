function uwa_log(fmt, varargin)
%UWA_LOG Print timestamped log line.

    prefix = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('[%s] ', prefix);
    fprintf(fmt, varargin{:});
    if isempty(fmt) || fmt(end) ~= sprintf('\n')
        fprintf('\n');
    end
end

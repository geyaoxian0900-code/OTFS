function uwa_write_config_json(filename, cfg)
%UWA_WRITE_CONFIG_JSON Best-effort JSON export of config struct.

    fid = fopen(filename, 'w');
    if fid < 0
        warning('Could not write config JSON: %s', filename);
        return;
    end
    try
        txt = jsonencode(cfg);
        txt = pretty_json(txt);
        fwrite(fid, txt, 'char');
    catch ME
        fprintf(fid, 'JSON export failed: %s\n', ME.message);
    end
    fclose(fid);
end

function out = pretty_json(in)
    out = in;
    out = strrep(out, ',', sprintf(',\n'));
    out = strrep(out, '{', sprintf('{\n'));
    out = strrep(out, '}', sprintf('\n}'));
end

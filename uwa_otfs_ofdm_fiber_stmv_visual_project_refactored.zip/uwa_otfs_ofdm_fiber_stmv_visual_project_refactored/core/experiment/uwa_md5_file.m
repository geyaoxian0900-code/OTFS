function md5 = uwa_md5_file(filename)
%UWA_MD5_FILE Compute an MD5 hash with Java when available.

    md5 = '';
    try
        fis = java.io.FileInputStream(java.io.File(filename));
        md = java.security.MessageDigest.getInstance('MD5');
        buffer = zeros(1, 8192, 'int8');
        while true
            n = fis.read(buffer);
            if n <= 0
                break;
            end
            md.update(buffer(1:n));
        end
        fis.close();
        hash = typecast(md.digest(), 'uint8');
        md5 = lower(reshape(dec2hex(hash, 2).', 1, []));
    catch
        try
            fid = fopen(filename, 'rb');
            data = fread(fid, Inf, '*uint8');
            fclose(fid);
            % Fallback is not cryptographic but still records content state.
            md5 = sprintf('fallback_%08x_%08x', numel(data), sum(double(data)));
        catch
            md5 = 'unavailable';
        end
    end
end

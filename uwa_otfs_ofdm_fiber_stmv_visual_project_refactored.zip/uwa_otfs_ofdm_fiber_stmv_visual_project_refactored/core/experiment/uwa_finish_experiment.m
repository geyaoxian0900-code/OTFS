function uwa_finish_experiment(exp)
%UWA_FINISH_EXPERIMENT Stop diary and write finish timestamp.

    if nargin < 1 || isempty(exp)
        return;
    end

    fid = fopen(fullfile(exp.run_dir, 'finished_at.txt'), 'w');
    if fid > 0
        fprintf(fid, '%s\n', datestr(now, 31));
        fclose(fid);
    end

    try
        diary('off');
    catch
    end
end

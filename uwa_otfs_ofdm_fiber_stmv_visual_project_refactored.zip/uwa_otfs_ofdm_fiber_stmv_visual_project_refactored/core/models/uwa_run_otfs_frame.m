function out = uwa_run_otfs_frame(cfg, tx_syms, data_idx, ch, noise_var)
%UWA_RUN_OTFS_FRAME OTFS branch with selectable detector.
%
% Supported cfg.otfs_detection.method values:
%   'tf_mmse' : existing baseline using beamformed TF-domain MMSE
%   'bf_dae'  : TF-domain beamforming preprocessing + DD-domain BF-DAE

    if ~isfield(cfg, 'otfs_detection') || ~isfield(cfg.otfs_detection, 'method') || isempty(cfg.otfs_detection.method)
        detector_method = 'tf_mmse';
    else
        detector_method = lower(strtrim(cfg.otfs_detection.method));
    end

    X_dd = zeros(cfg.Ndd, cfg.Mdd);
    X_dd(data_idx) = tx_syms;

    switch detector_method
        case {'bf_dae', 'bf-dae', 'beamforming_dae'}
            dae_out = uwa_otfs_bf_dae_detect(cfg, X_dd, ch, noise_var, data_idx);
            rx_syms = dae_out.rx_syms;
            llr = dae_out.llr;

            out = struct();
            out.detector_method = 'bf_dae';
            out.X_grid = X_dd;
            if isfield(dae_out, 'beam_dd') && ~isempty(dae_out.beam_dd)
                out.Y_grid = dae_out.beam_dd(:, :, 1);
            else
                out.Y_grid = zeros(size(X_dd));
            end
            out.X_hat_grid = dae_out.X_hat_grid;
            out.rx_syms = rx_syms;
            out.llr = llr(:).';
            out.bf_dae = dae_out;

        otherwise
            Y_dd = uwa81_apply_otfs_tf_channel(X_dd, ch, cfg, noise_var);
            X_hat_dd = uwa_bellhop_otfs_tf_mmse_equalize(Y_dd, ch, cfg, noise_var);

            rx_syms = X_hat_dd(data_idx).';
            llr = square_qam_llr(rx_syms, cfg.modulation, noise_var);

            out = struct();
            out.detector_method = 'tf_mmse';
            out.X_grid = X_dd;
            out.Y_grid = Y_dd;
            out.X_hat_grid = X_hat_dd;
            out.rx_syms = rx_syms;
            out.llr = llr(:).';
    end
end

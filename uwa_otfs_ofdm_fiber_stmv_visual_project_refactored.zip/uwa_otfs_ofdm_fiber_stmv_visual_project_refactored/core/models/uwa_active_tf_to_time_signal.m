function [time_sig, full_grid] = uwa_active_tf_to_time_signal(Xtf_active, cfg, cp_len)
%UWA_ACTIVE_TF_TO_TIME_SIGNAL Map active TF grid to full OFDM grid and serialize.

    if nargin < 3 || isempty(cp_len)
        cp_len = cfg.cp_ofdm;
    end

    full_grid = zeros(cfg.fft_size, cfg.num_symbols);
    idx = uwa_center_active_indices(cfg.fft_size, cfg.num_active_sc);
    full_grid(idx, :) = Xtf_active;
    time_sig = uwa_ofdm_modulate(full_grid, cfg.fft_size, cp_len);
end

function results = uwa_run_link_simulation(cfg, mode, exp)
%UWA_RUN_LINK_SIMULATION Complete OTFS vs OFDM link simulation.
%
% Usage:
%   results = uwa_run_link_simulation(cfg)
%   results = uwa_run_link_simulation(cfg, mode)
%   results = uwa_run_link_simulation(cfg, mode, exp)
%
% Inputs:
%   cfg  - Simulation configuration struct.
%   mode - Run mode string. Default: 'quick'.
%   exp  - Optional experiment struct. When exp.run_dir exists, it is used
%          as the output directory.
%
% Output:
%   results - Struct containing BER/PER curves, snapshot data, and metadata.
%
% Notes:
%   The numerical simulation logic is intentionally preserved. This refactor
%   only isolates directory preparation, detector selection, preallocation,
%   and result assembly into dedicated helper functions.

    if nargin < 2 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 3
        exp = struct();
    end

    cfg = uwa_prepare_link_simulation_dirs(cfg, mode, exp); % [Refactor] 原因：将目录准备和长路径防护从主仿真函数中拆分出去，降低单函数职责复杂度。

    uwa_log('Preparing nominal underwater paths...');
    nominalPathTag = ['complete_chain_' mode '_' cfg.rx_array.combine_method];
    nominalPathBundle = uwa_bellhop_get_nominal_paths(cfg, nominalPathTag);
    nominal_paths = nominalPathBundle; %#ok<NASGU>
    save(fullfile(cfg.output_dir, ['nominal_paths_' mode '.mat']), 'nominal_paths', 'cfg');

    detectorMethod = uwa_get_otfs_detector_method(cfg); % [Refactor] 原因：统一处理默认检测器解析逻辑，避免主流程夹杂字段判空分支。
    snrDbList = cfg.snr_range;
    prbList = cfg.prb_configs;

    numPrbCases = numel(prbList);
    numSnr = numel(snrDbList);
    metrics = uwa_initialize_link_metrics(numPrbCases, numSnr); % [Refactor] 原因：集中预分配所有结果数组，满足预分配重构要求。

    for prbIndex = 1:numPrbCases
        numPrb = prbList(prbIndex);
        [~, dataIdx, packetBits] = uwa_make_resource_mask(cfg, numPrb);
        numDataSymbols = numel(dataIdx);

        uwa_log('--- PRB=%d | packet_bits=%d | data_symbols=%d | OTFS detector=%s ---', ...
            numPrb, packetBits, numDataSymbols, detectorMethod);

        for snrIndex = 1:numSnr
            snrDb = snrDbList(snrIndex);
            batchMetrics = uwa_run_snr_packet_batch(cfg, dataIdx, packetBits, snrDb, prbIndex, snrIndex, nominalPathBundle); % [Refactor] 原因：把单个 PRB/SNR 工作点的包级仿真拆成独立函数，主流程只负责遍历与汇总。

            metrics.perOtfs(prbIndex, snrIndex) = batchMetrics.perOtfs;
            metrics.perOfdm(prbIndex, snrIndex) = batchMetrics.perOfdm;
            metrics.berOtfs(prbIndex, snrIndex) = batchMetrics.berOtfs;
            metrics.berOfdm(prbIndex, snrIndex) = batchMetrics.berOfdm;
            metrics.rxArraySnapshots{prbIndex, snrIndex} = batchMetrics.rxArraySnapshot;

            uwa_log('SNR=%5.1f dB | BER OTFS=%1.3e OFDM=%1.3e | PER OTFS=%1.3e OFDM=%1.3e', ...
                snrDb, metrics.berOtfs(prbIndex, snrIndex), metrics.berOfdm(prbIndex, snrIndex), ...
                metrics.perOtfs(prbIndex, snrIndex), metrics.perOfdm(prbIndex, snrIndex));
        end
    end

    results = uwa_build_link_results(cfg, mode, snrDbList, prbList, metrics, detectorMethod); % [Refactor] 原因：集中构造结果结构体，减少主流程尾部样板代码。

    save(fullfile(cfg.output_dir, ['results_' mode '.mat']), 'results');
    uwa_plot_link_results(results, mode);
end

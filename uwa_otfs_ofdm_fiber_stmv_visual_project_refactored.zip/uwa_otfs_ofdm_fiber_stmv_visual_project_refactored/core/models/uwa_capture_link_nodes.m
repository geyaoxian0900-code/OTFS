function vis = uwa_capture_link_nodes(cfg, nom)
%UWA_CAPTURE_LINK_NODES Capture one representative packet through all nodes.
%
% This helper is the backbone of the expanded paper project.  It generates a
% single representative packet and records the major signal-processing nodes
% required for the paper figures:
%   - bits / coded bits / QAM symbols
%   - OTFS DD / TF / time-domain transmit nodes
%   - OFDM TF / time-domain transmit nodes
%   - single-sensor and beamformed TF/time nodes
%   - OTFS DD/TF receive and equalized nodes
%   - OFDM TF receive and equalized nodes
%   - array element TF data for azimuth-spectrum / beam-pattern figures
%
% The representative operating point comes from cfg.visual.

    if nargin < 2
        nom = [];
    end

    if ~isfield(cfg, 'visual') || isempty(cfg.visual)
        error('uwa_capture_link_nodes: cfg.visual is required. Use visualization_project_config().');
    end

    rep_prb = cfg.visual.rep_prb;
    rep_snr_dB = cfg.visual.rep_snr_dB;
    rep_seed = cfg.visual.rep_seed;
    noise_var = 1 / (cfg.code_rate * log2(cfg.modulation) * 10^(rep_snr_dB / 10));

    [resource_mask, data_idx, packet_bits] = uwa_make_resource_mask(cfg, rep_prb);
    num_data_symbols = numel(data_idx);
    pkt = uwa_build_tx_packet(cfg, packet_bits, num_data_symbols);

    [ch, h_eff, meta] = uwa_bellhop_prepare_frame_channel(cfg, rep_seed, nom); %#ok<ASGLU>
    [Htf_elem, elem_meta] = uwa_build_element_channel_response(cfg, ch);

    % ------------------------------------------------------------------
    % Common payload / metadata
    % ------------------------------------------------------------------
    vis = struct();
    vis.cfg = cfg;
    vis.rep_prb = rep_prb;
    vis.rep_snr_dB = rep_snr_dB;
    vis.noise_var = noise_var;
    vis.resource_mask = resource_mask;
    vis.data_idx = data_idx;
    vis.packet_bits = packet_bits;
    vis.num_data_symbols = num_data_symbols;
    vis.packet = pkt;
    vis.channel = ch;
    vis.channel_meta = meta;
    vis.effective_dd_channel = h_eff;
    vis.array = struct();
    vis.array.Htf_elem = Htf_elem;
    vis.array.meta = elem_meta;
    vis.array.weights_full = uwa_beamformer_extract_full_weights(ch.rx_array);
    vis.array.element1_zero_index = cfg.visual.zeroed_element_index;

    % Use a flat probe to make array-only beamforming figures cleaner.
    probe_tf = ones(cfg.Ndd, cfg.Mdd);
    vis.array.probe_elem_tf_clean = local_apply_tf_probe(Htf_elem, probe_tf);
    vis.array.probe_elem_tf_zeroed = vis.array.probe_elem_tf_clean;
    if cfg.visual.zeroed_element_index >= 1 && cfg.visual.zeroed_element_index <= size(Htf_elem, 3)
        vis.array.probe_elem_tf_zeroed(:, :, cfg.visual.zeroed_element_index) = 0;
    end

    % ------------------------------------------------------------------
    % OTFS branch
    % ------------------------------------------------------------------
    otfs = struct();
    otfs.Xdd_tx = zeros(cfg.Ndd, cfg.Mdd);
    otfs.Xdd_tx(data_idx) = pkt.symbols;
    otfs.Xtf_tx = uwa_otfs_isfft(otfs.Xdd_tx, cfg);
    [otfs.tx_time, otfs.Xfull_tx] = uwa_active_tf_to_time_signal(otfs.Xtf_tx, cfg, cfg.cp_otfs);

    otfs.Ytf_single_clean = ch.Htf_single_active .* otfs.Xtf_tx;
    otfs.Ytf_beam_clean = ch.Htf_active .* otfs.Xtf_tx;
    otfs.Ytf_beam_noisy = otfs.Ytf_beam_clean + uwa_complex_awgn(size(otfs.Ytf_beam_clean), noise_var);

    otfs.Ydd_beam_noisy = uwa_otfs_sfft(otfs.Ytf_beam_noisy, cfg);
    otfs.Xdd_hat = uwa_bellhop_otfs_tf_mmse_equalize(otfs.Ydd_beam_noisy, ch, cfg, noise_var);
    otfs.Xtf_hat = uwa_otfs_isfft(otfs.Xdd_hat, cfg);

    [otfs.rx_time_single, otfs.Yfull_single] = uwa_active_tf_to_time_signal(otfs.Ytf_single_clean, cfg, cfg.cp_otfs);
    [otfs.rx_time_beam, otfs.Yfull_beam] = uwa_active_tf_to_time_signal(otfs.Ytf_beam_noisy, cfg, cfg.cp_otfs);

    otfs.rx_syms_pre = otfs.Ydd_beam_noisy(data_idx).';
    otfs.rx_syms_post = otfs.Xdd_hat(data_idx).';
    otfs.llr = square_qam_llr(otfs.rx_syms_post, cfg.modulation, noise_var);
    otfs.decoded_bits = ldpc_decode(otfs.llr, cfg.code_rate, packet_bits, 0, 'QAM');
    if isempty(otfs.decoded_bits)
        otfs.decoded_bits = zeros(1, packet_bits);
    end
    otfs.decoded_bits = double(otfs.decoded_bits(:)).';
    otfs.decoded_bits = otfs.decoded_bits(1:min(packet_bits, numel(otfs.decoded_bits)));

    % Element-domain received TF/time data for OTFS node figures.
    otfs.Ytf_elem_clean = local_apply_tf_probe(Htf_elem, otfs.Xtf_tx);
    otfs.Ytf_elem_noisy = otfs.Ytf_elem_clean + uwa_complex_awgn(size(otfs.Ytf_elem_clean), noise_var);
    otfs.beam_weights = vis.array.weights_full;
    otfs.Ytf_from_weights = uwa_apply_weights_to_array_tf(otfs.Ytf_elem_noisy, otfs.beam_weights);
    [otfs.rx_time_elem1, otfs.Yfull_elem1] = uwa_active_tf_to_time_signal(squeeze(otfs.Ytf_elem_noisy(:, :, 1)), cfg, cfg.cp_otfs);

    % Optional OTFS BF-DAE branch: TF beamforming preprocessing + DD DAE.
    if isfield(cfg, 'visual') && isfield(cfg.visual, 'capture_bf_dae') && cfg.visual.capture_bf_dae
        otfs_bf_dae = uwa_otfs_bf_dae_detect(cfg, otfs.Xdd_tx, ch, noise_var, data_idx);
        otfs_bf_dae.decoded_bits = ldpc_decode(otfs_bf_dae.llr, cfg.code_rate, packet_bits, 0, 'QAM');
        if isempty(otfs_bf_dae.decoded_bits)
            otfs_bf_dae.decoded_bits = zeros(1, packet_bits);
        end
        otfs_bf_dae.decoded_bits = double(otfs_bf_dae.decoded_bits(:)).';
        otfs_bf_dae.decoded_bits = otfs_bf_dae.decoded_bits(1:min(packet_bits, numel(otfs_bf_dae.decoded_bits)));
        if isfield(otfs_bf_dae, 'beam_tf') && ~isempty(otfs_bf_dae.beam_tf)
            [otfs_bf_dae.rx_time_beam1, otfs_bf_dae.Yfull_beam1] = uwa_active_tf_to_time_signal(otfs_bf_dae.beam_tf(:, :, 1), cfg, cfg.cp_otfs);
        else
            otfs_bf_dae.rx_time_beam1 = zeros(size(otfs.tx_time));
            otfs_bf_dae.Yfull_beam1 = zeros(size(otfs.Xfull_tx));
        end
        if isfield(otfs_bf_dae, 'beam_dd') && ~isempty(otfs_bf_dae.beam_dd)
            otfs_bf_dae.beam_dd_first = otfs_bf_dae.beam_dd(:, :, 1);
            otfs_bf_dae.beam_tf_first = otfs_bf_dae.beam_tf(:, :, 1);
            otfs_bf_dae.rx_syms_pre = otfs_bf_dae.beam_dd_first(data_idx).';
        else
            otfs_bf_dae.beam_dd_first = zeros(size(otfs.Xdd_tx));
            otfs_bf_dae.beam_tf_first = zeros(size(otfs.Xtf_tx));
            otfs_bf_dae.rx_syms_pre = zeros(1, numel(data_idx));
        end
        otfs_bf_dae.rx_syms_post = otfs_bf_dae.X_hat_grid(data_idx).';
        vis.otfs_bf_dae = otfs_bf_dae;
    end

    % ------------------------------------------------------------------
    % OFDM branch
    % ------------------------------------------------------------------
    ofdm = struct();
    ofdm.Xtf_tx = zeros(cfg.Ndd, cfg.Mdd);
    ofdm.Xtf_tx(data_idx) = pkt.symbols;
    [ofdm.tx_time, ofdm.Xfull_tx] = uwa_active_tf_to_time_signal(ofdm.Xtf_tx, cfg, cfg.cp_ofdm);

    ofdm.Ytf_single_clean = ch.Htf_single_active .* ofdm.Xtf_tx;
    ofdm.Ytf_beam_clean = ch.Htf_active .* ofdm.Xtf_tx;
    ofdm.Ytf_beam_noisy = ofdm.Ytf_beam_clean + uwa_complex_awgn(size(ofdm.Ytf_beam_clean), noise_var);
    ofdm.Xtf_hat = ofdm.Ytf_beam_noisy .* conj(ch.Htf_active) ./ (abs(ch.Htf_active).^2 + max(noise_var, 1e-12));

    [ofdm.rx_time_single, ofdm.Yfull_single] = uwa_active_tf_to_time_signal(ofdm.Ytf_single_clean, cfg, cfg.cp_ofdm);
    [ofdm.rx_time_beam, ofdm.Yfull_beam] = uwa_active_tf_to_time_signal(ofdm.Ytf_beam_noisy, cfg, cfg.cp_ofdm);

    ofdm.rx_syms_pre = ofdm.Ytf_beam_noisy(data_idx).';
    ofdm.rx_syms_post = ofdm.Xtf_hat(data_idx).';
    ofdm.llr = square_qam_llr(ofdm.rx_syms_post, cfg.modulation, noise_var);
    ofdm.decoded_bits = ldpc_decode(ofdm.llr, cfg.code_rate, packet_bits, 0, 'QAM');
    if isempty(ofdm.decoded_bits)
        ofdm.decoded_bits = zeros(1, packet_bits);
    end
    ofdm.decoded_bits = double(ofdm.decoded_bits(:)).';
    ofdm.decoded_bits = ofdm.decoded_bits(1:min(packet_bits, numel(ofdm.decoded_bits)));

    ofdm.Ytf_elem_clean = local_apply_tf_probe(Htf_elem, ofdm.Xtf_tx);
    ofdm.Ytf_elem_noisy = ofdm.Ytf_elem_clean + uwa_complex_awgn(size(ofdm.Ytf_elem_clean), noise_var);
    ofdm.beam_weights = vis.array.weights_full;
    ofdm.Ytf_from_weights = uwa_apply_weights_to_array_tf(ofdm.Ytf_elem_noisy, ofdm.beam_weights);
    [ofdm.rx_time_elem1, ofdm.Yfull_elem1] = uwa_active_tf_to_time_signal(squeeze(ofdm.Ytf_elem_noisy(:, :, 1)), cfg, cfg.cp_ofdm);

    vis.otfs = otfs;
    vis.ofdm = ofdm;

    vis.summary = struct();
    vis.summary.info_bits = pkt.info_bits;
    vis.summary.coded_bits = pkt.coded_bits;
    vis.summary.tx_symbols = pkt.symbols(:).';
    vis.summary.decoded_bits_otfs = local_pad_bits(otfs.decoded_bits, packet_bits);
    vis.summary.decoded_bits_ofdm = local_pad_bits(ofdm.decoded_bits, packet_bits);
    vis.summary.bit_errors_otfs = sum(xor(vis.summary.info_bits, vis.summary.decoded_bits_otfs));
    vis.summary.bit_errors_ofdm = sum(xor(vis.summary.info_bits, vis.summary.decoded_bits_ofdm));
    if isfield(vis, 'otfs_bf_dae') && isfield(vis.otfs_bf_dae, 'decoded_bits')
        vis.summary.decoded_bits_otfs_bf_dae = local_pad_bits(vis.otfs_bf_dae.decoded_bits, packet_bits);
        vis.summary.bit_errors_otfs_bf_dae = sum(xor(vis.summary.info_bits, vis.summary.decoded_bits_otfs_bf_dae));
    end
end

function Ytf_elem = local_apply_tf_probe(Htf_elem, Xtf)
    [Ka, M, E] = size(Htf_elem);
    Ytf_elem = zeros(Ka, M, E);
    for e = 1:E
        Ytf_elem(:, :, e) = Htf_elem(:, :, e) .* Xtf;
    end
end

function bits = local_pad_bits(bits, L)
    bits = double(bits(:)).';
    if numel(bits) < L
        bits = [bits zeros(1, L - numel(bits))];
    elseif numel(bits) > L
        bits = bits(1:L);
    end
end

function out = uwa_run_ofdm_frame(cfg, tx_syms, data_idx, ch, noise_var)
%UWA_RUN_OFDM_FRAME OFDM branch: TF grid -> UWA channel -> MMSE -> LLR.

    X_tf = zeros(cfg.Ndd, cfg.Mdd);
    X_tf(data_idx) = tx_syms;

    X_hat_tf = uwa_bellhop_ofdm_mmse_frame(X_tf, ch, cfg, noise_var);
    rx_syms = X_hat_tf(data_idx).';
    llr = square_qam_llr(rx_syms, cfg.modulation, noise_var);

    out = struct();
    out.X_grid = X_tf;
    out.X_hat_grid = X_hat_tf;
    out.rx_syms = rx_syms;
    out.llr = llr(:).';
end

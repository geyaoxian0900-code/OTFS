function bits = qam_demod(symbols, M, varargin)
%QAM_DEMOD Gray-coded square QAM demodulation.
%
% Supported call styles:
%   bits = qam_demod(symbols, M, 'hard')
%   bits = qam_demod(symbols, M, noiseVar, 'hard')
%
% Inputs:
%   symbols  - Received QAM symbols.
%   M        - Modulation order. Supported: 4, 16, 64, 256.
%   noiseVar - Optional, ignored in hard decision mode.
%   mode     - Currently supports 'hard'.
%
% Output:
%   bits     - Column vector of recovered bits.

    if nargin < 3
        error('qam_demod requires at least 3 arguments');
    end

    if ~ismember(M, [4 16 64 256])
        error('qam_demod: only M = 4, 16, 64, 256 are supported');
    end

    if nargin == 3
        mode = varargin{1};
    elseif nargin >= 4
        mode = varargin{2};
    else
        error('qam_demod: invalid number of arguments');
    end

    if ~ischar(mode) && ~isstring(mode)
        error('qam_demod: mode must be ''hard''');
    end

    mode = char(mode);
    if ~strcmpi(mode, 'hard')
        error('qam_demod: only hard decision is supported in this version');
    end

    symbols = symbols(:);
    bitsPerSymbol = log2(M);
    modulationSide = round(sqrt(M));
    bitsPerAxis = bitsPerSymbol / 2;

    levels = -(modulationSide - 1):2:(modulationSide - 1);
    [gridI, gridQ] = meshgrid(levels, levels);
    constellationFull = gridI(:) + 1j * gridQ(:);
    normFactor = sqrt(mean(abs(constellationFull).^2));
    normalizedLevels = levels / normFactor;

    realPart = real(symbols);
    imagPart = imag(symbols);

    idxIBin = nearest_level_index(realPart, normalizedLevels) - 1; % zero-based
    idxQBin = nearest_level_index(imagPart, normalizedLevels) - 1; % zero-based

    idxIGray = bitxor(idxIBin, bitshift(idxIBin, -1));
    idxQGray = bitxor(idxQBin, bitshift(idxQBin, -1));

    bitsI = de2bi(idxIGray, bitsPerAxis, 'left-msb');
    bitsQ = de2bi(idxQGray, bitsPerAxis, 'left-msb');

    bitMatrix = [bitsI, bitsQ];
    bits = reshape(bitMatrix.', [], 1);
end

function idx = nearest_level_index(x, levels)
%NEAREST_LEVEL_INDEX Find nearest PAM level index for each input sample.
    xOriginalSize = size(x);
    xColumn = x(:);
    levelRow = levels(:).';
    [~, idx] = min(abs(bsxfun(@minus, xColumn, levelRow)), [], 2); % [Refactor] 原因：用矩阵化距离搜索替代逐样本 for 循环，并显式使用 bsxfun 保持旧版 MATLAB 兼容性。
    idx = reshape(idx, xOriginalSize);
end

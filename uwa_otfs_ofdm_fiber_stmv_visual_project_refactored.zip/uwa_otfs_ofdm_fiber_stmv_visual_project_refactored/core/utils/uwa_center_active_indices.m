function idx = uwa_center_active_indices(K,Ka)

k0=floor(K/2)-floor(Ka/2)+1;
idx=(k0:k0+Ka-1).';
end

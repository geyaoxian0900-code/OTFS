function coded = ldpc_encode(info_bits, code_rate, outlen, mod)
% LDPC_ENCODE
% 当前稳定版：卷积码 + puncture
% 说明：
%   暂不使用 LTE Turbo，避免非法块长导致失败
%
% 支持：
%   R=1/2 : 母码率 1/2 卷积码
%   R=2/3 : 1/2 卷积码 + puncture
%
% 输入:
%   info_bits  : 信息比特 (0/1)
%   code_rate  : 目标码率，支持 1/2 和 2/3
%   outlen     : 输出长度
%   mod        : 保留接口，不参与实际编码
%
% 输出:
%   coded      : 0/1 行向量，长度恰好为 outlen

    if nargin < 4
        mod = 'QPSK'; %#ok<NASGU>
    end
    if nargin < 3 || isempty(outlen)
        outlen = [];
    end

    info_bits = double(info_bits(:)).';
    if isempty(info_bits)
        coded = [];
        return;
    end

    % 卷积码：K=7, generators [171 133] (octal)
    trellis = poly2trellis(7, [171 133]);

    % 加尾比特，帮助 Viterbi 收敛
    tail = zeros(1, 6);
    msg = [info_bits tail];

    mother = convenc(msg, trellis);
    mother = double(mother(:)).';

    % puncture 模式
    if abs(code_rate - 1/2) < 1e-6
        punct_pat = [1 1];
    elseif abs(code_rate - 2/3) < 1e-6
        punct_pat = [1 1 1 0];
    else
        error('ldpc_encode: unsupported code_rate %.6f (only 1/2, 2/3 supported)', code_rate);
    end

    punct_pat = punct_pat(:).';
    rep_pat = repmat(punct_pat, 1, ceil(length(mother) / length(punct_pat)));
    rep_pat = rep_pat(1:length(mother));

    coded_tmp = mother(logical(rep_pat));
    coded_tmp = double(coded_tmp(:)).';

    if isempty(outlen)
        coded = coded_tmp;
    else
        if length(coded_tmp) < outlen
            coded = [coded_tmp, zeros(1, outlen - length(coded_tmp))];
        else
            coded = coded_tmp(1:outlen);
        end
    end

    coded = double(coded(:)).';
end

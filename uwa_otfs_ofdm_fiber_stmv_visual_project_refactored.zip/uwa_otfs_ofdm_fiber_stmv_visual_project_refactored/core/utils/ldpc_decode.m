function info_bits = ldpc_decode(rx_bits, code_rate, trblklen, rv, mod)
% LDPC_DECODE
% 当前稳定版：与 ldpc_encode.m 配套的卷积码/Viterbi 解码器
%
% 输入:
%   rx_bits    : 软值 LLR 或硬比特
%   code_rate  : 目标码率，支持 1/2 和 2/3
%   trblklen   : 原始信息比特长度
%   rv         : 保留接口
%   mod        : 保留接口
%
% 输出:
%   info_bits  : 解码信息比特；失败返回 []

    if nargin < 5
        mod = 'QPSK'; %#ok<NASGU>
    end
    if nargin < 4
        rv = 0; %#ok<NASGU>
    end

    if isempty(rx_bits)
        info_bits = [];
        return;
    end

    rx_bits = double(rx_bits(:)).';

    % 若传入的是硬比特，映射成软值
    if all(ismember(rx_bits, [0 1]))
        llr = (1 - 2 * rx_bits) * 8;
    else
        llr = rx_bits;
    end

    % 限幅
    llr = max(min(llr, 20), -20);

    % Viterbi 配置
    trellis = poly2trellis(7, [171 133]);
    tbdepth = 5 * 7;

    % puncture 模式
    if abs(code_rate - 1/2) < 1e-6
        punct_pat = [1 1];
    elseif abs(code_rate - 2/3) < 1e-6
        punct_pat = [1 1 1 0];
    else
        error('ldpc_decode: unsupported code_rate %.6f (only 1/2, 2/3 supported)', code_rate);
    end

    punct_pat = punct_pat(:).';

    % 编码器里加了 6 个尾比特
    msg_len_with_tail = trblklen + 6;
    mother_len = 2 * msg_len_with_tail;

    % 构造与编码端一致的 puncture mask
    rep_pat = repmat(punct_pat, 1, ceil(mother_len / length(punct_pat)));
    rep_pat = rep_pat(1:mother_len);

    keep_idx = find(rep_pat == 1);
    nkeep = length(keep_idx);

    % 取前 nkeep 个软值；不足则补 0
    soft_in = llr;
    if length(soft_in) < nkeep
        soft_in = [soft_in, zeros(1, nkeep - length(soft_in))];
    else
        soft_in = soft_in(1:nkeep);
    end

    % depuncture：被 puncture 的位置补 0 软值
    depunc = zeros(1, mother_len);
    depunc(keep_idx) = soft_in;

    try
        decoded = vitdec(depunc, trellis, tbdepth, 'term', 'unquant');
    catch
        try
            decoded = vitdec(depunc, trellis, tbdepth, 'trunc', 'unquant');
        catch
            info_bits = [];
            return;
        end
    end

    decoded = double(decoded(:)).';

    if length(decoded) < trblklen
        info_bits = [];
        return;
    end

    info_bits = decoded(1:trblklen);
end

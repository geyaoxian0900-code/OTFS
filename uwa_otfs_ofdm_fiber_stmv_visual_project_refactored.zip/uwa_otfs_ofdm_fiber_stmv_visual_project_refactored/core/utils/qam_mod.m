function symbols = qam_mod(bits, M)
%QAM_MOD Gray-coded square QAM modulation
%
% Inputs:
%   bits : row/column vector of bits
%   M    : modulation order, supported: 4,16,64,256
%
% Output:
%   symbols : row vector of QAM symbols with unit average power

    if nargin < 2
        error('qam_mod requires bits and M');
    end

    if ~ismember(M, [4 16 64 256])
        error('qam_mod: only M = 4, 16, 64, 256 are supported');
    end

    bits = bits(:).';
    k = log2(M);

    if mod(length(bits), k) ~= 0
        error('qam_mod: number of input bits must be a multiple of log2(M)');
    end

    m_side = sqrt(M);
    if abs(m_side - round(m_side)) > 1e-12
        error('qam_mod: M must be a square QAM order');
    end
    m_side = round(m_side);

    % Reshape bits into symbols
    bit_mat = reshape(bits, k, []).';

    % Split into I and Q halves
    k2 = k / 2;
    bits_i = bit_mat(:, 1:k2);
    bits_q = bit_mat(:, k2+1:end);

    % Binary -> Gray index per dimension
    idx_i_gray = bi2de(bits_i, 'left-msb');
    idx_q_gray = bi2de(bits_q, 'left-msb');

    % Gray index -> PAM amplitude
    amp_i = gray_index_to_pam(idx_i_gray, m_side);
    amp_q = gray_index_to_pam(idx_q_gray, m_side);

    % Standard QAM convention
    symbols = amp_i + 1j * amp_q;

    % Normalize to unit average power
    symbols = symbols / sqrt(mean(abs(symbols).^2));
    symbols = symbols(:).';
end

function amp = gray_index_to_pam(gray_idx, m_side)
    % Convert Gray-coded index to binary index
    bin_idx = gray2bin_vec(gray_idx);

    % PAM levels: e.g. m_side=4 => [-3 -1 1 3]
    levels = -(m_side-1):2:(m_side-1);
    amp = levels(bin_idx + 1).';
end

function b = gray2bin_vec(g)
    b = g;
    shift = bitshift(b, -1);
    while any(shift(:) ~= 0)
        b = bitxor(b, shift);
        shift = bitshift(shift, -1);
    end
end

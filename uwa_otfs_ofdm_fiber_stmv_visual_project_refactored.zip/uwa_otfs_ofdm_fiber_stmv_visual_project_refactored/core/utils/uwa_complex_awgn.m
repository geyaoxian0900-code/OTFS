function n = uwa_complex_awgn(sz,var)

n = sqrt(var/2)*(randn(sz)+1j*randn(sz));
end

function llr = square_qam_llr(rxSyms, M, noiseVar)
%SQUARE_QAM_LLR Max-log LLR for Gray-coded square QAM.
%
% Usage:
%   llr = square_qam_llr(rxSyms, M, noiseVar)
%
% Inputs:
%   rxSyms   - Received QAM symbols.
%   M        - Square QAM order.
%   noiseVar - Noise variance.
%
% Output convention:
%   LLR > 0  => bit=0 more likely
%   LLR < 0  => bit=1 more likely
%
% Output:
%   llr      - Row vector of bit LLRs.

    rxSyms = rxSyms(:).';
    bitsPerSymbol = log2(M);
    modulationSide = sqrt(M);
    bitsPerAxis = bitsPerSymbol / 2;

    if abs(modulationSide - round(modulationSide)) > 1e-12
        error('square_qam_llr: M must be square QAM');
    end
    modulationSide = round(modulationSide);

    if noiseVar <= 0
        noiseVar = 1e-12;
    end

    levels = -(modulationSide - 1):2:(modulationSide - 1);
    [gridI, gridQ] = meshgrid(levels, levels);
    constellation0 = gridI(:) + 1j * gridQ(:);
    normFactor = sqrt(mean(abs(constellation0).^2));
    normalizedLevels = levels / normFactor;

    binIdx = 0:modulationSide-1;
    grayIdx = bitxor(binIdx, bitshift(binIdx, -1));
    grayBits = de2bi(grayIdx, bitsPerAxis, 'left-msb');

    llrI = local_pam_llr_vectorized(real(rxSyms).', normalizedLevels, grayBits, noiseVar);
    llrQ = local_pam_llr_vectorized(imag(rxSyms).', normalizedLevels, grayBits, noiseVar);

    llrMatrix = [llrI, llrQ];
    llr = reshape(llrMatrix.', 1, []); % [Refactor] 原因：按符号顺序重排向量化结果，保持与原实现完全相同的比特输出顺序。
end

function llrMatrix = local_pam_llr_vectorized(z, normalizedLevels, grayBits, noiseVar)
%LOCAL_PAM_LLR_VECTORIZED Vectorized max-log PAM LLR per bit position.
    distanceMatrix = bsxfun(@minus, z, normalizedLevels(:).').^2; % [Refactor] 原因：一次性计算所有样本到全部 PAM 电平的距离，替代逐符号重复计算，并兼容较旧 MATLAB 版本。
    numBitsPerAxis = size(grayBits, 2);
    llrMatrix = zeros(numel(z), numBitsPerAxis);

    for bitIndex = 1:numBitsPerAxis
        zeroMask = (grayBits(:, bitIndex) == 0).';
        oneMask = ~zeroMask;

        minDistanceZero = min(distanceMatrix(:, zeroMask), [], 2);
        minDistanceOne = min(distanceMatrix(:, oneMask), [], 2);
        llrMatrix(:, bitIndex) = (minDistanceOne - minDistanceZero) / max(noiseVar, 1e-12); % [Refactor] 原因：保留原 max-log LLR 公式，仅将逐符号循环改为按列向量化。
    end
end

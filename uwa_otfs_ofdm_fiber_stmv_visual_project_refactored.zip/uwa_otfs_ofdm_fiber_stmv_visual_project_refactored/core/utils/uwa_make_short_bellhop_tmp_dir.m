function tmp_dir = uwa_make_short_bellhop_tmp_dir(tag)
%UWA_MAKE_SHORT_BELLHOP_TMP_DIR Create a short Bellhop working directory.
% Bellhop/Fortran executables on Windows can fail when the current working
% directory plus generated files (e.g. fort.6) exceeds MAX_PATH.

    if nargin < 1 || isempty(tag)
        tag = 'run';
    end

    tag = regexprep(char(tag), '[^A-Za-z0-9_\-]', '_');

    if numel(tag) > 40
        tag = tag(1:40);
    end

    root = fullfile(tempdir, 'uwa_bh');
    if ~exist(root, 'dir')
        mkdir(root);
    end

    tmp_dir = fullfile(root, tag);
end

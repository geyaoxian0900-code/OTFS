function cfg = visualization_project_config(mode)
%VISUALIZATION_PROJECT_CONFIG Extended config for full paper-style figure suite.
%
% This config is built on top of complete_chain_demo_config and adds the
% figure-generation controls needed for:
%   - communication-chain node figures
%   - beamforming / array / subarray figure suite
%   - fast beamforming algorithm comparison figures
%
% Typical usage:
%   cfg = visualization_project_config('paper');
%
% Main design choice:
%   use one representative packet/SNR/PRB point to generate all node-level
%   and array-level figures, while still allowing the main BER/PER run to use
%   the full Monte-Carlo profile.

    if nargin < 1 || isempty(mode)
        mode = 'paper';
    end

    cfg = complete_chain_demo_config(mode);

    v = struct();
    v.enable_all = true;
    v.generate_performance_curves = true;
    v.generate_chain_node_figures = true;
    v.generate_beamforming_suite = true;
    v.generate_manifest = true;

    % Representative operating point used to visualize all internal nodes.
    if any(cfg.prb_configs == 16)
        v.rep_prb = 16;
    else
        v.rep_prb = cfg.prb_configs(1);
    end

    snr_default = 6;
    if ~any(abs(cfg.snr_range - snr_default) < 1e-12)
        snr_default = cfg.snr_range(max(1, round(numel(cfg.snr_range) / 2)));
    end
    v.rep_snr_dB = snr_default;
    v.rep_packet_index = 1;
    v.rep_seed = cfg.seed_base + 909;

    % Angle-domain figure controls.
    v.scan_angles_deg = -90:0.5:90;
    v.arrival_angle_cases_deg = [-50 -30 -10 0 20 40 60];
    v.direction_gain_angles_deg = -90:1:90;
    v.beam_pointing_angle_deg = 0;
    v.beam_output_angle_deg = 0;
    v.fast_fft_length = 2048;
    v.capture_bf_dae = true;
    v.beamformer_family_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};

    % Array / subarray sweep settings.
    v.spacing_lambda_list = [0.25 0.50 0.75 1.00];
    v.spacing_labels = {'0.25\lambda', '0.50\lambda', '0.75\lambda', '1.00\lambda'};
    v.subarray_partitions = {[16], [8 8], [4 4 4 4], [2 2 2 2 2 2 2 2]};
    v.subarray_labels = {'Full array', '2 subarrays (8+8)', ...
        '4 subarrays (4+4+4+4)', '8 subarrays (2x8)'};

    % Fault / robustness figures.
    v.zeroed_element_index = 1;
    v.include_zeroed_element_case = true;
    v.include_pure_signal_scan = true;

    % Export and output structure.
    v.save_fig = true;
    v.export_dpi = 300;
    v.figure_root_name = 'figures';
    v.chain_subdir = 'communication_nodes';
    v.beam_subdir = 'beamforming_suite';
    v.summary_subdir = 'summaries';

    % Extra communications-node figures.
    v.max_time_samples_to_plot = 300;
    v.show_decoded_bit_count = 128;

    cfg.visual = v;
end

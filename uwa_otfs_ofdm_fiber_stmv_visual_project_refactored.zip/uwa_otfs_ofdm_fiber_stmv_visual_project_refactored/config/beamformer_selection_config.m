function cfg = beamformer_selection_config(mode)
%BEAMFORMER_SELECTION_CONFIG Config for CBF/STMV/improved-STMV comparison.

    cfg = complete_chain_demo_config(mode);
    cfg.experiment_name = 'beamformer_selection_for_otfs';
    cfg.rx_array.candidate_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};

    % Keep this comparison light enough to run before the full experiment.
    cfg.snr_range = unique([0 6 12]);
    cfg.prb_configs = cfg.prb_configs(1:min(numel(cfg.prb_configs), 2));
    cfg.num_packets = min(cfg.num_packets, 8);
    cfg.output_dir = fullfile(cfg.output_root, ['beamformer_selection_' lower(mode)]);
    cfg.bellhop_tmp_dir = fullfile(cfg.output_dir, 'bellhop_tmp');
    cfg.bellhop_cache_dir = fullfile(cfg.output_dir, 'bellhop_cache');
    if ~exist(cfg.output_dir, 'dir')
        mkdir(cfg.output_dir);
    end
end

function cfg = uwa_bellhop_figs_config(fig_name)
%UWA_BELLHOP_FIGS_CONFIG Bellhop/UWA config for Bellhop-backed Figure 5-9 runs.
%
% Design goal:
%   - preserve each figure's metric / resource-usage logic
%   - replace the wireless TDL-C / ETU channel with a Bellhop-driven
%     underwater acoustic channel
%
% Notes:
%   - Figure 5/6/7/8 keep their original N/M resource sizes
% Figure 9 final setting:
%   OFDM
%   OTFS short window = 2 ms
%   OTFS long window  = 12 ms

%   - Bellhop nominal arrivals are cached; Bellhop itself only needs to run
%     once per figure/environment

    base = struct();
    try
        base = system_config(fig_name);
    catch
    end

    project_root = fileparts(fileparts(mfilename('fullpath')));
    output_root = fullfile(project_root, 'output');
    if ~exist(output_root, 'dir')
        mkdir(output_root);
    end

    cfg = struct();

    % ------------------------------------------------------------
    % Shared Bellhop / UWA scene
    % ------------------------------------------------------------
    cfg.range_m       = 1000;
    cfg.tx_depth_m    = 20;
    cfg.rx_depth_m    = 50;
    cfg.water_depth_m = 100;
    cfg.sound_speed   = 1500;
    cfg.spread_factor = 1.7;
    cfg.bandwidth_hz  = 1000;

    cfg.tx_drift_mps  = 0.10;
    cfg.rx_drift_mps  = 0.02;

    cfg.fc_hz         = 4000;   % acoustic carrier
    cfg.delta_f_hz    = 15;
    cfg.fft_size      = 1024;
    cfg.cp_ofdm       = 72;
    cfg.cp_otfs       = 1;
    cfg.fs            = cfg.fft_size * cfg.delta_f_hz;
    cfg.cp_len        = cfg.cp_ofdm;

    cfg.num_paths_max = 12;
    cfg.ls_sigma_l_m  = 0.5;

    cfg.ofdm_obs_sc_radius      = 0;
    cfg.ofdm_obs_sym_radius     = 0;
    cfg.otfs_obs_delay_radius   = 6;
    cfg.otfs_obs_doppler_radius = 2;

    cfg.tf_coarse_sc_block  = 4;
    cfg.tf_coarse_sym_block = 1;
    cfg.tf_phase_levels     = 32;
    cfg.tf_mag_levels       = 32;

    cfg.bottom_soundspeed = 1600;
    cfg.bottom_density    = 1.5;
    cfg.bottom_atten      = 0.5;

    cfg.bellhop_exe = uwa_resolve_bellhop_exe('');
    cfg.bellhop_tmp_dir = fullfile(project_root, 'output', 'bellhop_tmp');
    cfg.bellhop_cache_dir = fullfile(project_root, 'output', 'bellhop_cache');

    cfg.seed_base = 20260418;
    cfg.rx_array = uwa_rx_array_default_cfg(cfg);


    if isfield(base, 'velocity')
        velocity_ref = base.velocity;
    else
        velocity_ref = 120;
    end

    % Acoustic Doppler factor reference from drift speed over sound speed,
    % then scale it by the relative figure velocity to preserve the
    % Fig.5/6/8 (higher mobility) vs Fig.7 (lower mobility) relationship.
    doppler_base = (cfg.tx_drift_mps + cfg.rx_drift_mps) / cfg.sound_speed;
    cfg.doppler_factor = doppler_base * (velocity_ref / 120);

    % ------------------------------------------------------------
    % Figure-specific overlay
    % ------------------------------------------------------------
    switch fig_name
        case 'fig5'
            cfg.figure_name = 'Figure 5 (Bellhop)';
            cfg.Ndd = base.N;
            cfg.Mdd = base.M;
            cfg.num_active_sc = cfg.Ndd;
            cfg.num_symbols = cfg.Mdd;
          
            
%cfg.snr_range = 0;
%cfg.max_trials = 1;
%cfg.min_trials = 1;
%cfg.min_errors = 1;
%cfg.fig5_batch_size = 1;
%cfg.fig5_use_parallel = false;

% cfg.fig5_use_parallel = false;
% cfg.snr_range = 0:2:20;
% cfg.max_trials = 20;
% cfg.min_trials = 8;
% cfg.min_errors = 30;
% cfg.fig5_batch_size = 4;


            
           cfg.snr_range = base.snr_range;
            cfg.modulation_orders = base.modulation_orders;
            cfg.equalizers = base.equalizers;
           cfg.max_trials = 300;
           cfg.min_errors = 300;
           cfg.min_trials = 50;
           cfg.fig5_batch_size = 8;
            cfg.fig5_use_parallel = true;
            cfg.output_data_file = fullfile(project_root, 'output', 'fig5_bellhop_data.mat');
            cfg.output_png_file  = fullfile(project_root, 'output', 'fig5_bellhop_uncoded_ber.png');

        case 'fig6'
            cfg.figure_name = 'Figure 6 (Bellhop)';
            cfg.Ndd = base.N;
            cfg.Mdd = base.M;
            cfg.num_active_sc = cfg.Ndd;
            cfg.num_symbols = cfg.Mdd;
            cfg.max_trials = 80;
            cfg.legend_names = { ...
                'OTFS-Iterative', ...
                'OTFS-Genie', ...
                'OTFS-DFE', ...
                'OTFS-MMSE', ...
                'OFDM-MMSE'};
            cfg.output_data_file = fullfile(project_root, 'output', 'fig6_bellhop_data.mat');
            cfg.output_png_file  = fullfile(project_root, 'output', 'fig6_bellhop_per.png');


cfg.max_trials = 120;
cfg.fig6_min_trials = 16;
cfg.fig6_min_pkt_errors = 25;
cfg.fig6_iter_num = 4;
cfg.fig6_batch_size = 4;



cfg.snr_range = 0:1:12;
cfg.max_trials = 40;
cfg.fig6_min_trials = 8;
cfg.fig6_min_pkt_errors = 10;




        case 'fig7'
            cfg.figure_name = 'Figure 7 (Bellhop)';
            cfg.Ndd = base.N;
            cfg.Mdd = base.M;
            cfg.num_active_sc = cfg.Ndd;
            cfg.num_symbols = cfg.Mdd;
            cfg.num_prb = base.num_prb;
            cfg.modulation_orders = base.modulation_orders;
            cfg.code_rate = base.code_rate;
            cfg.snr_range = base.snr_range;
            cfg.max_trials = 80;
            cfg.min_trials = 60;
            cfg.max_block_errors = 60;
            cfg.output_data_file = fullfile(project_root, 'output', 'fig7_bellhop_data.mat');
            cfg.output_png_file  = fullfile(project_root, 'output', 'fig7_bellhop_bler.png');

        case 'fig8'
            cfg.figure_name = 'Figure 8 (Bellhop)';
            cfg.Ndd = base.N;
            cfg.Mdd = base.M;
            cfg.num_active_sc = cfg.Ndd;
            cfg.num_symbols = cfg.Mdd;
            cfg.prb_configs = base.prb_configs;
            cfg.modulation = base.modulation;
            cfg.code_rate = base.code_rate;
            cfg.snr_range = base.snr_range;
            cfg.num_packets = 80;
            cfg.output_data_file = fullfile(project_root, 'output', 'fig8_bellhop_data.mat');
            cfg.output_png_file  = fullfile(project_root, 'output', 'fig8_bellhop_per.png');

        case 'fig9'
            cfg.figure_name = 'Figure 9 (Bellhop)';
            cfg.num_active_sc = 300;
            cfg.num_symbols = 14;
            cfg.Ndd = cfg.num_active_sc;
            cfg.Mdd = cfg.num_symbols;
            cfg.time_duration = 0.7;
            cfg.time_sampling_rate = 1000;    % 1 ms resolution
            cfg.avg_snr_db = base.avg_snr_db;
            cfg.otfs_windows = [1e-3, 10e-3];
            cfg.fig9_doppler_factor = max(cfg.doppler_factor, 5e-5);
            cfg.output_data_file = fullfile(project_root, 'output', 'fig9_bellhop_data.mat');
            cfg.output_png_file  = fullfile(project_root, 'output', 'fig9_bellhop_snr_cdf.png');

        otherwise
            error('uwa_bellhop_figs_config: unsupported fig_name = %s', fig_name);
    end
end

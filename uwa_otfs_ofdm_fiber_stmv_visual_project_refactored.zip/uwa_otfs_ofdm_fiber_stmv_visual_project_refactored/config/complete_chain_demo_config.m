function cfg = complete_chain_demo_config(mode)
%COMPLETE_CHAIN_DEMO_CONFIG Reproducible config for OTFS vs OFDM UWA chain.
%
% Modes:
%   quick : first-time users; short SNR list and few packets
%   paper              : paper-ready mode; denser SNR grid and more packets
%   paper_final        : final paper mode; highest packet count for stable tails
%   paper_single_prb16 : paper-ready mode for PRB=16 only
%   paper_single_prb4  : paper-ready mode for PRB=4 only
%   full               : backward-compatible alias of paper
%
% The active receive array is modelled as an all-optical fibre hydrophone
% line array.  Only the array-level content is used from the fibre-array
% thesis: high-sensitivity hydrophones, large-scale array suitability, and
% low-interference optical transmission are represented as metadata and
% default array choices.  The optical interferometer physics is intentionally
% not mixed into the communication waveform model.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end

    cfg = uwa_bellhop_figs_config('fig8');

    % ------------------------------------------------------------------
    % Output / reproducibility root
    % ------------------------------------------------------------------
    project_root = fileparts(fileparts(mfilename('fullpath')));
    cfg.project_root = project_root;
    cfg.output_root = fullfile(project_root, 'output');
    cfg.output_dir = fullfile(cfg.output_root, ['complete_chain_' lower(mode)]);
    if ~exist(cfg.output_dir, 'dir')
        mkdir(cfg.output_dir);
    end

    cfg.bellhop_tmp_dir = fullfile(cfg.output_dir, 'bellhop_tmp');
    cfg.bellhop_cache_dir = fullfile(cfg.output_dir, 'bellhop_cache');
    cfg.allow_synthetic_nominal_paths = true;   % reproducible fallback when Bellhop is absent

    % ------------------------------------------------------------------
    % Experiment identity / random seeds
    % ------------------------------------------------------------------
    cfg.experiment_name = 'otfs_ofdm_uwa_fiber_array_improved_stmv';
    cfg.seed_base = 20260420;
    cfg.reproducible_rng = true;
    cfg.save_code_manifest = true;
    cfg.save_config_json = true;

    % ------------------------------------------------------------------
    % All-optical fibre array metadata from the fibre-array thesis.
    % This does not replace the acoustic propagation model; it defines the
    % receiving array platform used by the beamformer.
    % ------------------------------------------------------------------
    cfg.sensor_platform = struct();
    cfg.sensor_platform.type = 'all_optical_fibre_hydrophone_array';
    cfg.sensor_platform.keep_scope = 'array_platform_only';
    cfg.sensor_platform.notes = ['The optical-fibre thesis is used only for ', ...
        'the receiver array platform: high sensitivity, anti-electromagnetic ', ...
        'interference, easier large-scale arraying, and simplified wet-end ', ...
        'engineering. The communication waveform remains OTFS/OFDM.'];

    % ------------------------------------------------------------------
    % Paper-selected beamformer.
    % CBF is robust and simple, STMV is high-resolution and suppresses
    % interference/multipath, and improved STMV cascades CBF subarrays with
    % STMV to improve robustness and reduce complexity.  For OTFS in a
    % multipath UWA channel, improved STMV is the default.
    % ------------------------------------------------------------------
    cfg.rx_array = uwa_rx_array_default_cfg(cfg);
    cfg.rx_array.enabled = true;
    cfg.rx_array.platform = cfg.sensor_platform.type;
    cfg.rx_array.num_elements = 16;
    cfg.rx_array.spacing_m = cfg.sound_speed / (2 * cfg.fc_hz);
    cfg.rx_array.orientation = 'vertical';
    cfg.rx_array.combine_method = 'improved_stmv';
    cfg.rx_array.candidate_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};
    cfg.rx_array.selected_reason = ['Selected for OTFS because it preserves ', ...
        'the robust CBF pre-beamformed subarray outputs while using STMV ', ...
        'to suppress angular multipath/interference with lower dimension ', ...
        'than full-array STMV.'];
    cfg.rx_array.steering_mode = 'strongest';
    cfg.rx_array.steering_angle_deg = 0;
    cfg.rx_array.window = 'uniform';
    cfg.rx_array.diagonal_loading = 1e-2;
    cfg.rx_array.interference_power_floor = 1e-4;
    cfg.rx_array.exclude_steered_path_from_interference = true;
    cfg.rx_array.preserve_array_gain = true;
    cfg.rx_array.subarray_partition = [4 4 4 4];
    cfg.rx_array.subarray_overlap = 0;
    cfg.rx_array.subarray_mode = 'contiguous';
    cfg.rx_array.normalize_weights = true;

    % ------------------------------------------------------------------
    % OTFS detector options.
    % Default: existing TF-domain MMSE detector.
    % Added: BF-DAE detector inspired by the OCEANS 2025 paper, combining
    % TF-domain R-to-Q beamforming preprocessing with DD-domain multichannel
    % adaptive detection.
    % ------------------------------------------------------------------
    cfg.otfs_detection = struct();
    cfg.otfs_detection.method = 'tf_mmse';
    cfg.otfs_detection.candidate_methods = {'tf_mmse', 'bf_dae'};
    cfg.otfs_detection.description = ['TF-domain MMSE is the default baseline. ', ...
        'BF-DAE adds TF-domain beamforming preprocessing plus a DD-domain ', ...
        'multichannel adaptive detector.'];
    cfg.otfs_detection.bf_dae = struct();
    cfg.otfs_detection.bf_dae.use_true_doa = true;
    cfg.otfs_detection.bf_dae.max_beams = 4;
    cfg.otfs_detection.bf_dae.angle_merge_tol_deg = 5;
    cfg.otfs_detection.bf_dae.scan_angles_deg = -90:1:90;
    cfg.otfs_detection.bf_dae.doa_estimator = 'capon_scan';
    cfg.otfs_detection.bf_dae.training_fraction = 0.25;
    cfg.otfs_detection.bf_dae.num_passes = 1;
    cfg.otfs_detection.bf_dae.Kf = 1;
    cfg.otfs_detection.bf_dae.Lf = 1;
    cfg.otfs_detection.bf_dae.Kb = 1;
    cfg.otfs_detection.bf_dae.Lb = 1;
    cfg.otfs_detection.bf_dae.mu_f = 0.25;
    cfg.otfs_detection.bf_dae.mu_b = 0.10;
    cfg.otfs_detection.bf_dae.delta_f = 1e-3;
    cfg.otfs_detection.bf_dae.delta_b = 1e-3;
    cfg.otfs_detection.bf_dae.ipnlms_alpha = 0;
    cfg.otfs_detection.bf_dae.use_feedback = true;
    cfg.otfs_detection.bf_dae.decision_directed_after_training = true;

    switch lower(mode)
        case 'quick'
            cfg.mode_label = 'quick';
            cfg.mode_purpose = 'Fast sanity-check run for first-time users.';
            cfg.snr_range = 0:3:12;
            cfg.prb_configs = [16 4];
            cfg.num_packets = 10;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];

        case 'paper'
            cfg.mode_label = 'paper';
            cfg.mode_purpose = ['Paper-ready run with denser SNR sampling, ', ...
                'higher packet count, and formal BER/PER figures.'];
            cfg.snr_range = 0:1:12;
            cfg.prb_configs = [16 4];
            cfg.num_packets = 200;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];

        case 'paper_final'
            cfg.mode_label = 'paper_final';
            cfg.mode_purpose = ['Final paper run with the same dense SNR grid as paper mode, ', ...
                'but a larger packet count for smoother high-SNR tails and more stable BER/PER estimates.'];
            cfg.snr_range = 0:1:12;
            cfg.prb_configs = [16 4];
            cfg.num_packets = 1000;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];

        case 'paper_single_prb16'
            cfg.mode_label = 'paper_single_prb16';
            cfg.mode_purpose = ['Paper-ready run for PRB=16 only. Useful for cleaner ', ...
                'single-configuration figures in manuscripts.'];
            cfg.snr_range = 0:1:12;
            cfg.prb_configs = 16;
            cfg.num_packets = 200;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];

        case 'paper_single_prb4'
            cfg.mode_label = 'paper_single_prb4';
            cfg.mode_purpose = ['Paper-ready run for PRB=4 only. Useful for cleaner ', ...
                'single-configuration figures in manuscripts.'];
            cfg.snr_range = 0:1:12;
            cfg.prb_configs = 4;
            cfg.num_packets = 200;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];

        case 'full'
            % Backward-compatible alias. Keep old entry point working, but
            % internally align it with the paper-ready experiment profile.
            cfg.mode_label = 'paper';
            cfg.mode_purpose = ['Backward-compatible alias of paper mode; ', ...
                'uses dense SNR sampling and more packets.'];
            cfg.snr_range = 0:1:12;
            cfg.prb_configs = [16 4];
            cfg.num_packets = 200;
            cfg.rx_array.num_elements = 16;
            cfg.rx_array.subarray_partition = [4 4 4 4];


        otherwise
            error('Unsupported mode: %s', mode);
    end
end

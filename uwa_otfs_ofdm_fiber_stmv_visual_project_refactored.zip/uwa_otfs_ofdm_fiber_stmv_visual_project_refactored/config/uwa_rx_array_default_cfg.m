function rx_array = uwa_rx_array_default_cfg(cfg)
%UWA_RX_ARRAY_DEFAULT_CFG Default all-optical fibre receive-array settings.
%
% The array model is acoustic at the signal-processing level.  The phrase
% "all-optical fibre" describes the hydrophone-array platform: optical fibre
% sensing/transmission gives high sensitivity, anti-electromagnetic
% interference, and practical large-scale arraying.  The default beamformer
% follows the beamforming thesis and uses improved STMV (CBF subarrays +
% STMV/MVDR across subarray outputs).

    if nargin < 1 || isempty(cfg)
        cfg = struct();
    end

    c = 1500;
    if isfield(cfg, 'sound_speed') && isnumeric(cfg.sound_speed) && isscalar(cfg.sound_speed)
        c = cfg.sound_speed;
    end

    fc = 4000;
    if isfield(cfg, 'fc_hz') && isnumeric(cfg.fc_hz) && isscalar(cfg.fc_hz)
        fc = cfg.fc_hz;
    elseif isfield(cfg, 'center_freq_hz') && isnumeric(cfg.center_freq_hz) && isscalar(cfg.center_freq_hz)
        fc = cfg.center_freq_hz;
    end

    rx_array = struct();
    rx_array.enabled = true;
    rx_array.platform = 'all_optical_fibre_hydrophone_array';
    rx_array.num_elements = 16;
    rx_array.spacing_m = c / max(2 * fc, eps);   % lambda/2 at centre frequency
    rx_array.orientation = 'vertical';
    rx_array.combine_method = 'improved_stmv';   % selected paper method
    rx_array.candidate_methods = {'cbf', 'mvdr', 'wicmv', 'stmv', 'improved_stmv'};
    rx_array.steering_mode = 'strongest';
    rx_array.steering_angle_deg = 0;
    rx_array.preserve_array_gain = true;
    rx_array.window = 'uniform';
    rx_array.diagonal_loading = 1e-2;
    rx_array.interference_power_floor = 1e-4;
    rx_array.exclude_steered_path_from_interference = true;
    rx_array.subarray_partition = [4 4 4 4];
    rx_array.subarray_overlap = 0;
    rx_array.subarray_mode = 'contiguous';
    rx_array.normalize_weights = true;
end

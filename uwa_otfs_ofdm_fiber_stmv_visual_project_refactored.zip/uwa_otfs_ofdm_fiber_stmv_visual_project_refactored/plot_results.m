function varargout = plot_results(varargin)
%PLOT_RESULTS Paper-style BER/PER plotting for OTFS vs OFDM experiments.
%
% This file is intentionally placed at the project root so it can directly
% replace a legacy plot_results.m and be called from scripts or plotting
% modules.
%
% Supported usages:
%   plot_results(results)
%   plot_results(results, out_dir)
%   plot_results(results, out_dir, beamformer_name)
%
%   plot_results(snr_dB_list, prb_list, ber_otfs, ber_ofdm, per_otfs, per_ofdm)
%   plot_results(snr_dB_list, prb_list, ber_otfs, ber_ofdm, per_otfs, per_ofdm, out_dir)
%   plot_results(snr_dB_list, prb_list, ber_otfs, ber_ofdm, per_otfs, per_ofdm, out_dir, beamformer_name)
%
% Outputs:
%   out = plot_results(...)
%       out.ber_png, out.ber_fig, out.per_png, out.per_fig
%
% Design choices:
%   - BER and PER are plotted with logarithmic y-axis, which is the usual
%     style for communication performance curves.
%   - Zero values are clipped to a small floor only for plotting. The saved
%     numerical results are not changed.
%   - PNG and FIG are both saved. PNG is for papers/reports; FIG is for later
%     MATLAB editing.

    [results, out_dir, beamformer_name, mode_name] = parse_inputs(varargin{:});
    cfg = default_plot_config();

    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end

    snr_dB_list = results.snr_dB_list(:).';
    prb_list = results.prb_list(:).';

    file_token = build_file_token(beamformer_name, mode_name);

    % ------------------------------------------------------------------
    % BER figure
    % ------------------------------------------------------------------
    fig_ber = figure('Color', 'w', ...
        'Name', 'BER Paper Style', ...
        'NumberTitle', 'off', ...
        'Position', [100 100 900 650]);

    ax1 = axes(fig_ber); %#ok<LAXES>
    hold(ax1, 'on');
    box(ax1, 'on');
    grid(ax1, 'on');
    set_paper_axes_style(ax1, cfg);

    plot_metric_semilogy(ax1, snr_dB_list, results.ber_otfs, results.ber_ofdm, ...
        prb_list, cfg.ber_floor, cfg);

    xlabel(ax1, 'SNR (dB)', 'FontName', cfg.font_name, ...
        'FontSize', cfg.label_font_size, 'Interpreter', 'none');
    ylabel(ax1, 'BER', 'FontName', cfg.font_name, ...
        'FontSize', cfg.label_font_size, 'Interpreter', 'none');
    title(ax1, compose_metric_title('BER', beamformer_name), ...
        'FontName', cfg.font_name, 'FontSize', cfg.title_font_size, ...
        'FontWeight', 'normal', 'Interpreter', 'none');

    xlim(ax1, [min(snr_dB_list), max(snr_dB_list)]);
    ylim(ax1, [cfg.ber_floor, 1]);

    lgd1 = legend(ax1, build_legend_entries(prb_list), ...
        'Location', 'southwest', 'FontName', cfg.font_name, ...
        'FontSize', cfg.legend_font_size, 'Box', 'on');
    try, lgd1.Interpreter = 'none'; catch, end %#ok<CTCH>

    ber_png = fullfile(out_dir, sprintf('ber_%s_paper.png', file_token));
    ber_fig = fullfile(out_dir, sprintf('ber_%s_paper.fig', file_token));
    save_figure_outputs(fig_ber, ber_png, ber_fig, cfg.export_dpi);

    % ------------------------------------------------------------------
    % PER figure
    % ------------------------------------------------------------------
    fig_per = figure('Color', 'w', ...
        'Name', 'PER Paper Style', ...
        'NumberTitle', 'off', ...
        'Position', [120 120 900 650]);

    ax2 = axes(fig_per); %#ok<LAXES>
    hold(ax2, 'on');
    box(ax2, 'on');
    grid(ax2, 'on');
    set_paper_axes_style(ax2, cfg);

    plot_metric_semilogy(ax2, snr_dB_list, results.per_otfs, results.per_ofdm, ...
        prb_list, cfg.per_floor, cfg);

    xlabel(ax2, 'SNR (dB)', 'FontName', cfg.font_name, ...
        'FontSize', cfg.label_font_size, 'Interpreter', 'none');
    ylabel(ax2, 'PER', 'FontName', cfg.font_name, ...
        'FontSize', cfg.label_font_size, 'Interpreter', 'none');
    title(ax2, compose_metric_title('PER', beamformer_name), ...
        'FontName', cfg.font_name, 'FontSize', cfg.title_font_size, ...
        'FontWeight', 'normal', 'Interpreter', 'none');

    xlim(ax2, [min(snr_dB_list), max(snr_dB_list)]);
    ylim(ax2, [cfg.per_floor, 1]);

    lgd2 = legend(ax2, build_legend_entries(prb_list), ...
        'Location', 'southwest', 'FontName', cfg.font_name, ...
        'FontSize', cfg.legend_font_size, 'Box', 'on');
    try, lgd2.Interpreter = 'none'; catch, end %#ok<CTCH>

    per_png = fullfile(out_dir, sprintf('per_%s_paper.png', file_token));
    per_fig = fullfile(out_dir, sprintf('per_%s_paper.fig', file_token));
    save_figure_outputs(fig_per, per_png, per_fig, cfg.export_dpi);

    out = struct();
    out.ber_png = ber_png;
    out.ber_fig = ber_fig;
    out.per_png = per_png;
    out.per_fig = per_fig;

    fprintf('[plot_results] Saved paper-style figures:\n');
    fprintf('  %s\n', ber_png);
    fprintf('  %s\n', ber_fig);
    fprintf('  %s\n', per_png);
    fprintf('  %s\n', per_fig);

    if nargout >= 1
        varargout{1} = out;
    end
end

% ========================================================================
% Input parsing
% ========================================================================

function [results, out_dir, beamformer_name, mode_name] = parse_inputs(varargin)
    out_dir = pwd;
    beamformer_name = 'beamformer';
    mode_name = '';

    if nargin < 1
        error('plot_results requires at least one input.');
    end

    if isstruct(varargin{1})
        results = normalize_results_struct(varargin{1});

        if nargin >= 2 && ~isempty(varargin{2})
            out_dir = char(varargin{2});
        else
            out_dir = infer_out_dir_from_results(varargin{1}, out_dir);
        end

        if nargin >= 3 && ~isempty(varargin{3})
            beamformer_name = char(varargin{3});
        else
            beamformer_name = infer_beamformer_name(varargin{1}, beamformer_name);
        end

        if isfield(varargin{1}, 'mode') && ~isempty(varargin{1}.mode)
            mode_name = char(varargin{1}.mode);
        end
        return;
    end

    if nargin < 6
        error(['Numeric calling mode requires at least 6 inputs: ', ...
            'snr_dB_list, prb_list, ber_otfs, ber_ofdm, per_otfs, per_ofdm.']);
    end

    results = struct();
    results.snr_dB_list = varargin{1};
    results.prb_list = varargin{2};
    results.ber_otfs = varargin{3};
    results.ber_ofdm = varargin{4};
    results.per_otfs = varargin{5};
    results.per_ofdm = varargin{6};
    results = normalize_results_struct(results);

    if nargin >= 7 && ~isempty(varargin{7})
        out_dir = char(varargin{7});
    end
    if nargin >= 8 && ~isempty(varargin{8})
        beamformer_name = char(varargin{8});
    end
end

function results = normalize_results_struct(results)
    required_fields = {'snr_dB_list', 'prb_list', 'ber_otfs', 'ber_ofdm', 'per_otfs', 'per_ofdm'};
    for k = 1:numel(required_fields)
        f = required_fields{k};
        if ~isfield(results, f)
            error('plot_results: missing field results.%s', f);
        end
    end

    snr = results.snr_dB_list;
    prb = results.prb_list;
    if ~isnumeric(snr) || isempty(snr)
        error('results.snr_dB_list must be a non-empty numeric vector.');
    end
    if ~isnumeric(prb) || isempty(prb)
        error('results.prb_list must be a non-empty numeric vector.');
    end

    nprb = numel(prb);
    nsnr = numel(snr);
    check_metric_size(results.ber_otfs, 'ber_otfs', nprb, nsnr);
    check_metric_size(results.ber_ofdm, 'ber_ofdm', nprb, nsnr);
    check_metric_size(results.per_otfs, 'per_otfs', nprb, nsnr);
    check_metric_size(results.per_ofdm, 'per_ofdm', nprb, nsnr);
end

function check_metric_size(x, name, nprb, nsnr)
    if ~isnumeric(x) || ~ismatrix(x)
        error('results.%s must be a numeric 2D matrix.', name);
    end
    s = size(x);
    if ~isequal(s, [nprb, nsnr])
        error('results.%s must have size [%d x %d], but got [%d x %d].', ...
            name, nprb, nsnr, s(1), s(2));
    end
end

function out_dir = infer_out_dir_from_results(results, fallback_dir)
    out_dir = fallback_dir;
    if isfield(results, 'cfg') && isstruct(results.cfg)
        cfg = results.cfg;
        if isfield(cfg, 'output_dir') && ~isempty(cfg.output_dir)
            out_dir = char(cfg.output_dir);
            return;
        end
        if isfield(cfg, 'output_run_folder') && ~isempty(cfg.output_run_folder)
            out_dir = char(cfg.output_run_folder);
            return;
        end
        if isfield(cfg, 'output_root') && ~isempty(cfg.output_root)
            out_dir = char(cfg.output_root);
            return;
        end
    end
end

function beamformer_name = infer_beamformer_name(results, fallback_name)
    beamformer_name = fallback_name;
    if isfield(results, 'cfg') && isstruct(results.cfg)
        cfg = results.cfg;
        if isfield(cfg, 'rx_array') && isstruct(cfg.rx_array)
            if isfield(cfg.rx_array, 'combine_method') && ~isempty(cfg.rx_array.combine_method)
                beamformer_name = char(cfg.rx_array.combine_method);
                return;
            end
            if isfield(cfg.rx_array, 'beamformer') && isstruct(cfg.rx_array.beamformer)
                if isfield(cfg.rx_array.beamformer, 'method') && ~isempty(cfg.rx_array.beamformer.method)
                    beamformer_name = char(cfg.rx_array.beamformer.method);
                    return;
                end
            end
        end
        if isfield(cfg, 'beamformer_method') && ~isempty(cfg.beamformer_method)
            beamformer_name = char(cfg.beamformer_method);
            return;
        end
    end
end

% ========================================================================
% Plotting helpers
% ========================================================================

function cfg = default_plot_config()
    cfg.font_name = 'Times New Roman';
    cfg.title_font_size = 15;
    cfg.label_font_size = 14;
    cfg.axis_font_size = 12;
    cfg.legend_font_size = 11;
    cfg.line_width = 1.8;
    cfg.marker_size = 7;
    cfg.axis_line_width = 1.0;
    cfg.export_dpi = 300;

    % Floors are only for log-scale drawing. They are not written back to results.
    cfg.ber_floor = 1e-5;
    cfg.per_floor = 1e-3;

    cfg.otfs_styles = {'-o', '-^', '-v', '-d', '-p', '-h'};
    cfg.ofdm_styles = {'--s', '--d', '-->', '--<', '--x', '--+'};
end

function set_paper_axes_style(ax, cfg)
    set(ax, ...
        'FontName', cfg.font_name, ...
        'FontSize', cfg.axis_font_size, ...
        'LineWidth', cfg.axis_line_width, ...
        'YScale', 'log', ...
        'Layer', 'top');
end

function plot_metric_semilogy(ax, snr_dB_list, metric_otfs, metric_ofdm, prb_list, y_floor, cfg)
    nprb = numel(prb_list);
    metric_otfs_plot = safe_log_data(metric_otfs, y_floor);
    metric_ofdm_plot = safe_log_data(metric_ofdm, y_floor);

    for i = 1:nprb
        otfs_style = pick_style(cfg.otfs_styles, i);
        ofdm_style = pick_style(cfg.ofdm_styles, i);

        semilogy(ax, snr_dB_list, metric_otfs_plot(i,:), otfs_style, ...
            'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
        semilogy(ax, snr_dB_list, metric_ofdm_plot(i,:), ofdm_style, ...
            'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
    end
end

function y = safe_log_data(x, floor_val)
    y = x;
    y(~isfinite(y)) = floor_val;
    y(y <= 0) = floor_val;
end

function s = pick_style(style_list, idx)
    n = numel(style_list);
    s = style_list{mod(idx - 1, n) + 1};
end

function entries = build_legend_entries(prb_list)
    nprb = numel(prb_list);
    entries = cell(1, 2 * nprb);
    idx = 1;
    for i = 1:nprb
        entries{idx} = sprintf('OTFS, PRB=%d', prb_list(i));
        idx = idx + 1;
        entries{idx} = sprintf('OFDM, PRB=%d', prb_list(i));
        idx = idx + 1;
    end
end

function ttl = compose_metric_title(metric_name, beamformer_name)
    bf = prettify_beamformer_name(beamformer_name);
    ttl = sprintf('%s Performance Comparison of OTFS and OFDM with %s Beamforming', metric_name, bf);
end

function out = prettify_beamformer_name(name_in)
    out = char(name_in);
    out = strrep(out, '_', '-');
    if strcmpi(out, 'improved-stmv')
        out = 'Improved-STMV';
    elseif strcmpi(out, 'stmv')
        out = 'STMV';
    elseif strcmpi(out, 'mvdr')
        out = 'MVDR';
    elseif strcmpi(out, 'cbf')
        out = 'CBF';
    elseif strcmpi(out, 'beamformer')
        out = 'Beamforming';
    end
end


function token = build_file_token(beamformer_name, mode_name)
    token = safe_filename_token(beamformer_name);
    mode_token = safe_filename_token(mode_name);

    if isempty(mode_token)
        return;
    end

    % Keep file names compact and avoid duplicated "..._paper_paper".
    % Examples:
    %   beamformer=improved_stmv, mode=quick            -> improved_stmv_quick
    %   beamformer=improved_stmv, mode=paper            -> improved_stmv
    %   beamformer=improved_stmv, mode=paper_final      -> improved_stmv_paper_final
    %   beamformer=improved_stmv, mode=paper_single...  -> improved_stmv_paper_single...
    if strcmpi(mode_token, 'paper')
        return;
    end

    if endsWith(token, ['_' mode_token]) || strcmpi(token, mode_token)
        return;
    end

    token = [token '_' mode_token];
end

function token = safe_filename_token(name_in)
    token = char(name_in);
    token = lower(token);
    token = regexprep(token, '\s+', '_');
    token = regexprep(token, '[^a-zA-Z0-9_\-]', '');
    if isempty(token)
        token = 'beamformer';
    end
end

function save_figure_outputs(fig, png_path, fig_path, dpi)
    try
        exportgraphics(fig, png_path, 'Resolution', dpi);
    catch
        try
            print(fig, png_path, '-dpng', ['-r' num2str(dpi)]);
        catch
            saveas(fig, png_path);
        end
    end

    try
        savefig(fig, fig_path);
    catch
        % Older MATLAB/Octave may not support savefig. PNG has already been saved.
    end
end

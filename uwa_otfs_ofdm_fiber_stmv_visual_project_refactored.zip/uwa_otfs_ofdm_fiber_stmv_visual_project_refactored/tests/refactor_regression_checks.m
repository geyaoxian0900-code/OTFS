%% REFACTOR_REGRESSION_CHECKS
% Regression checks for refactored vectorized kernels.
%
% Usage:
%   run('tests/refactor_regression_checks.m')
%
% Goal:
%   Verify the refactored functions preserve numerical outputs relative to
%   explicit-loop reference implementations with max absolute error < 1e-10.

clear;
clc;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
setup_project_paths(projectRoot, false);

rng(42);
fprintf('Running refactor regression checks...\n');

check_apply_weights_to_array_tf();
check_apply_line_array_beamforming();
check_qam_demod_hard_decision();
check_square_qam_llr();

fprintf('All refactor regression checks passed.\n');

function check_apply_weights_to_array_tf()
    arrayTf = randn(8, 10, 4) + 1j * randn(8, 10, 4);
    weightMatrix = randn(8, 4) + 1j * randn(8, 4);

    yRef = reference_apply_weights_to_array_tf(arrayTf, weightMatrix);
    yNew = uwa_apply_weights_to_array_tf(arrayTf, weightMatrix);

    maxError = max(abs(yRef(:) - yNew(:)));
    assert(maxError < 1e-10, 'uwa_apply_weights_to_array_tf max error = %.3e', maxError);
    fprintf('  [OK] uwa_apply_weights_to_array_tf max error = %.3e\n', maxError);
end

function check_apply_line_array_beamforming()
    cfg = system_config();
    freqHz = linspace(cfg.fc_hz - cfg.bandwidth_hz / 2, cfg.fc_hz + cfg.bandwidth_hz / 2, 8).';
    HpFt = randn(8, 6, 3) + 1j * randn(8, 6, 3);
    pathAnglesDeg = [-20 0 25];
    pathMetric = [1.0 0.8 0.5];

    [hRef, bfRef] = reference_apply_line_array_beamforming(cfg, freqHz, HpFt, pathAnglesDeg, pathMetric);
    [hNew, bfNew] = uwa_apply_line_array_beamforming(cfg, freqHz, HpFt, pathAnglesDeg, pathMetric);

    maxError = max(abs(hRef(:) - hNew(:)));
    assert(maxError < 1e-10, 'uwa_apply_line_array_beamforming max error = %.3e', maxError);
    assert(isequaln(bfRef, bfNew), 'Beamformer auxiliary outputs changed unexpectedly.');
    fprintf('  [OK] uwa_apply_line_array_beamforming max error = %.3e\n', maxError);
end

function check_qam_demod_hard_decision()
    M = 16;
    bitsIn = randi([0 1], 1, 400);
    symbols = qam_mod(bitsIn, M);
    bitsRef = reference_qam_demod(symbols, M, 'hard');
    bitsNew = qam_demod(symbols, M, 'hard');

    maxError = max(abs(bitsRef(:) - bitsNew(:)));
    assert(maxError < 1e-10, 'qam_demod max error = %.3e', maxError);
    fprintf('  [OK] qam_demod max error = %.3e\n', maxError);
end

function check_square_qam_llr()
    M = 16;
    rxSyms = randn(1, 128) + 1j * randn(1, 128);
    noiseVar = 0.25;

    llrRef = reference_square_qam_llr(rxSyms, M, noiseVar);
    llrNew = square_qam_llr(rxSyms, M, noiseVar);

    maxError = max(abs(llrRef(:) - llrNew(:)));
    assert(maxError < 1e-10, 'square_qam_llr max error = %.3e', maxError);
    fprintf('  [OK] square_qam_llr max error = %.3e\n', maxError);
end

function Ytf = reference_apply_weights_to_array_tf(arrayTf, weightMatrix)
    [numActiveSc, numSymbols, numElements] = size(arrayTf);
    if size(weightMatrix, 1) == 1 && numActiveSc > 1
        weightMatrix = repmat(weightMatrix, numActiveSc, 1);
    end

    Ytf = zeros(numActiveSc, numSymbols);
    for subcarrierIndex = 1:numActiveSc
        xk = squeeze(arrayTf(subcarrierIndex, :, :));
        Ytf(subcarrierIndex, :) = xk * conj(weightMatrix(subcarrierIndex, :).');
    end
end

function [HtfEff, beamformingInfo] = reference_apply_line_array_beamforming(cfg, freqHz, HpFt, pathAnglesDeg, pathMetric)
    if nargin < 5
        pathMetric = [];
    end

    [numActiveSc, numSymbols, numPaths] = size(HpFt);
    if numPaths == 0
        HtfEff = zeros(numActiveSc, numSymbols);
        beamformingInfo = struct();
        beamformingInfo.enabled = false;
        return;
    end

    [pathResponse, beamformingInfo] = uwa_line_array_path_response(cfg, freqHz, pathAnglesDeg, pathMetric);
    HtfEff = zeros(numActiveSc, numSymbols);
    for pathIndex = 1:numPaths
        HtfEff = HtfEff + HpFt(:, :, pathIndex) .* repmat(pathResponse(:, pathIndex), 1, numSymbols);
    end
end

function bits = reference_qam_demod(symbols, M, varargin)
    if nargin == 3
        mode = varargin{1};
    else
        mode = varargin{2};
    end
    if ~strcmpi(char(mode), 'hard')
        error('Only hard mode is supported in the reference checker.');
    end

    symbols = symbols(:);
    bitsPerSymbol = log2(M);
    modulationSide = round(sqrt(M));
    bitsPerAxis = bitsPerSymbol / 2;

    levels = -(modulationSide-1):2:(modulationSide-1);
    [gridI, gridQ] = meshgrid(levels, levels);
    constellationFull = gridI(:) + 1j * gridQ(:);
    normFactor = sqrt(mean(abs(constellationFull).^2));
    normalizedLevels = levels / normFactor;

    realPart = real(symbols);
    imagPart = imag(symbols);

    idxIBin = reference_nearest_level_index(realPart, normalizedLevels) - 1;
    idxQBin = reference_nearest_level_index(imagPart, normalizedLevels) - 1;

    idxIGray = bitxor(idxIBin, bitshift(idxIBin, -1));
    idxQGray = bitxor(idxQBin, bitshift(idxQBin, -1));

    bitsI = de2bi(idxIGray, bitsPerAxis, 'left-msb');
    bitsQ = de2bi(idxQGray, bitsPerAxis, 'left-msb');

    bitMatrix = [bitsI, bitsQ];
    bits = reshape(bitMatrix.', [], 1);
end

function idx = reference_nearest_level_index(x, levels)
    idx = zeros(size(x));
    for sampleIndex = 1:numel(x)
        [~, levelIndex] = min(abs(x(sampleIndex) - levels));
        idx(sampleIndex) = levelIndex;
    end
end

function llr = reference_square_qam_llr(rxSyms, M, noiseVar)
    rxSyms = rxSyms(:).';
    bitsPerSymbol = log2(M);
    modulationSide = sqrt(M);
    bitsPerAxis = bitsPerSymbol / 2;

    if abs(modulationSide - round(modulationSide)) > 1e-12
        error('square_qam_llr: M must be square QAM');
    end
    modulationSide = round(modulationSide);

    if noiseVar <= 0
        noiseVar = 1e-12;
    end

    levels = -(modulationSide-1):2:(modulationSide-1);
    [gridI, gridQ] = meshgrid(levels, levels);
    constellation0 = gridI(:) + 1j * gridQ(:);
    normFactor = sqrt(mean(abs(constellation0).^2));
    normalizedLevels = levels / normFactor;

    binIdx = 0:modulationSide-1;
    grayIdx = bitxor(binIdx, bitshift(binIdx, -1));
    grayBits = de2bi(grayIdx, bitsPerAxis, 'left-msb');

    llr = zeros(1, numel(rxSyms) * bitsPerSymbol);
    for symbolIndex = 1:numel(rxSyms)
        x = real(rxSyms(symbolIndex));
        y = imag(rxSyms(symbolIndex));

        llrI = reference_local_pam_llr(x, normalizedLevels, grayBits, noiseVar);
        llrQ = reference_local_pam_llr(y, normalizedLevels, grayBits, noiseVar);

        outIdx = (symbolIndex - 1) * bitsPerSymbol + (1:bitsPerSymbol);
        llr(outIdx) = [llrI, llrQ];
    end
end

function llr = reference_local_pam_llr(z, normalizedLevels, grayBits, noiseVar)
    [modulationSide, bitsPerAxis] = size(grayBits); %#ok<ASGLU>
    distance2 = (z - normalizedLevels(:)).^2;
    llr = zeros(1, bitsPerAxis);

    for bitIndex = 1:bitsPerAxis
        idx0 = find(grayBits(:, bitIndex) == 0); %#ok<FNDSB>
        idx1 = find(grayBits(:, bitIndex) == 1); %#ok<FNDSB>
        minDistance0 = min(distance2(idx0));
        minDistance1 = min(distance2(idx1));
        llr(bitIndex) = (minDistance1 - minDistance0) / max(noiseVar, 1e-12);
    end
end

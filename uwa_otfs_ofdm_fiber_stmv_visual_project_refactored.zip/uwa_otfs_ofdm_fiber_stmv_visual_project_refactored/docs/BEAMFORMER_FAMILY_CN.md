# 波束形成算法族补充说明

项目当前统一支持以下接收波束形成方法：

- `cbf`：常规波束形成 / delay-and-sum
- `mvdr`：逐频点窄带 MVDR / Capon
- `wicmv`：宽带非相干 MVDR
- `stmv`：导向最小方差波束形成
- `improved_stmv`：CBF 子阵 + STMV 级联

## 1. 统一接口

所有方法都通过：

- `uwa_line_array_path_response.m`
- `uwa_apply_line_array_beamforming.m`
- `uwa_beam_scan_spectrum.m`

调用，因此：

- 主链路仿真
- 单包节点抓取
- 扫描谱图
- 输出频谱图
- 方法比较脚本

都不需要改调用方式。

## 2. 当前项目中的含义

### CBF

稳健、简单、阵增益直观，但抗干扰和分辨力有限。

### MVDR

逐频点最小方差无畸变响应，突出高分辨和零陷抑制。

### WICMV

先对子带做 MVDR，再由下游扫描/功率整合实现宽带非相干输出。

### STMV

使用导向协方差矩阵的项目级近似实现，和普通 MVDR 在建模层面区分开。

### improved_STMV

先做子阵 CBF，再在低维子阵输出上做 STMV/MVDR，自适应维数更低，更符合论文中“CBF + STMV 级联”的工程逻辑。

## 3. 快速查看

```matlab
run_beamformer_selection_experiment('quick')
run_generate_beamforming_suite('quick')
```

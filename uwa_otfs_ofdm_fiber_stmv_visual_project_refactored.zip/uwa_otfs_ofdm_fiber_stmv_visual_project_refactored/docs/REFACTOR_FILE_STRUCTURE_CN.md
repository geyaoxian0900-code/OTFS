# 重构后的文件结构说明（含修改原因与依赖说明）

## 1. 重构目标

本次重构遵循以下约束：

- **不修改原有算法逻辑**，重点重构入口脚本、流程编排层与可安全向量化的小型数值内核。
- **保持数值计算结果一致**。对改为向量化的函数，已额外提供 `tests/refactor_regression_checks.m` 供在 MATLAB 中执行误差回归检查，目标阈值为 **`< 1e-10`**。
- **不引入新的未声明工具箱依赖**。重构未新增第三方工具箱；若运行原工程本身涉及工具箱，已在下文明确列出。

## 2. 本次重构范围

### 2.1 主要重构对象

- 顶层入口脚本 `scripts/*.m`
- 主流程编排函数 `core/models/uwa_run_link_simulation.m`
- 可安全向量化的基础数值函数：
  - `core/array/uwa_apply_weights_to_array_tf.m`
  - `core/array/uwa_apply_line_array_beamforming.m`
  - `core/utils/qam_demod.m`
  - `core/utils/square_qam_llr.m`
- 新增统一工作流目录：`core/workflow/`
- 新增回归验证脚本目录：`tests/`

### 2.2 未改动的部分

以下内容保持原有核心实现不变，以最大限度保证结果一致性：

- Bellhop / synthetic nominal path 路径生成
- OTFS / OFDM 帧生成、信道通过、均衡、译码主流程
- 各类波束形成器主体公式
- 大型绘图函数的绘图内容和输出接口

## 3. 修改后的目录结构（重点文件）

```text
uwa_otfs_ofdm_fiber_stmv_visual_project_refactored/
├─ setup_project_paths.m
├─ README.md
├─ plot_results.m
├─ config/
├─ core/
│  ├─ array/
│  │  ├─ uwa_apply_line_array_beamforming.m      ← 已向量化
│  │  └─ uwa_apply_weights_to_array_tf.m         ← 已向量化
│  ├─ models/
│  │  └─ uwa_run_link_simulation.m               ← 主流程拆分
│  ├─ utils/
│  │  ├─ qam_demod.m                             ← 最近电平搜索向量化
│  │  └─ square_qam_llr.m                        ← 按符号 LLR 计算向量化
│  └─ workflow/                                  ← 新增，统一入口/流程辅助函数
│     ├─ uwa_initialize_script_context.m
│     ├─ uwa_apply_runtime_overrides.m
│     ├─ uwa_prepare_comparison_branch_config.m
│     ├─ uwa_capture_visual_snapshot.m
│     ├─ uwa_save_visual_snapshot.m
│     ├─ uwa_build_visual_output_dirs.m
│     ├─ uwa_prepare_link_simulation_dirs.m
│     ├─ uwa_get_otfs_detector_method.m
│     ├─ uwa_initialize_link_metrics.m
│     ├─ uwa_run_snr_packet_batch.m
│     └─ uwa_build_link_results.m
├─ scripts/
│  ├─ run_complete_uwa_otfs_ofdm_chain.m
│  ├─ run_complete_uwa_otfs_ofdm_visual_project.m
│  ├─ run_beamformer_selection_experiment.m
│  ├─ run_generate_beamforming_suite.m
│  ├─ run_generate_link_node_figures.m
│  └─ run_otfs_bf_dae_detector_experiment.m
└─ tests/
   └─ refactor_regression_checks.m
```

## 4. 每个新增函数的职责说明

### 4.1 `core/workflow/uwa_initialize_script_context.m`
- 作用：统一完成 `close all` / `clc` / 项目根目录定位 / `setup_project_paths`。
- 目的：消除多个入口脚本中重复出现的初始化样板代码。

### 4.2 `core/workflow/uwa_apply_runtime_overrides.m`
- 作用：统一处理 `beamformerMethod`、`otfsDetectorMethod` 运行时覆盖。
- 目的：避免多个脚本重复做 `isempty + lower + strtrim + 字段判空`。

### 4.3 `core/workflow/uwa_prepare_comparison_branch_config.m`
- 作用：生成某个对比分支（beamformer / detector）的 `output_dir`、`bellhop_tmp_dir`、`bellhop_cache_dir`。
- 目的：把实验分支目录规则集中管理。

### 4.4 `core/workflow/uwa_capture_visual_snapshot.m`
- 作用：把“获取标称路径 + 抓取可视化快照”封装成单一函数。
- 目的：减轻入口脚本复杂度。

### 4.5 `core/workflow/uwa_save_visual_snapshot.m`
- 作用：保存 `visual_snapshot.mat`，保留原有长路径兜底逻辑与 `-v7/-v7.3` 优先级。
- 目的：把文件系统异常处理从主入口移出。

### 4.6 `core/workflow/uwa_build_visual_output_dirs.m`
- 作用：统一生成通信节点图和波束形成图输出目录。
- 目的：集中目录命名规则。

### 4.7 `core/workflow/uwa_prepare_link_simulation_dirs.m`
- 作用：在链路仿真开始前，统一准备 `output_dir` 与 Bellhop 临时/缓存目录。
- 目的：让 `uwa_run_link_simulation.m` 只保留仿真流程，不再承担目录治理。

### 4.8 `core/workflow/uwa_get_otfs_detector_method.m`
- 作用：统一解析 OTFS 检测器方法，并保留默认值 `tf_mmse`。
- 目的：减少主流程中的字段判定逻辑。

### 4.9 `core/workflow/uwa_initialize_link_metrics.m`
- 作用：统一预分配 BER/PER 与 `rx_array_snapshots`。
- 目的：满足“预分配数组内存”要求。

### 4.10 `core/workflow/uwa_run_snr_packet_batch.m`
- 作用：执行一个固定 `PRB + SNR` 工作点下的所有 Monte-Carlo 包仿真。
- 目的：将主仿真函数按职责拆分，保持单函数单任务。

### 4.11 `core/workflow/uwa_build_link_results.m`
- 作用：统一构造结果结构体。
- 目的：消除主流程末尾的重复结构体拼装代码。

## 5. 已修改文件与修改要点

### 5.1 入口脚本

| 文件 | 修改内容 | 结果影响 |
|---|---|---|
| `scripts/run_complete_uwa_otfs_ofdm_chain.m` | 提取初始化、运行时覆盖逻辑 | 不改变数值结果 |
| `scripts/run_complete_uwa_otfs_ofdm_visual_project.m` | 提取快照抓取、保存、目录构造 | 不改变数值结果 |
| `scripts/run_beamformer_selection_experiment.m` | 抽取对比分支配置生成 | 不改变数值结果 |
| `scripts/run_generate_beamforming_suite.m` | 抽取快照生成公共流程 | 不改变数值结果 |
| `scripts/run_generate_link_node_figures.m` | 抽取快照生成公共流程 | 不改变数值结果 |
| `scripts/run_otfs_bf_dae_detector_experiment.m` | 抽取 detector 对比分支配置生成 | 不改变数值结果 |

### 5.2 主流程函数

| 文件 | 修改内容 | 结果影响 |
|---|---|---|
| `core/models/uwa_run_link_simulation.m` | 拆分为目录准备、检测器解析、预分配、单工作点仿真、结果组装 | 不改变 Monte-Carlo 逻辑 |

### 5.3 向量化函数

| 文件 | 原始热点 | 重构方式 | 数值说明 |
|---|---|---|---|
| `core/array/uwa_apply_weights_to_array_tf.m` | 按子载波循环加权 | 改为 3D 张量广播 + `sum(...,3)` | 线性组合公式不变 |
| `core/array/uwa_apply_line_array_beamforming.m` | 按路径循环叠加 | 改为路径维广播 + `sum(...,3)` | 路径叠加公式不变 |
| `core/utils/qam_demod.m` | 最近电平逐样本搜索 | 改为矩阵距离一次性最小值搜索 | 硬判决规则不变 |
| `core/utils/square_qam_llr.m` | 按符号逐个计算 LLR | 改为样本批量距离矩阵计算 | max-log LLR 公式不变 |

## 6. 工具箱 / 外部依赖说明

### 6.1 本次重构**没有新增**的依赖

- 没有新增第三方工具箱
- 没有新增 MEX / Python / Java 依赖
- 没有新增并行工具箱依赖

### 6.2 原工程已存在、运行时可能需要的依赖

#### （1）Communications Toolbox
下列函数通常依赖 Communications Toolbox：

- `poly2trellis`
- `convenc`
- `vitdec`
- `de2bi`
- `bi2de`

涉及文件：

- `core/utils/ldpc_encode.m`
- `core/utils/ldpc_decode.m`
- `core/utils/qam_demod.m`
- `core/utils/qam_mod.m`
- `core/utils/square_qam_llr.m`

#### （2）Signal Processing Toolbox（视 MATLAB 版本而定）
下列窗函数在部分版本中可能依赖 Signal Processing Toolbox：

- `hann`
- `hamming`

涉及文件：

- `core/array/uwa_array_taper.m`

#### （3）Bellhop（可选外部程序）
- 若本机安装了 Bellhop，可直接使用真实路径声学计算。
- 若未安装，工程已有 synthetic nominal path 回退逻辑，通常仍可运行主要流程。

## 7. 数值一致性验证建议

### 7.1 先运行局部回归检查

```matlab
setup_project_paths(pwd, false)
run('tests/refactor_regression_checks.m')
```

预期：

- 向量化重构函数与参考实现的最大绝对误差 < `1e-10`

### 7.2 再运行端到端 smoke test

```matlab
run_complete_uwa_otfs_ofdm_chain('quick')
run_complete_uwa_otfs_ofdm_visual_project('quick')
```

## 8. 备注

- 本次重构的目标是**在不改算法逻辑的前提下，显著降低入口层与流程层的重复代码**。
- 对 Monte-Carlo 主循环（PRB/SNR/packet）未强行做“伪向量化”，因为这会混入随机种子、Bellhop 路径生成、逐包译码等状态逻辑，反而更容易破坏结果一致性。
- 已对适合向量化且公式清晰的数值内核进行了矩阵化替换。

# 本次更新

1. 新增 `paper_final` 模式，用于更高统计量的最终论文图。
2. 新增 `paper_single_prb16` 与 `paper_single_prb4` 模式，便于输出更适合论文排版的单配置曲线。
3. 修复 `plot_results.m` 文件命名重复问题，避免生成 `*_paper_paper.png`。

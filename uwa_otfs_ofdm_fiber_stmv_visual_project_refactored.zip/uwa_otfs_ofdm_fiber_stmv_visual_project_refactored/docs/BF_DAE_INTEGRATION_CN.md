# BF-DAE 集成说明（OTFS 水声通信）

本说明对应新增的 OTFS 检测路径：

- `tf_mmse`：原项目默认 TF-domain MMSE
- `bf_dae`：TF 域波束形成预处理 + DD 域多通道自适应检测

## 1. 流程

1. OTFS 发射符号 `X_dd` 经过 ISFFT 得到 `X_tf`
2. 依据 Bellhop/UWA + 阵列模型构造阵元级 `Y_tf_elem`
3. 在 TF 域根据选定波达角做 R→Q 波束形成预处理，得到 `Z_tf(:,:,q)`
4. 对每个波束输出做 SFFT，得到 `z_dd(:,:,q)`
5. 在 DD 域运行多通道 DAE/IPNLMS 检测，输出 `X_hat_dd`
6. 对 `X_hat_dd(data_idx)` 生成软比特和译码结果

## 2. 当前工程实现特点

- 支持直接使用物理路径角作为 DoA 参考
- 也支持通过扫描谱峰值选取波束方向
- DAE 采用轻量化 2D feedforward / feedback + IPNLMS 型更新
- 保持和原有 `uwa_run_otfs_frame.m` 一致的输出接口

## 3. 关键文件

- `core/detection/uwa_tf_beamforming_preprocess_otfs.m`
- `core/detection/uwa_dd_multichannel_ipnlms_dae.m`
- `core/detection/uwa_otfs_bf_dae_detect.m`
- `scripts/run_otfs_bf_dae_detector_experiment.m`

## 4. 建议命令

```matlab
run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv', 'bf_dae')
run_otfs_bf_dae_detector_experiment('paper', 'improved_stmv')
```

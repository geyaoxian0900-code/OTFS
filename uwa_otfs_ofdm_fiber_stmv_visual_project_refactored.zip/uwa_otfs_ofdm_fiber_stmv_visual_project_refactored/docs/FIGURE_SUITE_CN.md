# 图形清单与对应代码

## 1. 完整主入口

```matlab
run_complete_uwa_otfs_ofdm_visual_project('quick')
```

## 2. 通信链路节点图

由：

- `core/models/uwa_capture_link_nodes.m`
- `core/plotting/uwa_generate_communication_node_figures.m`

生成。

对应图包括：

1. `system_chain_block_diagram`
2. `info_bits`
3. `coded_bits`
4. `tx_constellation`
5. `otfs_tx_dd_grid`
6. `otfs_tx_tf_grid`
7. `otfs_tx_time_signal`
8. `ofdm_tx_tf_grid`
9. `ofdm_tx_time_signal`
10. `single_sensor_tf_channel`
11. `beamformed_tf_channel`
12. `effective_dd_channel`
13. `otfs_rx_time_element1`
14. `otfs_rx_time_beamformed`
15. `otfs_rx_tf_noisy`
16. `otfs_rx_dd_noisy`
17. `otfs_eq_dd`
18. `ofdm_rx_time_element1`
19. `ofdm_rx_time_beamformed`
20. `ofdm_rx_tf_noisy`
21. `ofdm_eq_tf`
22. `otfs_constellation_prepost`
23. `ofdm_constellation_prepost`
24. `otfs_llr`
25. `ofdm_llr`
26. `decoded_bits_compare`
27. `otfs_single_vs_beam_spectrum`
28. `ofdm_single_vs_beam_spectrum`

## 3. 阵列 / 波束形成图

由：

- `core/plotting/uwa_generate_beamforming_figure_suite.m`

生成。

对应图包括：

1. `beam_pointing_pattern`
2. `beam_scan_spectrum`
3. `beam_output_spectrum_0deg`
4. `subarray_scan_spectrum_compare`
5. `subarray_output_spectrum_compare`
6. `element1_zeroed_result`
7. `pure_signal_scan_spectrum`
8. `array_gain_vs_direction`
9. `cbf_weight_norm`
10. `spacing_sweep_beampattern`
11. `arrival_angle_cases`
12. `fast_beamforming_compare`

## 4. 快速波束形成算法

代码：

- `core/array/uwa_fast_cbf_fft_scan.m`

说明：

- 这是基于 ULA 空间 FFT 的快速扫描近似；
- 适合补论文中的“快速算法”与复杂度内容；
- 如果后续做宽带严格工程化，可进一步做分频带 / 聚焦矩阵 / 宽带时延补偿版本。

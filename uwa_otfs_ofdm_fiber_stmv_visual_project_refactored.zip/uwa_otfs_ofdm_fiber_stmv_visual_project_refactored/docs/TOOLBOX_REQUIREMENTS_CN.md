# 工具箱与外部依赖说明

## 必要说明

本次重构**未引入新的未声明工具箱**。以下依赖均来自原工程已有实现。

## 1. Communications Toolbox

原工程中以下函数通常依赖 Communications Toolbox：

- `poly2trellis`
- `convenc`
- `vitdec`
- `de2bi`
- `bi2de`

涉及文件：

- `core/utils/ldpc_encode.m`
- `core/utils/ldpc_decode.m`
- `core/utils/qam_demod.m`
- `core/utils/qam_mod.m`
- `core/utils/square_qam_llr.m`

## 2. Signal Processing Toolbox（部分 MATLAB 版本可能需要）

原工程中以下函数可能依赖 Signal Processing Toolbox：

- `hann`
- `hamming`

涉及文件：

- `core/array/uwa_array_taper.m`

## 3. Bellhop（可选外部程序）

- 若本机已安装 Bellhop，则可直接运行声学路径求解。
- 若未安装，工程内已有 synthetic path 的回退机制，通常可以继续完成主要图与链路流程。

## 4. 重构新增部分的依赖结论

重构新增的 `core/workflow/*.m` 与 `tests/refactor_regression_checks.m`：

- **没有新增任何工具箱依赖**
- 仅调用原工程已有函数或 MATLAB 基础语法

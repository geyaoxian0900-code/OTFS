# 模式说明

## quick
- SNR：0:3:12
- 每个 SNR 包数：10
- 用途：快速检查链路是否跑通

## paper
- SNR：0:1:12
- 每个 SNR 包数：200
- 用途：常规论文出图

## paper_final
- SNR：0:1:12
- 每个 SNR 包数：1000
- 用途：最终论文定稿图，尤其适合高 SNR 尾部更稳定的 BER/PER 统计

## paper_single_prb16
- SNR：0:1:12
- 每个 SNR 包数：200
- PRB：16
- 用途：输出单一 PRB=16 的正式论文图

## paper_single_prb4
- SNR：0:1:12
- 每个 SNR 包数：200
- PRB：4
- 用途：输出单一 PRB=4 的正式论文图

## full
- 兼容别名
- 当前等价于 `paper`

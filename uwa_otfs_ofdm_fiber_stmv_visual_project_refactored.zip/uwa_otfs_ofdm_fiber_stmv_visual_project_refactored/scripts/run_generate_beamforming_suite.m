function manifest = run_generate_beamforming_suite(mode, beamformerMethod)
%RUN_GENERATE_BEAMFORMING_SUITE Generate only the beamforming figure suite.
%
% Inputs:
%   mode             - Run mode string.
%   beamformerMethod - Optional beamformer override.
%
% Output:
%   manifest         - Saved figure manifest struct array.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformerMethod = '';
    end

    scriptContext = uwa_initialize_script_context(mfilename('fullpath'), false); % [Refactor] 原因：使用统一路径初始化，但保留当前图窗状态，避免无关清理。

    cfg = visualization_project_config(mode);
    cfg.project_root = scriptContext.projectRoot; % [Refactor] 原因：统一补充 project_root 字段，便于后续公共流程复用。
    cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod); % [Refactor] 原因：复用可选波束形成器覆盖逻辑。

    snapshotTag = ['beam_suite_' lower(mode) '_' cfg.rx_array.combine_method];
    [~, visualSnapshot] = uwa_capture_visual_snapshot(cfg, snapshotTag); % [Refactor] 原因：复用公共可视化快照生成流程，消除重复 Bellhop + capture 代码。

    outDir = fullfile(cfg.output_root, 'beamforming_suite_only');
    if exist(outDir, 'dir') ~= 7
        mkdir(outDir);
    end
    manifest = uwa_generate_beamforming_figure_suite(visualSnapshot, outDir);
end

function allResults = run_otfs_bf_dae_detector_experiment(mode, beamformerMethod)
%RUN_OTFS_BF_DAE_DETECTOR_EXPERIMENT Compare TF-MMSE and BF-DAE OTFS detectors.
%
% Example:
%   run_otfs_bf_dae_detector_experiment('quick')
%   run_otfs_bf_dae_detector_experiment('paper', 'improved_stmv')
%
% Inputs:
%   mode             - Run mode string.
%   beamformerMethod - Receive beamformer used during detector comparison.
%
% Output:
%   allResults       - Cell array of result structs for compared detectors.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2 || isempty(beamformerMethod)
        beamformerMethod = 'improved_stmv';
    end

    scriptContext = uwa_initialize_script_context(mfilename('fullpath'), true); % [Refactor] 原因：统一入口初始化和路径设置，减少实验脚本重复逻辑。

    baseCfg = complete_chain_demo_config(mode);
    baseCfg.project_root = scriptContext.projectRoot; % [Refactor] 原因：统一为基础配置补充 project_root，便于后续公共目录函数使用。
    baseCfg = uwa_apply_runtime_overrides(baseCfg, beamformerMethod); % [Refactor] 原因：复用统一的 beamformer 覆盖逻辑。

    exp = uwa_begin_experiment(baseCfg, mode, 'run_otfs_bf_dae_detector_experiment');
    cleanupObj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    methods = {'tf_mmse', 'bf_dae'};
    allResults = cell(1, numel(methods)); % [Refactor] 原因：显式预分配，避免循环内 cell 动态增长。
    for methodIndex = 1:numel(methods)
        methodName = methods{methodIndex};
        branchCfg = uwa_prepare_comparison_branch_config(baseCfg, exp.run_dir, methodName); % [Refactor] 原因：抽取共享的分支目录与缓存构造逻辑。
        branchCfg.otfs_detection.method = methodName;

        uwa_log('============================================================');
        uwa_log('OTFS detector comparison branch: %s', methodName);
        uwa_log('Receive beamformer             : %s', branchCfg.rx_array.combine_method);
        uwa_log('============================================================');

        allResults{methodIndex} = uwa_run_link_simulation(branchCfg, [mode '_' methodName], struct('run_dir', branchCfg.output_dir));
    end

    all_results = allResults; %#ok<NASGU> % [Refactor] 原因：保存时保留原 MAT 变量名，避免历史分析脚本失配。
    base_cfg = baseCfg; %#ok<NASGU> % [Refactor] 原因：保持结果文件中的配置变量命名兼容。
    save(fullfile(exp.run_dir, ['otfs_detector_results_' mode '.mat']), 'all_results', 'methods', 'base_cfg');
    uwa_plot_otfs_detector_comparison(allResults, methods, exp.run_dir, mode);
    uwa_log('OTFS detector comparison finished. Folder: %s', exp.run_dir);
end

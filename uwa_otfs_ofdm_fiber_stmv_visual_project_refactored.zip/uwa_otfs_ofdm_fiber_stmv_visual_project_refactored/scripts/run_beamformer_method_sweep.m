function all_results = run_beamformer_method_sweep(mode)
%RUN_BEAMFORMER_METHOD_SWEEP Backward-compatible wrapper.
%
% New preferred name:
%   run_beamformer_selection_experiment('quick')

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    all_results = run_beamformer_selection_experiment(mode);
end

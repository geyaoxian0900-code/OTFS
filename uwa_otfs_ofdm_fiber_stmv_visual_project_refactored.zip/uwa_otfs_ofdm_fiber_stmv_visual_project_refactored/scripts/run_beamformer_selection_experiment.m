function allResults = run_beamformer_selection_experiment(mode)
%RUN_BEAMFORMER_SELECTION_EXPERIMENT Compare CBF/MVDR/WICMV/STMV/improved-STMV.
%
% This script keeps the transceiver, channel, coding, mapping, and OTFS/OFDM
% settings fixed, and changes only cfg.rx_array.combine_method. It is the
% reproducible comparison used to justify choosing improved STMV as the
% default OTFS receive beamformer.
%
% Input:
%   mode       - Run mode string.
%
% Output:
%   allResults - Cell array of result structs, one per beamformer.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end

    scriptContext = uwa_initialize_script_context(mfilename('fullpath'), true); % [Refactor] 原因：复用统一初始化逻辑，消除入口脚本重复代码。

    baseCfg = beamformer_selection_config(mode);
    baseCfg.project_root = scriptContext.projectRoot; % [Refactor] 原因：补充统一的工程根目录来源，便于后续路径相关函数复用。
    methods = baseCfg.rx_array.candidate_methods;

    exp = uwa_begin_experiment(baseCfg, mode, 'run_beamformer_selection_experiment');
    cleanupObj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU>

    allResults = cell(1, numel(methods)); % [Refactor] 原因：显式预分配结果单元数组，避免循环内动态扩展。
    for methodIndex = 1:numel(methods)
        methodName = methods{methodIndex};
        branchCfg = uwa_prepare_comparison_branch_config(baseCfg, exp.run_dir, methodName); % [Refactor] 原因：提取分支配置构造逻辑，复用目录/缓存规则。
        branchCfg.rx_array.combine_method = methodName;
        branchCfg.seed_base = baseCfg.seed_base; % [Refactor] 原因：保持原公平对比所需的相同随机种子设置不变。

        uwa_log('============================================================');
        uwa_log('Beamformer comparison branch: %s', methodName);
        uwa_log('============================================================');
        allResults{methodIndex} = uwa_run_link_simulation(branchCfg, [mode '_' methodName], struct('run_dir', branchCfg.output_dir));
    end

    all_results = allResults; %#ok<NASGU> % [Refactor] 原因：保存时保留原 MAT 变量名，避免下游脚本兼容性变化。
    base_cfg = baseCfg; %#ok<NASGU> % [Refactor] 原因：保持历史结果文件字段命名不变。
    save(fullfile(exp.run_dir, ['beamformer_selection_results_' mode '.mat']), 'all_results', 'methods', 'base_cfg');
    uwa_plot_beamformer_selection(allResults, methods, exp.run_dir, mode);
    uwa_log('Beamformer selection finished. Folder: %s', exp.run_dir);
end

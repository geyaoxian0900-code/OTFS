function outputs = run_complete_uwa_otfs_ofdm_visual_project(mode, beamformerMethod, otfsDetectorMethod)
%RUN_COMPLETE_UWA_OTFS_OFDM_VISUAL_PROJECT Full project with all requested figures.
%
% Main user entry for the expanded project.
% Optional third argument selects the OTFS detector.
%
% Usage:
%   run_complete_uwa_otfs_ofdm_visual_project
%   run_complete_uwa_otfs_ofdm_visual_project('quick')
%   run_complete_uwa_otfs_ofdm_visual_project('paper')
%   run_complete_uwa_otfs_ofdm_visual_project('paper_final')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'cbf')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'stmv')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv')
%   run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv', 'bf_dae')
%
% Inputs:
%   mode               - Run mode string.
%   beamformerMethod   - Optional receive beamformer override.
%   otfsDetectorMethod - Optional OTFS detector override.
%
% Output:
%   outputs.results            : BER/PER Monte-Carlo results
%   outputs.visual_snapshot    : representative node snapshot
%   outputs.chain_manifest     : communication-node figure list
%   outputs.beam_manifest      : beamforming-figure list
%   outputs.summary_manifest   : markdown manifest path

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformerMethod = '';
    end
    if nargin < 3
        otfsDetectorMethod = '';
    end

    scriptContext = uwa_initialize_script_context(mfilename('fullpath'), true); % [Refactor] 原因：将重复的工程初始化提炼为单一职责函数，入口代码只保留高层流程。

    cfg = visualization_project_config(mode);
    cfg.project_root = scriptContext.projectRoot; % [Refactor] 原因：统一从脚本上下文继承工程根目录，避免重复 fileparts 嵌套调用。
    cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod, otfsDetectorMethod); % [Refactor] 原因：复用公共配置覆盖逻辑，消除同类条件代码块。

    exp = uwa_begin_experiment(cfg, mode, 'run_complete_uwa_otfs_ofdm_visual_project');
    cleanupObj = onCleanup(@() uwa_finish_experiment(exp)); %#ok<NASGU> % [Refactor] 原因：保留原始清理语义，统一局部变量命名风格。

    uwa_log('============================================================');
    uwa_log('Expanded UWA OTFS/OFDM full visual project');
    uwa_log('Mode              : %s', upper(mode));
    uwa_log('Beamformer        : %s', cfg.rx_array.combine_method);
    uwa_log('Output run folder : %s', exp.run_dir);
    uwa_log('OTFS detector     : %s', cfg.otfs_detection.method);
    uwa_log('Representative PRB: %d', cfg.visual.rep_prb);
    uwa_log('Representative SNR: %.2f dB', cfg.visual.rep_snr_dB);
    uwa_log('============================================================');

    cfg.output_dir = exp.run_dir; % [Refactor] 原因：显式绑定所有输出到当前 run_dir，避免后续辅助函数依赖隐式路径推断。
    cfg.run_dir = exp.run_dir;    % [Refactor] 原因：与 output_dir 同步保存，保持现有下游接口兼容。

    results = uwa_run_link_simulation(cfg, mode, exp);

    snapshotTag = ['visual_project_' lower(mode) '_' cfg.rx_array.combine_method];
    [nominalPaths, visualSnapshot] = uwa_capture_visual_snapshot(cfg, snapshotTag); %#ok<NASGU> % [Refactor] 原因：提取“路径获取 + 快照生成”组合流程，降低主脚本复杂度。
    visualSnapshotSavePath = uwa_save_visual_snapshot(visualSnapshot, exp.run_dir, exp.run_id); %#ok<NASGU> % [Refactor] 原因：将长路径保存兜底逻辑移入独立函数，避免主入口夹杂文件系统异常处理。

    [chainDir, beamDir] = uwa_build_visual_output_dirs(exp.run_dir, cfg.visual); % [Refactor] 原因：公共目录规则封装，减少重复 fullfile 拼接。
    chainManifest = uwa_generate_communication_node_figures(visualSnapshot, chainDir);
    beamManifest = uwa_generate_beamforming_figure_suite(visualSnapshot, beamDir);
    summaryManifest = uwa_write_visual_manifest(exp.run_dir, results, chainManifest, beamManifest, visualSnapshot);

    uwa_log('Communication-node figures saved: %d', numel(chainManifest));
    uwa_log('Beamforming figures saved       : %d', numel(beamManifest));
    uwa_log('Figure manifest                 : %s', summaryManifest);
    uwa_log('============================================================');

    outputs = struct();
    outputs.results = results;
    outputs.visual_snapshot = visualSnapshot;
    outputs.chain_manifest = chainManifest;
    outputs.beam_manifest = beamManifest;
    outputs.summary_manifest = summaryManifest;
end

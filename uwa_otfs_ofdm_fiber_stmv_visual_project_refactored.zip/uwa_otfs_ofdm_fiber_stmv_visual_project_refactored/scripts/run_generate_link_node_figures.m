function manifest = run_generate_link_node_figures(mode, beamformerMethod)
%RUN_GENERATE_LINK_NODE_FIGURES Generate only the communication-node figures.
%
% Inputs:
%   mode             - Run mode string.
%   beamformerMethod - Optional beamformer override.
%
% Output:
%   manifest         - Saved figure manifest struct array.

    if nargin < 1 || isempty(mode)
        mode = 'quick';
    end
    if nargin < 2
        beamformerMethod = '';
    end

    scriptContext = uwa_initialize_script_context(mfilename('fullpath'), false); % [Refactor] 原因：复用统一工程上下文初始化，减少脚本级重复样板代码。

    cfg = visualization_project_config(mode);
    cfg.project_root = scriptContext.projectRoot; % [Refactor] 原因：统一 project_root 来源，便于后续函数共享路径上下文。
    cfg = uwa_apply_runtime_overrides(cfg, beamformerMethod); % [Refactor] 原因：复用波束形成器覆盖逻辑，避免单脚本单独处理字符串清洗。

    snapshotTag = ['node_suite_' lower(mode) '_' cfg.rx_array.combine_method];
    [~, visualSnapshot] = uwa_capture_visual_snapshot(cfg, snapshotTag); % [Refactor] 原因：提取共用的标称路径 + 快照抓取步骤。

    outDir = fullfile(cfg.output_root, 'communication_node_figures_only');
    if exist(outDir, 'dir') ~= 7
        mkdir(outDir);
    end
    manifest = uwa_generate_communication_node_figures(visualSnapshot, outDir);
end

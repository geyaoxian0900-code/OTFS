# OTFS/OFDM 水声通信 + 全光纤阵列 + 波束形成/可视化扩展项目

这是在原有 `uwa_otfs_ofdm_fiber_stmv_package` 基础上重组并继续扩展的完整项目。当前版本除了保留 Bellhop/UWA 信道、全光纤水听器线列阵、OTFS/OFDM 对比、通信链路节点图和论文风格 BER/PER 图，还补入了两类关键内容：

1. **OTFS 的波束形成预处理高效符号检测**
   - 新增 BF-DAE（beamforming preprocessing + DD-domain adaptive detection）路径
   - 在 TF 域先做 R→Q 波束形成预处理，再映射到 DD 域做多通道自适应检测
   - 用于和原有 TF-domain MMSE OTFS 检测作对比

2. **水声通信中的波束形成算法族**
   - CBF / delay-and-sum
   - MVDR / Capon
   - 宽带非相干 MVDR（WICMV）
   - STMV
   - 改进 STMV（CBF 子阵 + STMV 级联）

> 说明
>
> - “全光纤阵列”在本项目中是**接收阵列平台**建模，不把光学解调细节混入 OTFS/OFDM 波形链路。
> - 如果本机没有安装 Bellhop，代码会自动使用可重复的 synthetic nominal paths，保证图和链路都能跑通。
> - 当前 `ldpc_encode / ldpc_decode` 稳定实现仍然是卷积码 + puncture + Viterbi，不是严格标准 LDPC。
> - BF-DAE 是结合当前项目链路结构实现的工程化近似版本：接口、流程、图和对比实验完整，但为了保持可跑性，DD 域自适应检测采用轻量化 IPNLMS 型实现。

## 1. 最常用入口

### 1.1 完整可视化项目

```matlab
setup_project_paths(pwd, false)
run_complete_uwa_otfs_ofdm_visual_project('quick')
run_complete_uwa_otfs_ofdm_visual_project('paper')
run_complete_uwa_otfs_ofdm_visual_project('paper_final')
```

### 1.2 切换接收波束形成器

```matlab
run_complete_uwa_otfs_ofdm_visual_project('quick', 'cbf')
run_complete_uwa_otfs_ofdm_visual_project('quick', 'mvdr')
run_complete_uwa_otfs_ofdm_visual_project('quick', 'wicmv')
run_complete_uwa_otfs_ofdm_visual_project('quick', 'stmv')
run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv')
```

### 1.3 切换 OTFS 检测器

第三个参数是 OTFS 检测器：

```matlab
run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv', 'tf_mmse')
run_complete_uwa_otfs_ofdm_visual_project('quick', 'improved_stmv', 'bf_dae')
```

默认仍然是 `tf_mmse`。

## 2. 新增对比脚本

### 2.1 OTFS 检测器对比：TF-MMSE vs BF-DAE

```matlab
run_otfs_bf_dae_detector_experiment('quick')
run_otfs_bf_dae_detector_experiment('paper', 'improved_stmv')
```

输出：

- `otfs_detector_compare_ber_<mode>.png`
- `otfs_detector_compare_per_<mode>.png`
- 每个 detector 各自的 `results_*.mat`

### 2.2 波束形成算法族对比

```matlab
run_beamformer_selection_experiment('quick')
run_beamformer_selection_experiment('paper')
```

当前比较方法：

- `cbf`
- `mvdr`
- `wicmv`
- `stmv`
- `improved_stmv`

## 3. 输出目录

每次完整运行都会生成独立目录：

```text
output/runs/<时间_模式_波束形成器_seed>/
```

其中通常包含：

- `run_log.txt`
- `results_<mode>.mat`
- `visual_snapshot.mat`
- `figures/communication_nodes/`
- `figures/beamforming_suite/`
- `figures/summaries/figure_manifest.md`
- `ber_*_paper.png`
- `per_*_paper.png`

## 4. 现在补充了哪些图

### 4.1 通信链路节点图

由 `uwa_capture_link_nodes.m` + `uwa_generate_communication_node_figures.m` 自动生成，例如：

- 信息比特 / 编码比特 / 发射星座
- OTFS 发射 DD / TF / 时域
- OFDM 发射 TF / 时域
- 单水听器 TF 信道 / 波束形成后 TF 信道 / 等效 DD 信道
- OTFS 接收 TF / DD / 均衡后 DD
- OFDM 接收 TF / 均衡后 TF
- OTFS / OFDM 均衡前后星座图
- OTFS / OFDM LLR
- **新增：OTFS BF-DAE 第一束 TF 图、第一束 DD 图、BF-DAE 检测后 DD 图、BF-DAE 星座图、BF-DAE LLR**

### 4.2 阵列与波束形成图

由 `uwa_generate_beamforming_figure_suite.m` 自动生成，例如：

- 光纤阵列波束指向图
- 波束扫描方位谱图
- 0° 波束输出频谱图
- 整阵 / 不同数量子阵扫描图
- 整阵 / 不同数量子阵输出频谱图
- 阵列不同方向增益图
- 常规波束形成器加权向量范数图
- 不同阵元间距下的波束图
- 不同波达角条件下的方位谱图
- 1 号基元置零处理结果图
- 纯信号时波束扫描方位谱图
- 快速波束形成：精确扫描 vs FFT 快速扫描
- **新增：CBF / MVDR / WICMV / STMV / improved-STMV 扫描谱对比图**
- **新增：CBF / MVDR / WICMV / STMV / improved-STMV 的 0° 输出频谱对比图**

## 5. 关键新增文件

### 5.1 BF-DAE 相关

- `core/detection/uwa_tf_beamforming_preprocess_otfs.m`
- `core/detection/uwa_dd_multichannel_ipnlms_dae.m`
- `core/detection/uwa_otfs_bf_dae_detect.m`
- `scripts/run_otfs_bf_dae_detector_experiment.m`
- `core/plotting/uwa_plot_otfs_detector_comparison.m`

### 5.2 新增波束形成方法

- `core/array/uwa_beamformer_mvdr_path_response.m`
- `core/array/uwa_beamformer_wicmv_path_response.m`
- `core/array/uwa_beamformer_stmv_path_response.m`（改成更明确的 STMV 近似）

### 5.3 更新的重要入口/配置

- `scripts/run_complete_uwa_otfs_ofdm_visual_project.m`
- `config/complete_chain_demo_config.m`
- `config/visualization_project_config.m`
- `config/beamformer_selection_config.m`
- `setup_project_paths.m`

## 6. 推荐使用顺序

### 6.1 先做路径和环境检查

```matlab
cd('D:\MATLAB\MATLABfiles\OTFS\GITHUB\project\project2026033101_line_array_beamforming\uwa_otfs_ofdm_fiber_stmv_visual_project_v3_bellhop_path_fix\uwa_otfs_ofdm_fiber_stmv_visual_project')
setup_project_paths(pwd, false)
which run_complete_uwa_otfs_ofdm_visual_project -all
which run_otfs_bf_dae_detector_experiment -all
```

### 6.2 先快速检查图和流程

```matlab
run_complete_uwa_otfs_ofdm_visual_project('quick')
```

### 6.3 再检查 BF-DAE 的检测器对比

```matlab
run_otfs_bf_dae_detector_experiment('quick')
```

### 6.4 最后跑论文模式

```matlab
run_complete_uwa_otfs_ofdm_visual_project('paper')
run_otfs_bf_dae_detector_experiment('paper')
```

## 7. 附加说明

- BF-DAE 默认可直接使用 Bellhop 生成的路径角信息作为仿真中的 DoA 参考；也预留了基于扫描谱峰值选取波束方向的入口。
- `mvdr`、`wicmv`、`stmv`、`improved_stmv` 在项目里都保留了统一的接口，因此链路、图和方法比较脚本都能共用。
- 本项目的重点是“**Bellhop/UWA + 线阵 + 波束形成 + OTFS/OFDM + 所有关键节点可视化**”，因此新增内容优先保证：
  - 端到端可跑
  - 结果可画
  - 算法接口统一
  - 论文分析可以直接引用

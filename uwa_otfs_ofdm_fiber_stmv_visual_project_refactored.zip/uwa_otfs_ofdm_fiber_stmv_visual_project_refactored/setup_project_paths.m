function setup_project_paths(projectRoot, includeReferenceLegacy)
%SETUP_PROJECT_PATHS Add active project paths while keeping legacy/archive isolated.
%
% Usage:
%   setup_project_paths(projectRoot)
%   setup_project_paths(projectRoot, true)
%
% Inputs:
%   projectRoot            - Project root folder. Default: current file folder.
%   includeReferenceLegacy - Logical flag. true adds legacy/reference code.
%
% Output:
%   None.
%
% Notes:
%   This helper adds only directories that exist, so it is safe to call
%   repeatedly from different entry functions.

    if nargin < 1 || isempty(projectRoot)
        projectRoot = fileparts(mfilename('fullpath'));
    end
    if nargin < 2
        includeReferenceLegacy = false;
    end

    add_if_dir(projectRoot);
    add_if_dir(fullfile(projectRoot, 'config'));
    add_if_dir(fullfile(projectRoot, 'scripts'));

    add_if_dir(fullfile(projectRoot, 'core', 'array'));
    add_if_dir(fullfile(projectRoot, 'core', 'channel'));
    add_if_dir(fullfile(projectRoot, 'core', 'data'));
    add_if_dir(fullfile(projectRoot, 'core', 'detection'));
    add_if_dir(fullfile(projectRoot, 'core', 'equalizer'));
    add_if_dir(fullfile(projectRoot, 'core', 'experiment'));
    add_if_dir(fullfile(projectRoot, 'core', 'models'));
    add_if_dir(fullfile(projectRoot, 'core', 'modulation'));
    add_if_dir(fullfile(projectRoot, 'core', 'plotting'));
    add_if_dir(fullfile(projectRoot, 'core', 'utils'));
    add_if_dir(fullfile(projectRoot, 'core', 'workflow')); % [Refactor] 原因：为主流程新增独立工作流函数目录，避免入口脚本堆积重复编排代码。
    add_if_dir(fullfile(projectRoot, 'test'));
    add_if_dir(fullfile(projectRoot, 'tests')); % [Refactor] 原因：加入重构后的回归检查脚本目录，便于验证误差阈值要求。

    if includeReferenceLegacy
        add_if_dir(fullfile(projectRoot, 'legacy', 'fig37_reference'));
        add_if_dir(fullfile(projectRoot, 'legacy', 'helpers_reference'));
    end
end

function add_if_dir(folderPath)
%ADD_IF_DIR Add folder to MATLAB path only when it exists.
    if exist(folderPath, 'dir') == 7
        addpath(folderPath);
    end
end

function uwa_plot_otfs_detector_comparison(all_results, methods, out_dir, mode)
%UWA_PLOT_OTFS_DETECTOR_COMPARISON Compare OTFS detectors under controlled seeds.
%
% The branch comparison reuses the same packet-bit seeds and channel seeds.
% The OTFS observation model can still differ across detectors, so the title
% intentionally avoids claiming identical front-end observations.

    if nargin < 4 || isempty(mode)
        mode = 'quick';
    end
    if exist(out_dir, 'dir') ~= 7
        mkdir(out_dir);
    end

    cfg = local_plot_cfg();
    prb_list = local_get_prb_list(all_results);

    for iprb = 1:numel(prb_list)
        prb_val = prb_list(iprb);
        prb_tag = sprintf('prb%d', prb_val);

        % BER figure
        fig = figure('Color', 'w', 'Position', [100 100 920 680]);
        ax = axes(fig); %#ok<LAXES>
        hold(ax, 'on'); grid(ax, 'on'); box(ax, 'on');
        set(ax, 'YScale', 'log', 'Layer', 'top', 'FontName', cfg.font_name, ...
            'FontSize', cfg.axis_font_size, 'LineWidth', cfg.axis_line_width);

        legends = {};
        for i = 1:numel(all_results)
            r = all_results{i};
            if isempty(r) || size(r.ber_otfs, 1) < iprb
                continue;
            end
            semilogy(ax, r.snr_dB_list, local_safe(r.ber_otfs(iprb, :), cfg.ber_floor), cfg.styles{mod(i-1, numel(cfg.styles))+1}, ...
                'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
            legends{end+1} = sprintf('OTFS + %s', local_pretty(methods{i})); %#ok<AGROW>
        end
        if ~isempty(all_results)
            r0 = all_results{1};
            if ~isempty(r0) && size(r0.ber_ofdm, 1) >= iprb
                semilogy(ax, r0.snr_dB_list, local_safe(r0.ber_ofdm(iprb, :), cfg.ber_floor), '-k', 'LineWidth', 1.8);
                legends{end+1} = 'OFDM baseline'; %#ok<AGROW>
            end
        end
        xlabel(ax, 'SNR (dB)'); ylabel(ax, 'BER');
        title(ax, sprintf('OTFS detector comparison (PRB=%d, controlled seeds)', prb_val), 'Interpreter', 'none');
        legend(ax, legends, 'Location', 'southwest', 'Interpreter', 'none');
        ylim(ax, [cfg.ber_floor, 1]);
        local_save(fig, fullfile(out_dir, ['otfs_detector_compare_ber_' prb_tag '_' mode]), cfg.export_dpi);

        % PER figure
        fig = figure('Color', 'w', 'Position', [120 120 920 680]);
        ax = axes(fig); %#ok<LAXES>
        hold(ax, 'on'); grid(ax, 'on'); box(ax, 'on');
        set(ax, 'YScale', 'log', 'Layer', 'top', 'FontName', cfg.font_name, ...
            'FontSize', cfg.axis_font_size, 'LineWidth', cfg.axis_line_width);

        legends = {};
        for i = 1:numel(all_results)
            r = all_results{i};
            if isempty(r) || size(r.per_otfs, 1) < iprb
                continue;
            end
            semilogy(ax, r.snr_dB_list, local_safe(r.per_otfs(iprb, :), cfg.per_floor), cfg.styles{mod(i-1, numel(cfg.styles))+1}, ...
                'LineWidth', cfg.line_width, 'MarkerSize', cfg.marker_size);
            legends{end+1} = sprintf('OTFS + %s', local_pretty(methods{i})); %#ok<AGROW>
        end
        if ~isempty(all_results)
            r0 = all_results{1};
            if ~isempty(r0) && size(r0.per_ofdm, 1) >= iprb
                semilogy(ax, r0.snr_dB_list, local_safe(r0.per_ofdm(iprb, :), cfg.per_floor), '-k', 'LineWidth', 1.8);
                legends{end+1} = 'OFDM baseline'; %#ok<AGROW>
            end
        end
        xlabel(ax, 'SNR (dB)'); ylabel(ax, 'PER');
        title(ax, sprintf('OTFS detector comparison (PRB=%d, controlled seeds)', prb_val), 'Interpreter', 'none');
        legend(ax, legends, 'Location', 'southwest', 'Interpreter', 'none');
        ylim(ax, [cfg.per_floor, 1]);
        local_save(fig, fullfile(out_dir, ['otfs_detector_compare_per_' prb_tag '_' mode]), cfg.export_dpi);
    end
end

function cfg = local_plot_cfg()
    cfg.font_name = 'Times New Roman';
    cfg.axis_font_size = 12;
    cfg.axis_line_width = 1.0;
    cfg.line_width = 1.8;
    cfg.marker_size = 7;
    cfg.export_dpi = 300;
    cfg.ber_floor = 1e-5;
    cfg.per_floor = 1e-3;
    cfg.styles = {'-o', '--s', '-.^', ':d'};
end

function prb_list = local_get_prb_list(all_results)
    prb_list = [];
    for i = 1:numel(all_results)
        r = all_results{i};
        if ~isempty(r) && isfield(r, 'prb_list') && ~isempty(r.prb_list)
            prb_list = r.prb_list(:).';
            return;
        end
    end
    prb_list = 1;
end

function x = local_safe(x, floor_val)
    x(~isfinite(x)) = floor_val;
    x(x <= 0) = floor_val;
end

function name = local_pretty(name)
    name = lower(strtrim(char(name)));
    switch name
        case 'tf_mmse'
            name = 'TF-MMSE';
        case 'bf_dae'
            name = 'BF-DAE';
        otherwise
            name = upper(strrep(name, '_', '-'));
    end
end

function local_save(fig, stem, dpi)
    try
        exportgraphics(fig, [stem '.png'], 'Resolution', dpi);
    catch
        saveas(fig, [stem '.png']);
    end
    try
        savefig(fig, [stem '.fig']);
    catch
    end
end

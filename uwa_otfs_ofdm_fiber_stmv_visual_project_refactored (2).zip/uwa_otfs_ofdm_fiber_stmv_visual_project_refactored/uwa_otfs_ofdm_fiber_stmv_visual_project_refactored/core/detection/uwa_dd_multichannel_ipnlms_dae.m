function out = uwa_dd_multichannel_ipnlms_dae(cfg, Zdd, Xdd_ref, data_idx, noise_var)
%UWA_DD_MULTICHANNEL_IPNLMS_DAE Multichannel DD-domain adaptive detector.
%
% Complete revised version:
%   1) fixes LS-init vector shape issues;
%   2) keeps feedback-update sign consistent with y = w^H u - b^H d;
%   3) supports delayed feedback activation via feedback_start_pass;
%   4) separates "adaptation/training" from "final inference";
%   5) runs a frozen forward pass after adaptation so BER/PER are computed
%      from the trained detector rather than from pre-update outputs.
%
% Interface is kept compatible with the project.

    pars = cfg.otfs_detection.bf_dae;
    [N, M, Q] = size(Zdd);

    Kf = local_get_field(pars, 'Kf', 1);
    Lf = local_get_field(pars, 'Lf', 1);
    Kb = local_get_field(pars, 'Kb', 1);
    Lb = local_get_field(pars, 'Lb', 1);

    mu_f = local_get_field(pars, 'mu_f', 0.25);
    mu_b = local_get_field(pars, 'mu_b', 0.10);
    delta_f = local_get_field(pars, 'delta_f', 1e-3);
    delta_b = local_get_field(pars, 'delta_b', 1e-3);
    alpha = local_get_field(pars, 'ipnlms_alpha', 0);

    use_feedback = logical(local_get_field(pars, 'use_feedback', true));
    dd_after_train = logical(local_get_field(pars, 'decision_directed_after_training', true));
    num_passes = max(1, round(local_get_field(pars, 'num_passes', 1)));
    feedback_start_pass = max(1, round(local_get_field(pars, 'feedback_start_pass', 2)));
    ls_init_diag_loading = local_get_field(pars, 'ls_init_diag_loading', 1e-6);

    ff_len = (2 * Kf + 1) * (Lf + 1);
    fb_offsets = local_feedback_offsets(Kb, Lb);
    fb_len = size(fb_offsets, 1);

    order = data_idx(:);
    if isempty(order)
        error('uwa_dd_multichannel_ipnlms_dae: data_idx must not be empty.');
    end

    training_fraction = local_get_field(pars, 'training_fraction', 0.25);
    training_fraction = max(0, min(1, training_fraction));

    if training_fraction <= 0
        train_count = 0;
    else
        train_count = round(training_fraction * numel(order));
        min_train = round(local_get_field(pars, 'min_training_symbols', 1));
        train_count = max(min_train, train_count);
        train_count = min(numel(order), train_count);
    end

    % ------------------------------------------------------------------
    % Feedforward initialization (regularized LS center-tap init)
    % ------------------------------------------------------------------
    F = local_initialize_feedforward_filters( ...
        Zdd, Xdd_ref, order, train_count, Kf, Lf, Q, ff_len, ls_init_diag_loading);

    % Feedback filter initialization
    B = zeros(fb_len, 1);

    % ------------------------------------------------------------------
    % Pass A: adaptation / training only
    % IMPORTANT:
    %   We do NOT use the pre-update y_hat as the final detector output.
    % ------------------------------------------------------------------
    train_decisions_dd = zeros(N, M);

    for pass = 1:num_passes
        use_feedback_now = use_feedback && (pass >= feedback_start_pass) && (fb_len > 0);

        for it = 1:numel(order)
            lin = order(it);
            [k, l] = ind2sub([N, M], lin);

            y_hat = 0;
            ff_cell = cell(Q, 1);

            for q = 1:Q
                u_ff = local_ff_patch(Zdd(:, :, q), k, l, Kf, Lf);
                ff_cell{q} = u_ff;
                y_hat = y_hat + F{q}' * u_ff;
            end

            if use_feedback_now
                u_fb = local_fb_patch(train_decisions_dd, k, l, fb_offsets);
                y_hat = y_hat - B' * u_fb;
            else
                u_fb = zeros(0, 1);
            end

            x_true = Xdd_ref(k, l);

            if it <= train_count
                d = x_true;
            elseif dd_after_train
                d = local_hard_qam_symbol(y_hat, cfg.modulation);
            else
                d = x_true;
            end

            e = d - y_hat;

            % Feedforward update
            for q = 1:Q
                Gf = local_ipnlms_diag(F{q}, alpha);
                u_ff = ff_cell{q};
                denom_f = real(u_ff' * Gf * u_ff) + delta_f;
                F{q} = F{q} + mu_f * conj(e) * (Gf * u_ff) / max(denom_f, eps);
            end

            % Feedback update
            if use_feedback_now
                Gb = local_ipnlms_diag(B, alpha);
                denom_b = real(u_fb' * Gb * u_fb) + delta_b;
                B = B - mu_b * conj(e) * (Gb * u_fb) / max(denom_b, eps);
            end

            % Store adaptation-time decision only for recursion support
            train_decisions_dd(k, l) = d;
        end
    end

    % ------------------------------------------------------------------
    % Pass B: frozen forward inference with final trained filters
    % IMPORTANT:
    %   BER/PER should be computed from this pass, not from Pass A.
    % ------------------------------------------------------------------
    Xhat_dd = zeros(N, M);
    decisions_dd = zeros(N, M);

    use_feedback_final = use_feedback && (num_passes >= feedback_start_pass) && (fb_len > 0);

    for it = 1:numel(order)
        lin = order(it);
        [k, l] = ind2sub([N, M], lin);

        y_hat = 0;
        for q = 1:Q
            u_ff = local_ff_patch(Zdd(:, :, q), k, l, Kf, Lf);
            y_hat = y_hat + F{q}' * u_ff;
        end

        if use_feedback_final
            u_fb = local_fb_patch(decisions_dd, k, l, fb_offsets);
            y_hat = y_hat - B' * u_fb;
        end

        Xhat_dd(k, l) = y_hat;

        % Final inference must not use oracle symbols for feedback recursion.
        % Always use hard decisions here.
        decisions_dd(k, l) = local_hard_qam_symbol(y_hat, cfg.modulation);
    end

    rx_syms = Xhat_dd(data_idx(:)).';
    if nargin < 5 || isempty(noise_var)
        noise_var = 1;
    end
    llr = square_qam_llr(rx_syms, cfg.modulation, noise_var);

    out = struct();
    out.Xhat_dd = Xhat_dd;
    out.decisions_dd = decisions_dd;
    out.llr = llr(:).';
    out.rx_syms = rx_syms;
    out.beam_filters = F;
    out.feedback_filter = B;
    out.train_count = train_count;
    out.num_beams = Q;
    out.feedback_start_pass = feedback_start_pass;
    out.params = pars;
end

function F = local_initialize_feedforward_filters(Zdd, Xdd_ref, order, train_count, Kf, Lf, Q, ff_len, ls_init_loading)
    F = cell(Q, 1);
    center_idx = local_ff_center_index(Kf, Lf);

    for q = 1:Q
        F{q} = zeros(ff_len, 1);
    end

    if train_count <= 0
        F{1}(center_idx) = 1;
        return;
    end

    train_order = order(1:train_count);
    train_order = train_order(:);

    x_train = Xdd_ref(train_order);
    x_train = x_train(:);

    Zc = zeros(train_count, Q);
    for q = 1:Q
        zq = Zdd(:, :, q);
        z_train_q = zq(train_order);
        Zc(:, q) = z_train_q(:);
    end

    % Regularized LS: minimize ||x - Zc*v||^2
    G = Zc' * Zc + ls_init_loading * eye(Q);
    rhs = Zc' * x_train;

    if rcond(G) < 1e-12
        G = G + 1e-4 * eye(Q);
    end

    v = G \ rhs;      % x ≈ Zc * v
    w0 = conj(v);     % detector uses y = w^H z

    if any(~isfinite(w0))
        w0 = zeros(Q, 1);
        w0(1) = 1;
    end

    for q = 1:Q
        fq = zeros(ff_len, 1);
        fq(center_idx) = w0(q);
        F{q} = fq;
    end
end

function idx = local_ff_center_index(Kf, Lf)
    % Keep the same indexing convention as the existing implementation:
    % rows: Doppler offsets [-Kf, ..., Kf]
    % cols: delay offsets [0, ..., Lf]
    % center tap chosen at Doppler center, delay 0
    idx = Kf + 1;
    if Lf > 0
        idx = idx + 0 * (2 * Kf + 1);
    end
end

function u = local_ff_patch(Z, k, l, Kf, Lf)
    [N, M] = size(Z);
    u = zeros((2 * Kf + 1) * (Lf + 1), 1);
    t = 1;
    for dl = 0:Lf
        ll = mod(l - 1 + dl, M) + 1;
        for dk = -Kf:Kf
            kk = mod(k - 1 + dk, N) + 1;
            u(t) = Z(kk, ll);
            t = t + 1;
        end
    end
end

function offs = local_feedback_offsets(Kb, Lb)
    offs = [];
    for dl = 0:Lb
        for dk = -Kb:Kb
            if dl == 0 && dk == 0
                continue;
            end
            if dl == 0 && dk > 0
                continue;
            end
            offs = [offs; dk, -dl]; %#ok<AGROW>
        end
    end
end

function u = local_fb_patch(D, k, l, offs)
    [N, M] = size(D);
    L = size(offs, 1);
    u = zeros(L, 1);
    for i = 1:L
        kk = mod(k - 1 + offs(i, 1), N) + 1;
        ll = mod(l - 1 + offs(i, 2), M) + 1;
        u(i) = D(kk, ll);
    end
end

function G = local_ipnlms_diag(w, alpha)
    w = w(:);
    L = numel(w);
    if L == 0
        G = zeros(0, 0);
        return;
    end

    absw = abs(w);
    s = sum(absw) + eps;
    g = ((1 - alpha) / (2 * L)) * ones(L, 1) + ((1 + alpha) / (2 * s)) * absw;
    G = diag(g);
end

function sym = local_hard_qam_symbol(x, M)
    bits = qam_demod(x, M, 'hard');
    sym = qam_mod(bits, M);
    sym = sym(1);
end

function v = local_get_field(s, name, default_v)
    v = default_v;
    if isstruct(s) && isfield(s, name)
        cand = s.(name);
        if isnumeric(cand) || islogical(cand)
            v = cand;
        end
    end
end

function out = uwa_tf_beamforming_preprocess_otfs(cfg, freq_hz, Ytf_elem, beam_angles_deg, path_angles_deg, path_metric)
%UWA_TF_BEAMFORMING_PREPROCESS_OTFS TF-domain R-to-Q beamforming for OTFS.
%
% This helper follows the beamforming-preprocessing idea of the 2025 OTFS
% UWA paper: perform DoA-based receive beamforming directly in the TF
% domain, reducing the element domain from R hydrophones to Q beam outputs.
%
% Input:
%   cfg            : project config (uses cfg.rx_array and sound speed)
%   freq_hz        : [Ka x 1] absolute frequency of each active subcarrier
%   Ytf_elem       : [Ka x M x R] element-domain TF data
%   beam_angles_deg: [1 x Q] beam directions
%   path_angles_deg: [1 x P] optional path angles used to build the
%                    selected beamformer family for each requested beam
%   path_metric    : [1 x P] optional path metric/weight vector
%
% Output struct fields:
%   Ztf            : [Ka x M x Q] beamformed TF-domain outputs
%   weights        : [Ka x R x Q] full-array beamforming weights
%   beam_angles_deg, num_beams, num_elements, beamformer_info

    freq_hz = freq_hz(:);
    [Ka, Mtime, R] = size(Ytf_elem);
    Q = numel(beam_angles_deg);

    if nargin < 5 || isempty(path_angles_deg)
        path_angles_deg = beam_angles_deg(:).';
    else
        path_angles_deg = double(path_angles_deg(:).');
    end
    if nargin < 6 || isempty(path_metric)
        path_metric = ones(size(path_angles_deg));
    else
        path_metric = double(path_metric(:).');
        if numel(path_metric) ~= numel(path_angles_deg)
            path_metric = ones(size(path_angles_deg));
        end
    end

    Ztf = zeros(Ka, Mtime, Q);
    W = zeros(Ka, R, Q);
    beamformer_info = cell(1, Q);

    for q = 1:Q
        [Wq, bf_info_q] = local_build_beam_weights(cfg, freq_hz, R, beam_angles_deg(q), path_angles_deg, path_metric);
        W(:, :, q) = Wq;
        beamformer_info{q} = bf_info_q;

        for k = 1:Ka
            Xk = reshape(Ytf_elem(k, :, :), [Mtime, R]); % [Mtime x R]
            wk = reshape(Wq(k, :), [R, 1]);
            Ztf(k, :, q) = Xk * conj(wk);
        end
    end

    out = struct();
    out.Ztf = Ztf;
    out.weights = W;
    out.beam_angles_deg = beam_angles_deg(:).';
    out.num_beams = Q;
    out.num_elements = R;
    out.beamformer_method = local_get_beamformer_name(cfg);
    out.beamformer_info = beamformer_info;
end

function [Wq, bf_info] = local_build_beam_weights(cfg, freq_hz, R, steer_angle_deg, path_angles_deg, path_metric)
    cfg_q = cfg;
    if ~isfield(cfg_q, 'rx_array') || ~isstruct(cfg_q.rx_array)
        cfg_q.rx_array = struct();
    end
    cfg_q.rx_array.steering_mode = 'manual';
    cfg_q.rx_array.steering_angle_deg = steer_angle_deg;

    [~, bf_info] = uwa_line_array_path_response(cfg_q, freq_hz, path_angles_deg, path_metric);
    Wq = uwa_beamformer_extract_full_weights(bf_info);

    if isscalar(Wq)
        Wq = repmat(ones(1, R) / sqrt(max(R, 1)), numel(freq_hz), 1);
    elseif size(Wq, 1) == 1 && numel(freq_hz) > 1
        Wq = repmat(Wq, numel(freq_hz), 1);
    end

    if size(Wq, 2) ~= R
        Wtmp = zeros(numel(freq_hz), R);
        cols = min(R, size(Wq, 2));
        Wtmp(:, 1:cols) = Wq(:, 1:cols);
        if cols == 0
            Wtmp = repmat(ones(1, R) / sqrt(max(R, 1)), numel(freq_hz), 1);
        end
        Wq = Wtmp;
    end
end

function name = local_get_beamformer_name(cfg)
    name = 'cbf';
    if isfield(cfg, 'rx_array') && isstruct(cfg.rx_array) && isfield(cfg.rx_array, 'combine_method') && ~isempty(cfg.rx_array.combine_method)
        name = char(cfg.rx_array.combine_method);
    end
end

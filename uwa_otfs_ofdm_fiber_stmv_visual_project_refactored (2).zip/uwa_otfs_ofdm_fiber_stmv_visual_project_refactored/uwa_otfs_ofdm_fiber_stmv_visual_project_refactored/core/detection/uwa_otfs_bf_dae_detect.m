function out = uwa_otfs_bf_dae_detect(cfg, X_dd, ch, noise_var, data_idx)
%UWA_OTFS_BF_DAE_DETECT OTFS BF-DAE receiver with TF beamforming preprocess.
%
% Processing steps:
%   1) build element-domain TF receive data;
%   2) perform R-to-Q TF-domain beamforming preprocessing;
%   3) apply SFFT to obtain Q DD-domain observations;
%   4) run a DD-domain multichannel adaptive detector.

    X_tf = uwa_otfs_isfft(X_dd, cfg);
    [Htf_elem, meta] = uwa_build_element_channel_response(cfg, ch);

    [Ka, Mtime, E] = size(Htf_elem);
    Ytf_elem_clean = zeros(Ka, Mtime, E);
    for e = 1:E
        Ytf_elem_clean(:, :, e) = Htf_elem(:, :, e) .* X_tf;
    end
    Ytf_elem_noisy = Ytf_elem_clean + uwa_complex_awgn(size(Ytf_elem_clean), noise_var);

    beam_angles_deg = local_select_beam_angles(cfg, ch, Ytf_elem_noisy);
    tfbf = uwa_tf_beamforming_preprocess_otfs(cfg, ch.freq_hz, Ytf_elem_noisy, beam_angles_deg, ch.path_angles_deg, abs(ch.hp_ls(:).'));

    Q = tfbf.num_beams;
    Zdd = zeros(cfg.Ndd, cfg.Mdd, Q);
    for q = 1:Q
        Zdd(:, :, q) = uwa_otfs_sfft(tfbf.Ztf(:, :, q), cfg);
    end

    dae = uwa_dd_multichannel_ipnlms_dae(cfg, Zdd, X_dd, data_idx, noise_var);

    out = struct();
    out.method = 'bf_dae';
    out.front_end_method = tfbf.beamformer_method;
    out.X_grid = X_dd;
    out.Xtf_tx = X_tf;
    out.Ytf_elem_clean = Ytf_elem_clean;
    out.Ytf_elem_noisy = Ytf_elem_noisy;
    out.beam_angles_deg = beam_angles_deg;
    out.beam_tf = tfbf.Ztf;
    out.beam_dd = Zdd;
    out.beam_weights = tfbf.weights;
    out.beamformer_info = tfbf.beamformer_info;
    out.X_hat_grid = dae.Xhat_dd;
    out.decisions_grid = dae.decisions_dd;
    out.rx_syms = dae.rx_syms;
    out.llr = dae.llr;
    out.array_meta = meta;
    out.dae = dae;
end

function beam_angles_deg = local_select_beam_angles(cfg, ch, Ytf_elem_noisy)
    pars = cfg.otfs_detection.bf_dae;
    max_beams = max(1, round(local_get_field(pars, 'max_beams', 4)));
    merge_tol = max(0, local_get_field(pars, 'angle_merge_tol_deg', 5));

    path_angles = [];
    path_metric = [];
    if isfield(ch, 'path_angles_deg') && ~isempty(ch.path_angles_deg)
        path_angles = ch.path_angles_deg(:).';
    end
    if isfield(ch, 'hp_ls') && ~isempty(ch.hp_ls)
        path_metric = abs(ch.hp_ls(:)).';
    else
        path_metric = ones(size(path_angles));
    end

    if logical(local_get_field(pars, 'use_true_doa', true)) && ~isempty(path_angles)
        beam_angles_deg = local_pick_true_angles(path_angles, path_metric, max_beams, merge_tol);
        return;
    end

    scan_angles = local_get_field(pars, 'scan_angles_deg', -90:1:90);
    method = char(local_get_field(pars, 'doa_estimator', 'capon_scan'));
    switch lower(method)
        case {'capon_scan', 'mvdr_scan'}
            scan_method = 'mvdr';
        case {'wicmv_scan', 'wideband_mvdr_scan'}
            scan_method = 'wicmv';
        otherwise
            scan_method = 'cbf';
    end
    scan = uwa_beam_scan_spectrum(cfg, ch.freq_hz, Ytf_elem_noisy, path_angles, path_metric, scan_angles, scan_method);
    beam_angles_deg = local_pick_scan_peaks(scan.scan_angles_deg, scan.power_lin, max_beams, merge_tol);

    if isempty(beam_angles_deg)
        beam_angles_deg = 0;
    end
end

function ang = local_pick_true_angles(path_angles, path_metric, max_beams, merge_tol)
    if isempty(path_angles)
        ang = 0;
        return;
    end
    [~, idx] = sort(path_metric(:), 'descend');
    picked = [];
    for i = 1:numel(idx)
        cand = path_angles(idx(i));
        if isempty(picked) || all(abs(cand - picked) > merge_tol)
            picked(end+1) = cand; %#ok<AGROW>
        end
        if numel(picked) >= max_beams
            break;
        end
    end
    ang = picked;
end

function ang = local_pick_scan_peaks(scan_angles, power_lin, max_beams, merge_tol)
    scan_angles = scan_angles(:).';
    power_lin = power_lin(:).';
    if isempty(scan_angles)
        ang = 0;
        return;
    end
    [~, order] = sort(power_lin, 'descend');
    picked = [];
    for i = 1:numel(order)
        cand = scan_angles(order(i));
        if isempty(picked) || all(abs(cand - picked) > merge_tol)
            picked(end+1) = cand; %#ok<AGROW>
        end
        if numel(picked) >= max_beams
            break;
        end
    end
    ang = picked;
end

function v = local_get_field(s, name, default_v)
    v = default_v;
    if isstruct(s) && isfield(s, name)
        cand = s.(name);
        if ~isempty(cand)
            v = cand;
        end
    end
end

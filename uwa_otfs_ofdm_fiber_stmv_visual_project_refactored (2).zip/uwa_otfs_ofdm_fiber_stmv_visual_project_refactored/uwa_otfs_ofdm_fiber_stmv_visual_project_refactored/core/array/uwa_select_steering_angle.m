function [steer_angle_deg, steer_idx, steer_mode_used] = uwa_select_steering_angle(arr, path_angles_deg, path_metric)
%UWA_SELECT_STEERING_ANGLE Resolve array steering direction.
%
% Fix note:
%   In manual/fixed steering mode, the previous implementation always set
%   steer_idx = 1. That breaks beamformer families such as MVDR/STMV/
%   improved-STMV when interference construction excludes the "steered"
%   path by index, because every manual beam incorrectly points to path #1.
%   Here we keep the user-specified steering angle, but map it to the
%   nearest physical path index when path angles are available.

    if nargin < 2 || isempty(path_angles_deg)
        path_angles_deg = 0;
    end
    if nargin < 3 || isempty(path_metric)
        path_metric = ones(size(path_angles_deg));
    end

    path_angles_deg = double(path_angles_deg(:).');
    path_metric = double(path_metric(:).');

    mode = '';
    if isfield(arr, 'steering_mode') && ~isempty(arr.steering_mode)
        mode = lower(strtrim(arr.steering_mode));
    end
    if isempty(mode)
        mode = 'strongest';
    end

    switch mode
        case {'manual', 'fixed'}
            steer_angle_deg = local_get_numeric_field(arr, 'steering_angle_deg', 0);

            if isempty(path_angles_deg)
                steer_idx = 1;
            else
                metric_is_valid = isfinite(path_angles_deg);
                valid_idx = find(metric_is_valid);

                if isempty(valid_idx)
                    steer_idx = 1;
                else
                    [~, rel_idx] = min(abs(path_angles_deg(valid_idx) - steer_angle_deg));
                    steer_idx = valid_idx(rel_idx);
                end
            end

            steer_mode_used = 'manual';

        case {'direct', 'earliest', 'first'}
            steer_idx = find(isfinite(path_angles_deg), 1, 'first');
            if isempty(steer_idx)
                steer_idx = 1;
            end
            steer_angle_deg = local_safe_angle_lookup(path_angles_deg, steer_idx, 0);
            steer_mode_used = 'direct';

        otherwise
            if isempty(path_metric) || all(~isfinite(path_metric))
                steer_idx = find(isfinite(path_angles_deg), 1, 'first');
            else
                metric_tmp = abs(path_metric);
                metric_tmp(~isfinite(metric_tmp)) = -inf;
                [~, steer_idx] = max(metric_tmp);
            end

            if isempty(steer_idx) || steer_idx < 1
                steer_idx = 1;
            end
            steer_angle_deg = local_safe_angle_lookup(path_angles_deg, steer_idx, 0);
            steer_mode_used = 'strongest';
    end

    if ~isfinite(steer_angle_deg)
        steer_angle_deg = 0;
    end
end

function v = local_get_numeric_field(s, name, default_v)
    v = default_v;
    if isstruct(s) && isfield(s, name)
        cand = s.(name);
        if isnumeric(cand) && isscalar(cand) && isfinite(cand)
            v = double(cand);
        end
    end
end

function ang = local_safe_angle_lookup(path_angles_deg, idx, default_v)
    ang = default_v;
    if isempty(path_angles_deg)
        return;
    end

    idx = max(1, min(numel(path_angles_deg), idx));
    cand = path_angles_deg(idx);
    if isfinite(cand)
        ang = cand;
    end
end
